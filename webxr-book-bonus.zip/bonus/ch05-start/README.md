# ch05-start

『野良猫でもわかるWebXRの教科書』の第5章のスタート地点です。テンプレートに、ねこびの 3D モデル（public/models/nekobi.glb）を足してあります。

## 使い方

1. ターミナルで、このフォルダーに移動します（`cd ` と打ってから、このフォルダーをターミナルにドラッグして `return`）
2. `npm install` を実行します（最初の1回だけ）
3. はじめてのときだけ、`npm run dev` を実行して Mac のパスワードを入れ、アドレスが出たら `control` ＋ `C` で止めます（証明書を作るため。Mac で1回だけ）
4. `claude`（Claude Code）か `codex`（Codex）で AI を起動して、「開発サーバーを動かして」と頼みます
5. AI が教えてくれた `https://192.168.…:5173` のアドレスを、Quest のブラウザで開きます

くわしくは、本の第1章を見てください。

## 入っているもの

- three.js 0.186.1 と Vite（開発サーバー）。mkcert で HTTPS にして、同じ Wi-Fi の Quest から開けます
- 「VR で遊ぶ」ボタン（MR のボタンも足せます）
- エラーを VR の中に出す赤い板
- Quest のブラウザのログを Mac で読むスクリプト（`npm run log`）
- 開発サーバーを裏で動かす・止める・ようすを見るスクリプト（`npm run start` / `stop` / `status`。出力は `dev.log`）。AI の会話が終わっても止まりません
- AI への約束ごと（Claude 用の `CLAUDE.md`、Codex 用の `AGENTS.md`。中身は同じ）
- AI が、セーブポイント（git）を作るときに、毎回許可を聞かなくてよい設定（Claude は、開発サーバーを動かす・止めるときも）（Claude 用の `.claude/settings.json`、Codex 用の `.codex/rules/default.rules`）。`git push` などの危ない操作は、させない設定にしています。ほかのコマンドは、AI が実行する前に聞いてきます
