// 作品の入り口。three.js で 3D の世界を作り、Quest の VR で見られるようにする
// 作品の中身は、いちばん下の「ここから下が作品の中身」より下に書く
// AI への約束ごとは AGENTS.md（Codex 用）と CLAUDE.md（Claude 用）に書いてある
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- 3つの役者：舞台（シーン）・目（カメラ）・描く係（レンダラー） ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // 背景の色（MR では自動で透明になり、部屋が見える）

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // 目の高さ 1.5 メートル（VR の中では、Quest の頭の動きに合わせて動く）

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // 床の高さを 0 にする
document.body.appendChild(renderer.domElement);

// ---- 明かり ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // 全体をまんべんなく照らす光
const sun = new THREE.DirectionalLight(0xffffff, 2);            // ひとつの向きから当たる光
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- 床のマス目（1マス 1 メートル）。大きさの目安にする。MR では本物の床が見えるので隠す ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- Mac のブラウザで見るとき：マウスのドラッグで見回せるようにする（VR の中では使わない） ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- 「MR で遊ぶ」ボタン ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-ar', 'MR で遊ぶ'));

// ---- エラーを VR の中にも出す（ログは npm run log で読める） ----
const debug = setupDebugPanel(scene, renderer);

// ---- 毎フレームくり返す：下の update() で動かして、描き直す ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // 止まっていたあとに、物が一気に動かないようにする
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // エラーが出ても止めずに描き続ける（エラーは赤い板に出る）
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- ブラウザの窓の大きさが変わったら、絵の大きさを合わせる ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== ここから下が作品の中身 ========
// 置くものは scene.add() で舞台に置く。単位はメートル。床は高さ 0、正面はマイナス z の向き
// 毎フレーム動かしたいものは、下の update() の中に書く

// ねこびを置く入れ物。読み込みが終わる前でも、MR 開始時の位置を覚えておける
const nekobi = new THREE.Group();
nekobi.position.set(0, 0, -1);
scene.add(nekobi);

// 上からの明かりで影を作る。明かりもねこびと一緒に動かす
renderer.shadowMap.enabled = true;
sun.position.set(0, 2, 0);
sun.castShadow = true;
sun.shadow.mapSize.set(512, 512);
sun.shadow.camera.left = -0.6;
sun.shadow.camera.right = 0.6;
sun.shadow.camera.top = 0.6;
sun.shadow.camera.bottom = -0.6;
sun.shadow.camera.near = 0.1;
sun.shadow.camera.far = 3;
sun.shadow.normalBias = 0.01;
nekobi.add(sun, sun.target);

// 板そのものは透明にし、影だけを本物の床に重ねる
const shadowFloor = new THREE.Mesh(
  new THREE.PlaneGeometry(1.2, 1.2),
  new THREE.ShadowMaterial({ opacity: 0.3, depthWrite: false }),
);
shadowFloor.rotation.x = -Math.PI / 2;
shadowFloor.position.y = 0.001;
shadowFloor.receiveShadow = true;
nekobi.add(shadowFloor);

new GLTFLoader().load('/models/nekobi.glb', (gltf) => {
  const model = gltf.scene;
  // ねこびを構成するすべての形が影を落とすようにする
  model.traverse((object) => {
    if (object.isMesh) object.castShadow = true;
  });
  const bounds = new THREE.Box3().setFromObject(model);
  const size = bounds.getSize(new THREE.Vector3());
  // 耳までの高さを40センチにそろえる
  model.scale.setScalar(0.4 / size.y);
  bounds.setFromObject(model);
  const center = bounds.getCenter(new THREE.Vector3());
  // 足元を床に合わせ、横方向の中心を入れ物の中心にそろえる
  model.position.x -= center.x;
  model.position.y -= bounds.min.y;
  model.position.z -= center.z;
  nekobi.add(model);
}, undefined, (error) => {
  console.error('ねこびを読み込めませんでした:', error);
});

// MR に入るたび、最初に見ている方向の1メートル先の床に置く
let placeNekobi = false;
const forward = new THREE.Vector3();
const headRotation = new THREE.Quaternion();
renderer.xr.addEventListener('sessionstart', () => {
  placeNekobi = true;
  nekobi.visible = false;
});
renderer.xr.addEventListener('sessionend', () => {
  placeNekobi = false;
  nekobi.position.set(0, 0, -1);
  nekobi.rotation.y = 0;
  nekobi.visible = true;
});

// Quest が覚えている部屋の面を、ほとんど透明な板で表示する
const roomPlanes = new Map();

function removeRoomPlane(plane, entry) {
  scene.remove(entry.mesh);
  entry.mesh.geometry.dispose();
  entry.mesh.material.dispose();
  roomPlanes.delete(plane);
}

renderer.xr.addEventListener('sessionend', () => {
  for (const [plane, entry] of roomPlanes) removeRoomPlane(plane, entry);
});

function createRoomPlaneGeometry(plane) {
  // 面の輪郭は、その面を基準にした x・z 座標で届く
  const points = Array.from(plane.polygon, (point) => new THREE.Vector2(point.x, -point.z));
  const geometry = new THREE.ShapeGeometry(new THREE.Shape(points));
  geometry.rotateX(-Math.PI / 2);
  return geometry;
}

function updateRoomPlanes(frame, referenceSpace) {
  const planes = frame.detectedPlanes;
  if (!planes) return;

  // 見つからなくなった面は、板と使っていた資源を片づける
  for (const [plane, entry] of roomPlanes) {
    if (!planes.has(plane)) removeRoomPlane(plane, entry);
  }

  for (const plane of planes) {
    const pose = frame.getPose(plane.planeSpace, referenceSpace);
    let entry = roomPlanes.get(plane);
    if (!pose || plane.polygon.length < 3) {
      if (entry) entry.mesh.visible = false;
      continue;
    }
    if (!entry) {
      const mesh = new THREE.Mesh(
        createRoomPlaneGeometry(plane),
        new THREE.MeshBasicMaterial({
          transparent: true, opacity: 0.12, side: THREE.DoubleSide,
          depthWrite: false,
        }),
      );
      mesh.matrixAutoUpdate = false;
      // ねこびの影より先に描き、影の見え方を保つ
      mesh.renderOrder = -1;
      scene.add(mesh);
      entry = { mesh, changedTime: plane.lastChangedTime };
      roomPlanes.set(plane, entry);
    } else if (entry.changedTime !== plane.lastChangedTime) {
      entry.mesh.geometry.dispose();
      entry.mesh.geometry = createRoomPlaneGeometry(plane);
      entry.changedTime = plane.lastChangedTime;
    }
    entry.mesh.visible = true;
    entry.mesh.matrix.fromArray(pose.transform.matrix);
    // 向きが届かない場合は、面の上向きの軸から横向きかどうかを調べる
    const horizontal = plane.orientation === 'horizontal' ||
      (plane.orientation == null && Math.abs(entry.mesh.matrix.elements[5]) > 0.7);
    entry.mesh.material.color.setHex(horizontal ? 0x66ff88 : 0x6699ff);
  }
}

// 右手のコントローラーだけを使う。手の追跡から届くつまみ操作は使わない
let rightInputSource = null;
let moveNekobi = false;
for (let index = 0; index < 2; index++) {
  const controller = renderer.xr.getController(index);
  controller.addEventListener('connected', (event) => {
    const source = event.data;
    if (source.handedness === 'right' && source.targetRayMode === 'tracked-pointer' && !source.hand) {
      rightInputSource = source;
    }
  });
  controller.addEventListener('disconnected', (event) => {
    if (event.data === rightInputSource) {
      rightInputSource = null;
      moveNekobi = false;
      aimLine.visible = aimMarker.visible = false;
    }
  });
  controller.addEventListener('selectstart', (event) => {
    if (rightInputSource && event.data === rightInputSource) moveNekobi = true;
  });
}

// 光線と白い丸は使い回し、毎フレーム作り直さない
const aimGeometry = new THREE.BufferGeometry().setFromPoints([
  new THREE.Vector3(), new THREE.Vector3(0, 0, -10),
]);
const aimLine = new THREE.Line(aimGeometry, new THREE.LineBasicMaterial({ color: 0xffffff }));
aimLine.matrixAutoUpdate = false;
aimLine.frustumCulled = false;
aimLine.visible = false;
scene.add(aimLine);

const aimMarker = new THREE.Mesh(
  new THREE.CircleGeometry(0.025, 24),
  new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, depthWrite: false }),
);
aimMarker.visible = false;
scene.add(aimMarker);

const aimRaycaster = new THREE.Raycaster();
aimRaycaster.far = 10;
const aimDirection = new THREE.Vector3();
const aimNormal = new THREE.Vector3();
const aimNormalMatrix = new THREE.Matrix3();
const markerAxis = new THREE.Vector3(0, 0, 1);
const aimTargets = [];
const aimHits = [];

renderer.xr.addEventListener('sessionend', () => {
  rightInputSource = null;
  moveNekobi = false;
  aimLine.visible = aimMarker.visible = false;
});

function updateControllerAim(frame, referenceSpace) {
  // トリガーはこのフレームで一度だけ処理し、空振りをあとに持ち越さない
  const shouldMove = moveNekobi;
  moveNekobi = false;
  aimLine.visible = aimMarker.visible = false;
  if (!rightInputSource) return;
  const pose = frame.getPose(rightInputSource.targetRaySpace, referenceSpace);
  if (!pose) return;

  aimLine.matrix.fromArray(pose.transform.matrix);
  aimRaycaster.ray.origin.setFromMatrixPosition(aimLine.matrix);
  aimDirection.set(0, 0, -1).transformDirection(aimLine.matrix);
  aimRaycaster.ray.direction.copy(aimDirection);
  aimTargets.length = 0;
  aimHits.length = 0;
  for (const { mesh } of roomPlanes.values()) {
    if (!mesh.visible) continue;
    // 描画より先に、新しく届いた面の位置で当たりを調べる
    mesh.updateMatrixWorld(true);
    aimTargets.push(mesh);
  }
  aimRaycaster.intersectObjects(aimTargets, false, aimHits);
  const hit = aimHits[0];
  aimGeometry.attributes.position.setXYZ(1, 0, 0, -(hit ? hit.distance : 10));
  aimGeometry.attributes.position.needsUpdate = true;
  aimLine.visible = true;
  if (!hit) return;

  // 丸を当たった面に沿わせ、ほんの少し手前に浮かせて重なりを避ける
  aimNormalMatrix.getNormalMatrix(hit.object.matrixWorld);
  aimNormal.copy(hit.face.normal).applyNormalMatrix(aimNormalMatrix);
  if (aimNormal.dot(aimDirection) > 0) aimNormal.negate();
  aimMarker.position.copy(hit.point).addScaledVector(aimNormal, 0.002);
  aimMarker.quaternion.setFromUnitVectors(markerAxis, aimNormal);
  aimMarker.visible = true;

  if (!shouldMove) return;
  const viewerPose = frame.getViewerPose(referenceSpace);
  if (!viewerPose) return;
  // 足元を目印の位置へ移し、体は立てたまま遊ぶ人のほうへ向ける
  nekobi.position.copy(hit.point);
  const viewerPosition = viewerPose.transform.position;
  const dx = viewerPosition.x - hit.point.x;
  const dz = viewerPosition.z - hit.point.z;
  if (dx * dx + dz * dz > 0.0001) nekobi.rotation.y = Math.atan2(dx, dz);
  nekobi.visible = true;
  placeNekobi = false;
}

/**
 * 毎フレーム呼ばれる
 * @param {number} delta 前のフレームからの時間（秒）
 * @param {number} elapsed 始まってからの時間（秒）
 */
function update(delta, elapsed) {
  if (!renderer.xr.isPresenting) return;
  const frame = renderer.xr.getFrame();
  const referenceSpace = renderer.xr.getReferenceSpace();
  if (!frame || !referenceSpace) return;
  updateRoomPlanes(frame, referenceSpace);
  updateControllerAim(frame, referenceSpace);
  if (!placeNekobi) return;
  const pose = frame.getViewerPose(referenceSpace);
  if (!pose) return;

  headRotation.copy(pose.transform.orientation);
  forward.set(0, 0, -1).applyQuaternion(headRotation);
  // 上下の傾きを除いて、床の上で1メートル先に置く
  forward.y = 0;
  if (forward.lengthSq() < 0.0001) return;
  forward.normalize();
  nekobi.position.copy(pose.transform.position).add(forward);
  nekobi.position.y = 0;
  // モデルの顔はプラス z 向きなので、遊ぶ人のほうへ向ける
  nekobi.rotation.y = Math.atan2(-forward.x, -forward.z);
  nekobi.visible = true;
  placeNekobi = false;
}
