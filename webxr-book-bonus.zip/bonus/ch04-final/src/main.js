// ---- ゲームの難しさ：変えたい数字はここにまとめる ----
const GAME_SETTINGS = {
  spawnInterval: 2,       // 最初の風船が出る間隔（秒）
  finalSpawnInterval: 0.5, // 最後の風船が出る間隔（秒）。0.5で1秒に2個
  easyDuration: 20,       // 最初のゆっくりした時間（秒）
  hardDuration: 20,       // 最後の難しい時間（秒）
  finalRiseMultiplier: 1.5, // 最後の上昇速度が、最初の何倍になるか
  riseSpeed: 0.5,         // 風船が上がる速さ（1秒あたりのメートル）
  balloonDiameter: 0.3,  // 風船の横の直径（メートル）。0.3で30センチ
  timeLimit: 60,          // ゲームの制限時間（秒）
  pointsPerBalloon: 1,    // 風船を1個割ったときの点数
  goldChance: 0.1,        // 金色の風船が出る確率。0.1で約10個に1個
  goldRiseMultiplier: 2,  // 金色の風船が、普通の風船の何倍の速さで上がるか
  goldPoints: 5,          // 金色の風船を1個割ったときの点数
};

// 作品の入り口。three.js で 3D の世界を作り、Quest の VR で見られるようにする
// 作品の中身は、いちばん下の「ここから下が作品の中身」より下に書く
// AI への約束ごとは AGENTS.md（Codex 用）と CLAUDE.md（Claude 用）に書いてある
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- 3つの役者：舞台（シーン）・目（カメラ）・描く係（レンダラー） ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // 背景の色（MR では自動で透明になり、部屋が見える）

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // 目の高さ 1.5 メートル（VR の中では、Quest の頭の動きに合わせて動く）

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // 床の高さを 0 にする
document.body.appendChild(renderer.domElement);

// ---- 明かり ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // 全体をまんべんなく照らす光
const sun = new THREE.DirectionalLight(0xffffff, 2);            // ひとつの向きから当たる光
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- 床のマス目（1マス 1 メートル）。大きさの目安にする。MR では本物の床が見えるので隠す ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- Mac のブラウザで見るとき：マウスのドラッグで見回せるようにする（VR の中では使わない） ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- 「VR で遊ぶ」ボタン ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'VR で遊ぶ'));

// ---- エラーを VR の中にも出す（ログは npm run log で読める） ----
const debug = setupDebugPanel(scene, renderer);

// ---- 毎フレームくり返す：下の update() で動かして、描き直す ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // 止まっていたあとに、物が一気に動かないようにする
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // エラーが出ても止めずに描き続ける（エラーは赤い板に出る）
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- ブラウザの窓の大きさが変わったら、絵の大きさを合わせる ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== ここから下が作品の中身 ========
// 置くものは scene.add() で舞台に置く。単位はメートル。床は高さ 0、正面はマイナス z の向き
// 毎フレーム動かしたいものは、下の update() の中に書く

import { XRControllerModelFactory } from 'three/addons/webxr/XRControllerModelFactory.js';

// 両手の先から、正面（マイナス z）へ長さ5メートルの白い光線を出す
const rayGeometry = new THREE.CylinderGeometry(0.002, 0.002, 5, 8);
rayGeometry.rotateX(Math.PI / 2);
rayGeometry.translate(0, 0, -2.5);
const rayMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, fog: false, toneMapped: false });
const controllerModelFactory = new XRControllerModelFactory();
const laserControllers = [];

for (let i = 0; i < 2; i++) {
  // 光線をコントローラーの子にすると、位置と向きが一緒に動く
  const controller = renderer.xr.getController(i);
  const ray = new THREE.Mesh(rayGeometry, rayMaterial);
  ray.visible = false;
  controller.add(ray);
  controller.addEventListener('connected', (event) => {
    ray.visible = event.data.targetRayMode === 'tracked-pointer' && !event.data.hand;
  });
  controller.addEventListener('disconnected', () => { ray.visible = false; });
  scene.add(controller);
  laserControllers.push({ controller, ray });
  controller.addEventListener('selectstart', (event) => {
    if (!ray.visible || !renderer.xr.isPresenting) return;
    if (gameState === 'finished') {
      startGame();
      return;
    }
    if (gameState !== 'playing') return;
    const target = hitsBalloon(controller);
    if (target) burstBalloon(target, event.data);
  });

  // 握っている場所に、機種に合ったコントローラーの形を表示する
  const grip = renderer.xr.getControllerGrip(i);
  grip.add(controllerModelFactory.createControllerModel(grip));
  scene.add(grip);
}

// 生きている風船と、割れたかけらを別々に管理する
const balloons = [];
const balloonMeshes = [];
const fragmentBursts = [];
const balloonColors = [0xe52222, 0x2277ee, 0xffdd22, 0x22bb55, 0xff66aa];
let spawnProgress = 0;
const viewerPosition = new THREE.Vector3();
const viewerForward = new THREE.Vector3();
const viewerRotation = new THREE.Quaternion();

// 音の聞き手をカメラに付け、短い破裂音をプログラムで作る
const popListener = new THREE.AudioListener();
camera.add(popListener);
let popBuffer;
const activePopSounds = new Set();

function removePopSound(sound) {
  if (!activePopSounds.delete(sound)) return;
  if (sound.isPlaying) sound.stop();
  sound.disconnect();
  sound.gain.disconnect();
  scene.remove(sound);
}

function playPopSound(position) {
  if (!popBuffer) {
    const context = popListener.context;
    const duration = 0.12;
    popBuffer = context.createBuffer(1, Math.ceil(context.sampleRate * duration), context.sampleRate);
    const samples = popBuffer.getChannelData(0);
    for (let i = 0; i < samples.length; i++) {
      const time = i / context.sampleRate;
      const attack = Math.min(1, time / 0.001);
      const fade = Math.pow(1 - i / samples.length, 2);
      samples[i] = attack * fade * (
        (Math.random() * 2 - 1) * 0.65 * Math.exp(-time * 35)
        + Math.sin(2 * Math.PI * 150 * time) * 0.35 * Math.exp(-time * 45)
      );
    }
  }
  const sound = new THREE.PositionalAudio(popListener);
  sound.setBuffer(popBuffer);
  sound.setRefDistance(2);
  sound.setVolume(0.7);
  sound.position.copy(position);
  sound.onEnded = () => {
    THREE.Audio.prototype.onEnded.call(sound);
    removePopSound(sound);
  };
  activePopSounds.add(sound);
  scene.add(sound);
  // 再生前に位置を反映して、割れた場所から聞こえるようにする
  sound.updateMatrixWorld(true);
  sound.play();
}

function vibrateController(inputSource) {
  const actuator = inputSource?.gamepad?.hapticActuators?.[0];
  if (!actuator) return;
  // 振動が使えない場合も、ゲームはそのまま続ける
  try {
    const result = actuator.pulse(0.5, 100);
    result?.catch(() => {});
  } catch {
    // 接続が切れているときは何もしない
  }
}

// 正面3メートル、高さ2.5メートルの看板に大きな文字を描く
let score = 0;
let remainingTime = GAME_SETTINGS.timeLimit;
let gameState = 'waiting';
let previousSignText = '';
const signCanvas = document.createElement('canvas');
signCanvas.width = 1024;
signCanvas.height = 512;
const signContext = signCanvas.getContext('2d');
const signTexture = new THREE.CanvasTexture(signCanvas);
signTexture.colorSpace = THREE.SRGBColorSpace;
const sign = new THREE.Mesh(
  new THREE.PlaneGeometry(1.8, 0.9),
  new THREE.MeshBasicMaterial({ map: signTexture, toneMapped: false, fog: false })
);
sign.position.set(0, 2.5, -3);
scene.add(sign);

function updateSign() {
  const seconds = Math.max(0, Math.ceil(remainingTime - 1e-9));
  const text = gameState === 'finished'
    ? `おしまい！\nスコア ${score}点`
    : `スコア ${score}\nのこり${seconds}秒`;
  if (text === previousSignText) return;
  previousSignText = text;
  signContext.fillStyle = '#fff8e8';
  signContext.fillRect(0, 0, 1024, 512);
  signContext.fillStyle = '#25354a';
  signContext.font = 'bold 110px sans-serif';
  signContext.textAlign = 'center';
  signContext.textBaseline = 'middle';
  const lines = text.split('\n');
  signContext.fillText(lines[0], 512, 160, 960);
  signContext.fillText(lines[1], 512, 350, 960);
  signTexture.needsUpdate = true;
}

// 新しいゲームでは、前の風船とかけらも片付ける
function clearGameObjects() {
  for (const sound of activePopSounds) removePopSound(sound);
  while (balloons.length > 0) removeBalloon(balloons[balloons.length - 1]);
  for (const burst of fragmentBursts) {
    for (const { mesh } of burst.fragments) scene.remove(mesh);
    burst.geometry.dispose();
    burst.material.dispose();
  }
  fragmentBursts.length = 0;
}

function startGame() {
  clearGameObjects();
  score = 0;
  remainingTime = GAME_SETTINGS.timeLimit;
  spawnProgress = 0;
  gameState = 'playing';
  updateSign();
}

renderer.xr.addEventListener('sessionstart', startGame);
renderer.xr.addEventListener('sessionend', () => {
  clearGameObjects();
  gameState = 'waiting';
  score = 0;
  remainingTime = GAME_SETTINGS.timeLimit;
  spawnProgress = 0;
  updateSign();
});
updateSign();

// 今いる場所と向きを基準に、前・左・右の2〜4メートル先に出す
function spawnBalloon() {
  const viewer = renderer.xr.isPresenting ? renderer.xr.getCamera() : camera;
  viewer.getWorldPosition(viewerPosition);
  viewer.getWorldQuaternion(viewerRotation);
  viewerForward.set(0, 0, -1).applyQuaternion(viewerRotation);
  const heading = Math.hypot(viewerForward.x, viewerForward.z) > 0.001
    ? Math.atan2(viewerForward.x, -viewerForward.z) : 0;
  const angle = heading + (Math.random() - 0.5) * Math.PI;
  const distance = 2 + Math.random() * 2;
  const group = new THREE.Group();
  group.position.set(
    viewerPosition.x + Math.sin(angle) * distance,
    0.43,
    viewerPosition.z - Math.cos(angle) * distance
  );
  const isGold = Math.random() < GAME_SETTINGS.goldChance;
  const color = isGold ? 0xffc526 : balloonColors[Math.floor(Math.random() * balloonColors.length)];
  const material = new THREE.MeshStandardMaterial({
    color,
    roughness: isGold ? 0.2 : 0.35,
    metalness: isGold ? 0.5 : 0,
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(GAME_SETTINGS.balloonDiameter / 2, 24, 16), material);
  mesh.scale.y = 1.2;
  group.add(mesh);
  const string = new THREE.Mesh(
    new THREE.CylinderGeometry(0.0015, 0.0015, 0.25, 6),
    new THREE.MeshStandardMaterial({ color: 0xffffff })
  );
  string.position.y = -0.305;
  group.add(string);
  const balloon = {
    group, mesh, string, color, baseX: group.position.x, age: 0,
    riseMultiplier: isGold ? GAME_SETTINGS.goldRiseMultiplier : 1,
    points: isGold ? GAME_SETTINGS.goldPoints : GAME_SETTINGS.pointsPerBalloon,
  };
  mesh.userData.balloon = balloon;
  balloons.push(balloon);
  balloonMeshes.push(mesh);
  scene.add(group);
}

// 消した風船の形と材質を片付ける
function removeBalloon(balloon) {
  scene.remove(balloon.group);
  balloons.splice(balloons.indexOf(balloon), 1);
  balloonMeshes.splice(balloonMeshes.indexOf(balloon.mesh), 1);
  balloon.mesh.geometry.dispose();
  balloon.mesh.material.dispose();
  balloon.string.geometry.dispose();
  balloon.string.material.dispose();
}

const balloonRaycaster = new THREE.Raycaster();
balloonRaycaster.far = 5;
const rayOrigin = new THREE.Vector3();
const rayDirection = new THREE.Vector3();
const rayRotation = new THREE.Matrix4();
const balloonHits = [];
const highlightWhite = new THREE.Color(0xffffff);

// 光線の5メートル以内で、いちばん手前の風船を選ぶ
function hitsBalloon(controller) {
  if (!renderer.xr.isPresenting) return null;
  controller.updateWorldMatrix(true, false);
  for (const balloon of balloons) balloon.mesh.updateWorldMatrix(true, false);
  rayOrigin.setFromMatrixPosition(controller.matrixWorld);
  rayRotation.extractRotation(controller.matrixWorld);
  rayDirection.set(0, 0, -1).applyMatrix4(rayRotation);
  balloonRaycaster.set(rayOrigin, rayDirection);
  balloonHits.length = 0;
  balloonRaycaster.intersectObjects(balloonMeshes, false, balloonHits);
  return balloonHits.length > 0 ? balloonHits[0].object.userData.balloon : null;
}

// 割った風船と同じ色のかけらを飛ばす
function burstBalloon(balloon, inputSource) {
  if (gameState !== 'playing' || !balloons.includes(balloon)) return;
  score += balloon.points;
  updateSign();
  const geometry = new THREE.PlaneGeometry(0.025, 0.035);
  const material = new THREE.MeshStandardMaterial({ color: balloon.color, side: THREE.DoubleSide });
  const fragments = [];
  for (let i = 0; i < 20; i++) {
    const mesh = new THREE.Mesh(geometry, material);
    const direction = new THREE.Vector3().randomDirection();
    mesh.position.copy(balloon.group.position).addScaledVector(direction, 0.1);
    mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
    scene.add(mesh);
    fragments.push({ mesh, velocity: direction.multiplyScalar(0.6 + Math.random() * 0.8) });
  }
  fragmentBursts.push({ fragments, geometry, material, age: 0 });
  playPopSound(balloon.group.position);
  vibrateController(inputSource);
  removeBalloon(balloon);
}

// 最初の20秒は一定、そのあいだは少しずつ変え、最後の20秒は最大にする
function getGameDifficulty(gameElapsed) {
  const transitionDuration = GAME_SETTINGS.timeLimit - GAME_SETTINGS.easyDuration - GAME_SETTINGS.hardDuration;
  const progress = transitionDuration > 0
    ? THREE.MathUtils.clamp((gameElapsed - GAME_SETTINGS.easyDuration) / transitionDuration, 0, 1)
    : (gameElapsed < GAME_SETTINGS.easyDuration ? 0 : 1);
  return {
    spawnRate: THREE.MathUtils.lerp(1 / GAME_SETTINGS.spawnInterval, 1 / GAME_SETTINGS.finalSpawnInterval, progress),
    riseSpeed: GAME_SETTINGS.riseSpeed * THREE.MathUtils.lerp(1, GAME_SETTINGS.finalRiseMultiplier, progress),
  };
}

/**
 * 毎フレーム呼ばれる
 * @param {number} delta 前のフレームからの時間（秒）
 * @param {number} elapsed 始まってからの時間（秒）
 */
function update(delta, elapsed) {
  // フレームの中央の時刻で計算して、描く回数によるペースの差を小さくする
  const difficulty = getGameDifficulty(GAME_SETTINGS.timeLimit - remainingTime + (gameState === 'playing' ? delta / 2 : 0));
  if (gameState === 'playing') {
    remainingTime = Math.max(0, remainingTime - delta);
    if (remainingTime <= 1e-9) {
      remainingTime = 0;
      gameState = 'finished';
    } else {
      spawnProgress += delta * difficulty.spawnRate;
      while (spawnProgress + 1e-9 >= 1) {
        spawnProgress = Math.max(0, spawnProgress - 1);
        spawnBalloon();
      }
    }
    updateSign();
  }
  for (let i = balloons.length - 1; i >= 0; i--) {
    const balloon = balloons[i];
    balloon.age += delta;
    balloon.group.position.y += difficulty.riseSpeed * balloon.riseMultiplier * delta;
    balloon.group.position.x = balloon.baseX + Math.sin(balloon.age * 1.5) * 0.1;
    if (balloon.group.position.y > 8) {
      removeBalloon(balloon);
      continue;
    }
    balloon.mesh.material.color.setHex(balloon.color);
    balloon.mesh.material.emissive.setHex(0x000000);
  }
  for (const { controller, ray } of laserControllers) {
    const target = gameState === 'playing' && ray.visible ? hitsBalloon(controller) : null;
    if (target) {
      target.mesh.material.color.setHex(target.color).lerp(highlightWhite, 0.2);
      target.mesh.material.emissive.setHex(target.color).multiplyScalar(0.15);
    }
  }
  for (let i = fragmentBursts.length - 1; i >= 0; i--) {
    const burst = fragmentBursts[i];
    burst.age += delta;
    for (const { mesh, velocity } of burst.fragments) {
      velocity.y -= 2 * delta;
      mesh.position.addScaledVector(velocity, delta);
      mesh.rotation.x += 3 * delta;
      mesh.rotation.z += 2 * delta;
    }
    // かけらはそれぞれ1.5秒で片付けて、形と材質も解放する
    if (burst.age >= 1.5) {
      for (const { mesh } of burst.fragments) scene.remove(mesh);
      burst.geometry.dispose();
      burst.material.dispose();
      fragmentBursts.splice(i, 1);
    }
  }
}

// ---- 原っぱ（第4章のスタート地点）：空と地面 ----
scene.remove(grid);                                // マス目は使わない
scene.background = new THREE.Color(0xe3f3ff);      // 空の色（地平線のあたり）
scene.fog = new THREE.Fog(0xe3f3ff, 25, 110);      // 遠くを空の色にかすませる

// 空：内側に色をぬった大きな球。上は濃い青、地平線に近いほど白っぽい
const skyGeometry = new THREE.SphereGeometry(100, 32, 16);
const skyColors = [];
const top = new THREE.Color(0x4a9be0);
const horizon = new THREE.Color(0xe3f3ff);
const position = skyGeometry.attributes.position;
for (let i = 0; i < position.count; i++) {
  const height = Math.max(0, position.getY(i) / 100);   // 0（地平線）〜 1（真上）
  const color = horizon.clone().lerp(top, Math.pow(height, 0.6));
  skyColors.push(color.r, color.g, color.b);
}
skyGeometry.setAttribute('color', new THREE.Float32BufferAttribute(skyColors, 3));
const sky = new THREE.Mesh(skyGeometry, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false }));
scene.add(sky);

// 地面：240メートル四方の緑の板（遠くは霧で空の色にかすむ）
const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(240, 240, 48, 48),
  new THREE.MeshStandardMaterial({ color: 0x79c26a, roughness: 1 })
);
ground.rotation.x = -Math.PI / 2;                  // 寝かせて床にする
scene.add(ground);

// 遠くの丘：つぶした球を、まわりにぐるりと並べる
const hillMaterial = new THREE.MeshStandardMaterial({ color: 0x5fae58, roughness: 1 });
for (let i = 0; i < 9; i++) {
  const angle = (i / 9) * Math.PI * 2 + 0.3;
  const hill = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), hillMaterial);
  const distance = 55 + (i % 3) * 12;
  hill.position.set(Math.sin(angle) * distance, 0, -Math.cos(angle) * distance);
  hill.scale.set(14 + (i % 4) * 4, 5 + (i % 3) * 2.5, 10);
  hill.lookAt(0, 0, 0);
  scene.add(hill);
}

// 雲：白い球をいくつか重ねて、空に浮かべる
const cloudMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0xaab6c2, fog: false });
for (let i = 0; i < 7; i++) {
  const angle = (i / 7) * Math.PI * 2;
  const cloud = new THREE.Group();
  for (let j = 0; j < 4; j++) {
    const puff = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), cloudMaterial);
    puff.position.set((j - 1.5) * 2.2, (j % 2) * 0.8, 0);
    puff.scale.setScalar(2 + (j % 2));
    cloud.add(puff);
  }
  cloud.position.set(Math.sin(angle) * 80, 30 + (i % 3) * 6, -Math.cos(angle) * 80);
  cloud.lookAt(0, cloud.position.y, 0);
  scene.add(cloud);
}
