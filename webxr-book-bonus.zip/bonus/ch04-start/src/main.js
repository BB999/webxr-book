// 作品の入り口。three.js で 3D の世界を作り、Quest の VR で見られるようにする
// 作品の中身は、いちばん下の「ここから下が作品の中身」より下に書く
// AI への約束ごとは AGENTS.md（Codex 用）と CLAUDE.md（Claude 用）に書いてある
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- 3つの役者：舞台（シーン）・目（カメラ）・描く係（レンダラー） ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // 背景の色（MR では自動で透明になり、部屋が見える）

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.6, 0);                 // 目の高さ 1.6 メートル（VR の中では、Quest の頭の動きに合わせて動く）

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // 床の高さを 0 にする
document.body.appendChild(renderer.domElement);

// ---- 明かり ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // 全体をまんべんなく照らす光
const sun = new THREE.DirectionalLight(0xffffff, 2);            // ひとつの向きから当たる光
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- 床のマス目（1マス 1 メートル）。大きさの目安にする。MR では本物の床が見えるので隠す ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- Mac のブラウザで見るとき：マウスのドラッグで見回せるようにする（VR の中では使わない） ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- 「VR で遊ぶ」ボタン ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'VR で遊ぶ'));

// ---- エラーを VR の中にも出す（ログは npm run log で読める） ----
const debug = setupDebugPanel(scene, renderer);

// ---- 毎フレームくり返す：下の update() で動かして、描き直す ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // 止まっていたあとに、物が一気に動かないようにする
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // エラーが出ても止めずに描き続ける（エラーは赤い板に出る）
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- ブラウザの窓の大きさが変わったら、絵の大きさを合わせる ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== ここから下が作品の中身 ========
// 置くものは scene.add() で舞台に置く。単位はメートル。床は高さ 0、正面はマイナス z の向き
// 毎フレーム動かしたいものは、下の update() の中に書く

/**
 * 毎フレーム呼ばれる
 * @param {number} delta 前のフレームからの時間（秒）
 * @param {number} elapsed 始まってからの時間（秒）
 */
function update(delta, elapsed) {
}

// ---- 原っぱ（第4章のスタート地点）：空と地面 ----
scene.remove(grid);                                // マス目は使わない
scene.background = new THREE.Color(0xe3f3ff);      // 空の色（地平線のあたり）
scene.fog = new THREE.Fog(0xe3f3ff, 25, 110);      // 遠くを空の色にかすませる

// 空：内側に色をぬった大きな球。上は濃い青、地平線に近いほど白っぽい
const skyGeometry = new THREE.SphereGeometry(100, 32, 16);
const skyColors = [];
const top = new THREE.Color(0x4a9be0);
const horizon = new THREE.Color(0xe3f3ff);
const position = skyGeometry.attributes.position;
for (let i = 0; i < position.count; i++) {
  const height = Math.max(0, position.getY(i) / 100);   // 0（地平線）〜 1（真上）
  const color = horizon.clone().lerp(top, Math.pow(height, 0.6));
  skyColors.push(color.r, color.g, color.b);
}
skyGeometry.setAttribute('color', new THREE.Float32BufferAttribute(skyColors, 3));
const sky = new THREE.Mesh(skyGeometry, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false }));
scene.add(sky);

// 地面：240メートル四方の緑の板（遠くは霧で空の色にかすむ）
const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(240, 240, 48, 48),
  new THREE.MeshStandardMaterial({ color: 0x79c26a, roughness: 1 })
);
ground.rotation.x = -Math.PI / 2;                  // 寝かせて床にする
scene.add(ground);

// 遠くの丘：つぶした球を、まわりにぐるりと並べる
const hillMaterial = new THREE.MeshStandardMaterial({ color: 0x5fae58, roughness: 1 });
for (let i = 0; i < 9; i++) {
  const angle = (i / 9) * Math.PI * 2 + 0.3;
  const hill = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), hillMaterial);
  const distance = 55 + (i % 3) * 12;
  hill.position.set(Math.sin(angle) * distance, 0, -Math.cos(angle) * distance);
  hill.scale.set(14 + (i % 4) * 4, 5 + (i % 3) * 2.5, 10);
  hill.lookAt(0, 0, 0);
  scene.add(hill);
}

// 雲：白い球をいくつか重ねて、空に浮かべる
const cloudMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0xaab6c2, fog: false });
for (let i = 0; i < 7; i++) {
  const angle = (i / 7) * Math.PI * 2;
  const cloud = new THREE.Group();
  for (let j = 0; j < 4; j++) {
    const puff = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), cloudMaterial);
    puff.position.set((j - 1.5) * 2.2, (j % 2) * 0.8, 0);
    puff.scale.setScalar(2 + (j % 2));
    cloud.add(puff);
  }
  cloud.position.set(Math.sin(angle) * 80, 30 + (i % 3) * 6, -Math.cos(angle) * 80);
  cloud.lookAt(0, cloud.position.y, 0);
  scene.add(cloud);
}
