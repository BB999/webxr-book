// 作品の入り口。three.js で 3D の世界を作り、Quest の VR で見られるようにする
// 作品の中身は、いちばん下の「ここから下が作品の中身」より下に書く
// AI への約束ごとは AGENTS.md（Codex 用）と CLAUDE.md（Claude 用）に書いてある
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- 3つの役者：舞台（シーン）・目（カメラ）・描く係（レンダラー） ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // 背景の色（MR では自動で透明になり、部屋が見える）

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.6, 0);                 // 目の高さ 1.6 メートル（VR の中では、Quest の頭の動きに合わせて動く）

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // 床の高さを 0 にする
document.body.appendChild(renderer.domElement);

// ---- 明かり ----
// 惑星の明かりは、下の作品の中身で設定する

// ---- Mac のブラウザで見るとき：マウスのドラッグで見回せるようにする（VR の中では使わない） ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- 「VR で遊ぶ」ボタン ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'VR で遊ぶ'));

// ---- エラーを VR の中にも出す（ログは npm run log で読める） ----
const debug = setupDebugPanel(scene, renderer);

// ---- 毎フレームくり返す：下の update() で動かして、描き直す ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // 止まっていたあとに、物が一気に動かないようにする
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // エラーが出ても止めずに描き続ける（エラーは赤い板に出る）
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- ブラウザの窓の大きさが変わったら、絵の大きさを合わせる ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== ここから下が作品の中身 ========
// 置くものは scene.add() で舞台に置く。単位はメートル。床は高さ 0、正面はマイナス z の向き
// 毎フレーム動かしたいものは、下の update() の中に書く

// 目の位置から60〜100メートル離れた全方向に、2000個の星を散りばめる
const starPositions = new Float32Array(2000 * 3);
for (let i = 0; i < 2000; i++) {
  const height = Math.random() * 2 - 1;
  const angle = Math.random() * Math.PI * 2;
  const distance = 60 + Math.random() * 40;
  const horizontal = Math.sqrt(1 - height * height);
  starPositions[i * 3] = distance * horizontal * Math.cos(angle);
  starPositions[i * 3 + 1] = 1.6 + distance * height;
  starPositions[i * 3 + 2] = distance * horizontal * Math.sin(angle);
}
// 星をまとめて描き、Questでも軽く表示する
const starGeometry = new THREE.BufferGeometry();
starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
const stars = new THREE.Points(
  starGeometry,
  new THREE.PointsMaterial({ color: 0xffffff, size: 0.15, sizeAttenuation: true, toneMapped: false }),
);
scene.add(stars);

// 暗い側にも、模様がうっすら見える程度の白い明かりを残す
scene.add(new THREE.AmbientLight(0xffffff, 0.12));
// 遠い太陽のように、左ななめ上から平行な白い光を当てる
const sun = new THREE.DirectionalLight(0xffffff, 2);
sun.position.set(-100, 101.6, 48);
sun.target.position.set(0, 1.6, -2);
scene.add(sun, sun.target);

// 画像ファイルを使わず、木星のような模様を一度だけ描く
// 細いしまを緯度ごとに色分けし、境目をノイズで波打たせる。南に大赤斑のような赤茶色のだ円を置く
const planetCanvas = document.createElement('canvas');
planetCanvas.width = 2048;
planetCanvas.height = 1024;
const planetContext = planetCanvas.getContext('2d');
const planetPixels = planetContext.createImageData(2048, 1024);

// なめらかなノイズ（球の表面の点で調べるので、つなぎ目が出ない）
const hash = (x, y, z) => {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
};
const smooth = (t) => t * t * (3 - 2 * t);
const noise = (x, y, z) => {
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
  const fx = smooth(x - ix), fy = smooth(y - iy), fz = smooth(z - iz);
  const lerp = (a, b, t) => a + (b - a) * t;
  const corner = (dx, dy, dz) => hash(ix + dx, iy + dy, iz + dz);
  return lerp(
    lerp(lerp(corner(0, 0, 0), corner(1, 0, 0), fx), lerp(corner(0, 1, 0), corner(1, 1, 0), fx), fy),
    lerp(lerp(corner(0, 0, 1), corner(1, 0, 1), fx), lerp(corner(0, 1, 1), corner(1, 1, 1), fx), fy),
    fz,
  );
};
const fbm = (x, y, z, octaves) => {
  let sum = 0, amp = 0.5, freq = 1;
  for (let i = 0; i < octaves; i++) {
    sum += amp * noise(x * freq, y * freq, z * freq);
    amp *= 0.5;
    freq *= 2;
  }
  return sum;
};

// 北から南へ、しまの上の端の緯度（度）と色
const bands = [
  [90, [138, 124, 110]], [62, [168, 148, 124]], [50, [204, 180, 146]], [44, [168, 128, 96]],
  [37, [226, 206, 172]], [30, [178, 122, 82]], [23, [236, 222, 192]], [17, [176, 104, 64]],
  [8, [242, 228, 198]], [-7, [158, 92, 56]], [-19, [236, 216, 182]], [-27, [184, 132, 92]],
  [-34, [222, 202, 168]], [-43, [172, 136, 106]], [-53, [188, 168, 142]], [-63, [138, 124, 110]],
];
const bandColor = (latDeg) => {
  let i = bands.findIndex((b, k) => k === bands.length - 1 || latDeg > bands[k + 1][0]);
  const [top, color] = bands[i];
  const next = bands[i + 1];
  // しまの下の端の近くは、次のしまの色へなめらかにつなぐ
  if (!next) return color;
  const t = Math.min(1, Math.max(0, (next[0] + 1.5 - latDeg) / 3));
  return color.map((c, k) => c + (next[1][k] - c) * smooth(t));
};

const spotLat = THREE.MathUtils.degToRad(-22);
const spotLon = Math.PI / 2; // 最初に手前を向く側
for (let y = 0; y < 1024; y++) {
  const latitude = (0.5 - (y + 0.5) / 1024) * Math.PI;
  for (let x = 0; x < 2048; x++) {
    const longitude = ((x + 0.5) / 2048) * Math.PI * 2;
    const px = Math.cos(latitude) * Math.cos(longitude);
    const py = Math.cos(latitude) * Math.sin(longitude);
    const pz = Math.sin(latitude);

    // しまの境目を波打たせる
    const warp = (fbm(px * 3, py * 3, pz * 3, 3) - 0.5) * 7 + (fbm(px * 10, py * 10, pz * 10, 2) - 0.5) * 1.2;
    let color = bandColor(THREE.MathUtils.radToDeg(latitude) + warp);

    // 横に流れる細かいすじ（南北方向に細かく、東西方向に長い）
    const streak = fbm(px * 6, py * 6, pz * 60, 3);
    color = color.map((c) => c * (0.86 + streak * 0.28));

    // 大赤斑のような、ふちのぼけた赤茶色のだ円
    let dLon = longitude - spotLon;
    dLon = Math.atan2(Math.sin(dLon), Math.cos(dLon));
    const d = Math.hypot((dLon * Math.cos(latitude)) / 0.34, (latitude - spotLat) / 0.15)
      + (fbm(px * 20, py * 20, pz * 20, 2) - 0.5) * 0.25;
    if (d < 1.5) {
      const core = 1 - smooth(Math.min(1, Math.max(0, (d - 0.55) / 0.45)));
      const ring = Math.max(0, 1 - Math.abs(d - 1.15) / 0.3);
      color = color.map((c, k) => c + ([246, 230, 206][k] - c) * ring * 0.7);
      color = color.map((c, k) => c + ([204, 102, 66][k] * (0.9 + streak * 0.2) - c) * core);
    }

    const offset = (y * 2048 + x) * 4;
    planetPixels.data[offset] = color[0];
    planetPixels.data[offset + 1] = color[1];
    planetPixels.data[offset + 2] = color[2];
    planetPixels.data[offset + 3] = 255;
  }
}
planetContext.putImageData(planetPixels, 0, 0);
const planetTexture = new THREE.CanvasTexture(planetCanvas);
planetTexture.colorSpace = THREE.SRGBColorSpace;
planetTexture.anisotropy = 8;

// 半径0.5メートルの惑星を、目の高さ・正面2メートルに置く
const planetSurface = new THREE.Mesh(
  new THREE.SphereGeometry(0.5, 64, 32),
  new THREE.MeshStandardMaterial({ map: planetTexture, roughness: 1 }),
);
// 軸のかたむきと自転を分け、かたむいた軸の向きを保つ
const planetAxis = new THREE.Group();
planetAxis.rotation.z = THREE.MathUtils.degToRad(20);
planetAxis.add(planetSurface);
// 惑星全体を親にして、表面の自転と月の公転を別々に動かす
const planet = new THREE.Group();
planet.position.set(0, 1.6, -2);
planet.add(planetAxis);
scene.add(planet);

// 惑星の中心に、自転とは別に回る、目に見えない台を置く
const moonPlatform = new THREE.Group();
planet.add(moonPlatform);

// 画像ファイルを使わず、月の模様（暗い「海」とクレーター）と、でこぼこの高さを一度だけ描く
const moonColorCanvas = document.createElement('canvas');
const moonBumpCanvas = document.createElement('canvas');
moonColorCanvas.width = moonBumpCanvas.width = 1024;
moonColorCanvas.height = moonBumpCanvas.height = 512;
const moonColorContext = moonColorCanvas.getContext('2d');
const moonBumpContext = moonBumpCanvas.getContext('2d');
const moonColorPixels = moonColorContext.createImageData(1024, 512);
const moonBumpPixels = moonBumpContext.createImageData(1024, 512);

// 毎回同じ並びになる乱数で、クレーターの場所と大きさを決める
let seed = 7;
const random = () => {
  seed = (seed * 16807) % 2147483647;
  return seed / 2147483647;
};
const craters = [];
for (let i = 0; i < 260; i++) {
  const z = random() * 2 - 1;
  const angle = random() * Math.PI * 2;
  const r = Math.sqrt(1 - z * z);
  // 小さいクレーターほど数が多くなるようにする
  const size = 0.03 + 0.17 * random() ** 3;
  craters.push({ x: r * Math.cos(angle), y: r * Math.sin(angle), z, size, near: Math.cos(size * 1.4) });
}

for (let y = 0; y < 512; y++) {
  const latitude = (0.5 - (y + 0.5) / 512) * Math.PI;
  for (let x = 0; x < 1024; x++) {
    const longitude = ((x + 0.5) / 1024) * Math.PI * 2;
    const px = Math.cos(latitude) * Math.cos(longitude);
    const py = Math.cos(latitude) * Math.sin(longitude);
    const pz = Math.sin(latitude);

    // 暗い「海」と、細かいざらつき
    const sea = smooth(Math.min(1, Math.max(0, (fbm(px * 2, py * 2, pz * 2, 4) - 0.46) / 0.2)));
    let shade = 0.78 - sea * 0.3 + (fbm(px * 30, py * 30, pz * 30, 3) - 0.5) * 0.12;
    let height = 0.5 + (fbm(px * 30, py * 30, pz * 30, 3) - 0.5) * 0.3;

    // クレーター：底はくぼんで少し暗く、ふちは盛り上がって明るい
    for (const c of craters) {
      // 遠いクレーターは、角度を計算する前に飛ばす
      const dot = px * c.x + py * c.y + pz * c.z;
      if (dot < c.near) continue;
      const d = Math.acos(Math.min(1, dot)) / c.size;
      if (d < 1) {
        height -= 0.35 * (1 - d * d);
        shade -= 0.06 * (1 - d);
      }
      const rim = Math.max(0, 1 - Math.abs(d - 1) / 0.4);
      height += 0.2 * rim;
      shade += 0.03 * rim;
    }

    const gray = Math.min(255, Math.max(0, shade * 255));
    const bump = Math.min(255, Math.max(0, height * 255));
    const offset = (y * 1024 + x) * 4;
    moonColorPixels.data[offset] = gray;
    moonColorPixels.data[offset + 1] = gray * 0.98;
    moonColorPixels.data[offset + 2] = gray * 0.95;
    moonColorPixels.data[offset + 3] = 255;
    moonBumpPixels.data[offset] = moonBumpPixels.data[offset + 1] = moonBumpPixels.data[offset + 2] = bump;
    moonBumpPixels.data[offset + 3] = 255;
  }
}
moonColorContext.putImageData(moonColorPixels, 0, 0);
moonBumpContext.putImageData(moonBumpPixels, 0, 0);
const moonTexture = new THREE.CanvasTexture(moonColorCanvas);
moonTexture.colorSpace = THREE.SRGBColorSpace;
const moonBump = new THREE.CanvasTexture(moonBumpCanvas);

// 直径20センチの月を台の子どもにして、台の中心から1メートル離す
const moon = new THREE.Mesh(
  new THREE.SphereGeometry(0.1, 64, 32),
  new THREE.MeshStandardMaterial({ map: moonTexture, bumpMap: moonBump, bumpScale: 3, roughness: 1 }),
);
moon.position.set(1, 0, 0);
moonPlatform.add(moon);

/**
 * 毎フレーム呼ばれる
 * @param {number} delta 前のフレームからの時間（秒）
 * @param {number} elapsed 始まってからの時間（秒）
 */
function update(delta, elapsed) {
  // 惑星自身の縦の軸を中心に、20秒で1回転する
  planetSurface.rotation.y = (planetSurface.rotation.y + (Math.PI * 2 / 20) * delta) % (Math.PI * 2);
  // 台を10秒で1回転させ、月を惑星のまわりに運ぶ
  moonPlatform.rotation.y = (moonPlatform.rotation.y + (Math.PI * 2 / 10) * delta) % (Math.PI * 2);
}
