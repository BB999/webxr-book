// 作品の入り口。three.js で 3D の世界を作り、Quest の VR で見られるようにする
// 作品の中身は、いちばん下の「ここから下が作品の中身」より下に書く
// AI への約束ごとは AGENTS.md（Codex 用）と CLAUDE.md（Claude 用）に書いてある
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- 3つの役者：舞台（シーン）・目（カメラ）・描く係（レンダラー） ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // 背景の色（MR では自動で透明になり、部屋が見える）

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.6, 0);                 // 目の高さ 1.6 メートル（VR の中では、Quest の頭の動きに合わせて動く）

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // 床の高さを 0 にする
document.body.appendChild(renderer.domElement);

// ---- 明かり ----
// 惑星の明かりは、下の作品の中身で設定する

// ---- Mac のブラウザで見るとき：マウスのドラッグで見回せるようにする（VR の中では使わない） ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- 「VR で遊ぶ」ボタン ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'VR で遊ぶ'));

// ---- エラーを VR の中にも出す（ログは npm run log で読める） ----
const debug = setupDebugPanel(scene, renderer);

// ---- 毎フレームくり返す：下の update() で動かして、描き直す ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // 止まっていたあとに、物が一気に動かないようにする
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // エラーが出ても止めずに描き続ける（エラーは赤い板に出る）
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- ブラウザの窓の大きさが変わったら、絵の大きさを合わせる ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== ここから下が作品の中身 ========
// 置くものは scene.add() で舞台に置く。単位はメートル。床は高さ 0、正面はマイナス z の向き
// 毎フレーム動かしたいものは、下の update() の中に書く

// 目の位置から60〜100メートル離れた全方向に、2000個の星を散りばめる
const starPositions = new Float32Array(2000 * 3);
for (let i = 0; i < 2000; i++) {
  const height = Math.random() * 2 - 1;
  const angle = Math.random() * Math.PI * 2;
  const distance = 60 + Math.random() * 40;
  const horizontal = Math.sqrt(1 - height * height);
  starPositions[i * 3] = distance * horizontal * Math.cos(angle);
  starPositions[i * 3 + 1] = 1.6 + distance * height;
  starPositions[i * 3 + 2] = distance * horizontal * Math.sin(angle);
}
// 星をまとめて描き、Questでも軽く表示する
const starGeometry = new THREE.BufferGeometry();
starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
const stars = new THREE.Points(
  starGeometry,
  new THREE.PointsMaterial({ color: 0xffffff, size: 0.15, sizeAttenuation: true, toneMapped: false }),
);
scene.add(stars);

// 暗い側にも、模様がうっすら見える程度の白い明かりを残す
scene.add(new THREE.AmbientLight(0xffffff, 0.12));
// 遠い太陽のように、左ななめ上から平行な白い光を当てる
const sun = new THREE.DirectionalLight(0xffffff, 2);
sun.position.set(-100, 101.6, 48);
sun.target.position.set(0, 1.6, -2);
scene.add(sun, sun.target);

// 画像ファイルを使わず、横じまと丸い模様を一度だけ描く
const planetCanvas = document.createElement('canvas');
planetCanvas.width = 1024;
planetCanvas.height = 512;
const planetContext = planetCanvas.getContext('2d');
const planetPixels = planetContext.createImageData(1024, 512);
const stripeColors = [[244, 190, 135], [161, 105, 65]];
for (let y = 0; y < 512; y++) {
  const latitude = (0.5 - (y + 0.5) / 512) * Math.PI;
  const stripeColor = stripeColors[Math.floor(y / 43) % 2];
  for (let x = 0; x < 1024; x++) {
    const longitude = ((x + 0.5) / 1024) * Math.PI * 2;
    // 手前を向いた球面に、半径約20度の丸い模様を1つ描く
    const inSpot = Math.cos(latitude) * Math.sin(longitude) > Math.cos(0.36);
    const color = inSpot ? [83, 43, 25] : stripeColor;
    const offset = (y * 1024 + x) * 4;
    planetPixels.data[offset] = color[0];
    planetPixels.data[offset + 1] = color[1];
    planetPixels.data[offset + 2] = color[2];
    planetPixels.data[offset + 3] = 255;
  }
}
planetContext.putImageData(planetPixels, 0, 0);
const planetTexture = new THREE.CanvasTexture(planetCanvas);
planetTexture.colorSpace = THREE.SRGBColorSpace;

// 半径0.5メートルの惑星を、目の高さ・正面2メートルに置く
const planetSurface = new THREE.Mesh(
  new THREE.SphereGeometry(0.5, 64, 32),
  new THREE.MeshStandardMaterial({ map: planetTexture, roughness: 1 }),
);
// 軸のかたむきと自転を分け、かたむいた軸の向きを保つ
const planetAxis = new THREE.Group();
planetAxis.rotation.z = THREE.MathUtils.degToRad(20);
planetAxis.add(planetSurface);
// 惑星全体を親にして、表面の自転と月の公転を別々に動かす
const planet = new THREE.Group();
planet.position.set(0, 1.6, -2);
planet.add(planetAxis);
scene.add(planet);

// 惑星の中心に、自転とは別に回る、目に見えない台を置く
const moonPlatform = new THREE.Group();
planet.add(moonPlatform);

// 直径20センチの月を台の子どもにして、台の中心から1メートル離す
const moon = new THREE.Mesh(
  new THREE.SphereGeometry(0.1, 32, 16),
  new THREE.MeshStandardMaterial({ color: 0x999999, roughness: 1 }),
);
moon.position.set(1, 0, 0);
moonPlatform.add(moon);

/**
 * 毎フレーム呼ばれる
 * @param {number} delta 前のフレームからの時間（秒）
 * @param {number} elapsed 始まってからの時間（秒）
 */
function update(delta, elapsed) {
  // 惑星自身の縦の軸を中心に、20秒で1回転する
  planetSurface.rotation.y = (planetSurface.rotation.y + (Math.PI * 2 / 20) * delta) % (Math.PI * 2);
  // 台を10秒で1回転させ、月を惑星のまわりに運ぶ
  moonPlatform.rotation.y = (moonPlatform.rotation.y + (Math.PI * 2 / 10) * delta) % (Math.PI * 2);
}
