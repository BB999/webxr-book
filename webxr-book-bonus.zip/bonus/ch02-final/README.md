# ch02-final

『野良猫でもわかるWebXRの教科書』の第2章の完成版です。色・大きさ・位置を変えた立方体が並びます。

この完成版は、本のプロンプトを AI に打って作ったものです。AI は毎回少しちがうプログラムを書くので、あなたの作品とちがっていても大丈夫です。

## 使い方

1. このフォルダーを VS Code で開きます
2. VS Code のターミナルで `npm install` を実行します（最初の1回だけ）
3. `npm run dev` を実行します。最初の1回は、Mac のパスワードを聞かれます
4. 表示された `https://192.168.…:5173` のアドレスを、Quest のブラウザで開きます

くわしくは、本の第1章を見てください。

## 入っているもの

- three.js 0.186.1 と Vite（開発サーバー）。mkcert で HTTPS にして、同じ Wi-Fi の Quest から開けます
- 「VR で遊ぶ」ボタン（MR のボタンも足せます）
- エラーを VR の中に出す赤い板
- Quest のブラウザのログを Mac で読むスクリプト（`npm run log`）
- AI への約束ごと（Claude 用の `CLAUDE.md`、Codex 用の `AGENTS.md`。中身は同じ）
- AI が、セーブポイント（git）を作るときに、毎回許可を聞かなくてよい設定（Claude 用の `.claude/settings.json`、Codex 用の `.codex/rules/default.rules`）。`git push` などの危ない操作は、させない設定にしています。ほかのコマンドは、AI が実行する前に聞いてきます
