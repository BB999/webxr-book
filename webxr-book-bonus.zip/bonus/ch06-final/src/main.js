// 作品の入り口。three.js で 3D の世界を作り、Quest の VR で見られるようにする
// 作品の中身は、いちばん下の「ここから下が作品の中身」より下に書く
// AI への約束ごとは AGENTS.md（Codex 用）と CLAUDE.md（Claude 用）に書いてある
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- 3つの役者：舞台（シーン）・目（カメラ）・描く係（レンダラー） ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // 背景の色（MR では自動で透明になり、部屋が見える）

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.6, 0);                 // 目の高さ 1.6 メートル（VR の中では、Quest の頭の動きに合わせて動く）

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // 床の高さを 0 にする
document.body.appendChild(renderer.domElement);

// ---- 明かり ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // 全体をまんべんなく照らす光
const sun = new THREE.DirectionalLight(0xffffff, 2);            // ひとつの向きから当たる光
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- 床のマス目（1マス 1 メートル）。大きさの目安にする。MR では本物の床が見えるので隠す ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- Mac のブラウザで見るとき：マウスのドラッグで見回せるようにする（VR の中では使わない） ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- 「MR で遊ぶ」ボタン（部屋が見える。背景は自動で透明になる） ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-ar', 'MR で遊ぶ'));

// ---- エラーを VR の中にも出す（ログは npm run log で読める） ----
const debug = setupDebugPanel(scene, renderer);

// ---- 毎フレームくり返す：下の update() で動かして、描き直す ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // 止まっていたあとに、物が一気に動かないようにする
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // エラーが出ても止めずに描き続ける（エラーは赤い板に出る）
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- ブラウザの窓の大きさが変わったら、絵の大きさを合わせる ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== ここから下が作品の中身 ========
// 置くものは scene.add() で舞台に置く。単位はメートル。床は高さ 0、正面はマイナス z の向き
// 毎フレーム動かしたいものは、下の update() の中に書く

import { RoomCollisions } from './room-collisions.js';
import { TargetGame } from './target-game.js';
import { HandBallInput } from './hand-ball-input.js';

const roomCollisions = new RoomCollisions();
const movementStart = new THREE.Vector3();
const ballHome = new THREE.Vector3(0, 1, -0.5);
const ball = new THREE.Mesh(
  new THREE.SphereGeometry(0.075, 24, 16),
  new THREE.MeshStandardMaterial({ color: 0xff0000 }),
);
ball.position.copy(ballHome);
scene.add(ball);

const ballVelocity = new THREE.Vector3();
const previousBallPosition = new THREE.Vector3();
const currentBallPosition = new THREE.Vector3();
const gripPosition = new THREE.Vector3();
let heldBy = null;
let ballReleased = false;
const ballRadius = 0.075;
const rollingAxis = new THREE.Vector3();
const targetGame = new TargetGame(scene, camera, roomCollisions);

function resetBall() {
  scene.attach(ball);
  heldBy = null;
  ballReleased = false;
  ball.position.copy(ballHome);
  ball.quaternion.identity();
  ballVelocity.set(0, 0, 0);
}

// 手でもコントローラーでも、同じ近さの判定と投げる速さを使う。
function grabBall(holder) {
  if (heldBy || !holder.visible) return;
  holder.getWorldPosition(gripPosition);
  ball.getWorldPosition(currentBallPosition);
  // ボールの表面から約5センチ以内ならつかめる。
  if (gripPosition.distanceTo(currentBallPosition) > 0.125) return;
  heldBy = holder;
  holder.attach(ball);
  previousBallPosition.copy(currentBallPosition);
  ballVelocity.set(0, 0, 0);
}

function releaseBall(holder) {
  if (heldBy !== holder) return;
  // 親を舞台に戻しても位置は保ち、直前の動く速さで飛ばす。
  scene.attach(ball);
  heldBy = null;
  ballReleased = true;
}

const handInput = new HandBallInput(scene, renderer.xr, grabBall, releaseBall, (holder) => {
  if (heldBy === holder) resetBall();
});

// 左右どちらも、光線の先ではなくコントローラー本体の近くでつかむ。
for (let index = 0; index < 2; index++) {
  const controller = renderer.xr.getController(index);
  const grip = renderer.xr.getControllerGrip(index);
  scene.add(controller, grip);

  controller.addEventListener('squeezestart', (event) => {
    if (!event.data?.hand) grabBall(grip);
  });

  controller.addEventListener('squeezeend', () => releaseBall(grip));
  controller.addEventListener('disconnected', () => {
    if (heldBy === grip) resetBall();
  });
}

renderer.xr.addEventListener('sessionend', resetBall);
renderer.xr.addEventListener('sessionend', () => handInput.clear());
renderer.xr.addEventListener('sessionend', () => roomCollisions.clear());
renderer.xr.addEventListener('sessionstart', () => targetGame.beginSession());
renderer.xr.addEventListener('sessionend', () => targetGame.endSession());

/**
 * 毎フレーム呼ばれる
 * @param {number} delta 前のフレームからの時間（秒）
 * @param {number} elapsed 始まってからの時間（秒）
 */
function update(delta, elapsed) {
  const frame = renderer.xr.getFrame();
  const referenceSpace = renderer.xr.getReferenceSpace();
  roomCollisions.update(frame, referenceSpace);
  handInput.update();
  ball.getWorldPosition(currentBallPosition);
  targetGame.update(delta, renderer.xr.isPresenting ? renderer.xr.getCamera() : camera,
    roomCollisions.planes, currentBallPosition, ballRadius, frame, referenceSpace);
  if (heldBy) {
    if (!heldBy.visible) {
      resetBall();
      return;
    }
    ball.getWorldPosition(currentBallPosition);
    if (delta > 0) {
      ballVelocity.copy(currentBallPosition).sub(previousBallPosition).divideScalar(delta);
    }
    previousBallPosition.copy(currentBallPosition);
  } else if (ballReleased) {
    // 時間を細かく分け、描画の間隔が長くても床での跳ね返りを安定させる。
    const steps = Math.max(1, Math.ceil(delta / (1 / 120)));
    const step = delta / steps;
    for (let i = 0; i < steps; i++) {
      movementStart.copy(ball.position);
      // 重力で下向きに加速し、放物線を描いて落ちる。
      ball.position.addScaledVector(ballVelocity, step);
      ball.position.y -= 0.5 * 9.8 * step * step;
      ballVelocity.y -= 9.8 * step;

      roomCollisions.resolve(movementStart, ball.position, ballVelocity, ballRadius, step);

      // 半径ぶんの高さで床に触れる。跳ねるたびに勢いを減らす。
      if (ball.position.y <= ballRadius) {
        ball.position.y = ballRadius;
        if (ballVelocity.y < 0) {
          ballVelocity.y = -ballVelocity.y * 0.55;
          if (ballVelocity.y < 0.35) ballVelocity.y = 0;
        }

        if (ballVelocity.y === 0) {
          // 小さな跳ね返りがなくなったら、床との摩擦で転がる速さを減らす。
          const speed = Math.hypot(ballVelocity.x, ballVelocity.z);
          const nextSpeed = Math.max(0, speed - 0.7 * step);
          if (speed > 0) {
            rollingAxis.set(ballVelocity.z, 0, -ballVelocity.x).normalize();
            ball.rotateOnWorldAxis(rollingAxis, speed * step / ballRadius);
            ballVelocity.x *= nextSpeed / speed;
            ballVelocity.z *= nextSpeed / speed;
          }
        }
      }
    }
    if (ball.position.lengthSq() > 5 * 5) resetBall();
  }
  handInput.finishFrame();
}
