// 検出した部屋の面とボールの移動経路を調べ、見えない面で跳ね返す。
import * as THREE from 'three';

const SEPARATION = 0.0001;

// 面の座標では高さが0なので、輪郭の内側かどうかは横と奥行きで調べる。
function insidePolygon(x, z, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const a = polygon[j];
    const b = polygon[i];
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const lengthSq = dx * dx + dz * dz;
    if (lengthSq > 0) {
      const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (z - a.z) * dz) / lengthSq));
      if ((x - a.x - t * dx) ** 2 + (z - a.z - t * dz) ** 2 < 1e-10) return true;
    }
    if ((a.z > z) !== (b.z > z) && x < a.x + (z - a.z) * dx / dz) inside = !inside;
  }
  return inside;
}

export class RoomCollisions {
  constructor() {
    this.planes = new Map();
    this.extraPlanes = [];
    this.start = new THREE.Vector3();
    this.end = new THREE.Vector3();
    this.localStart = new THREE.Vector3();
    this.localEnd = new THREE.Vector3();
    this.normal = new THREE.Vector3();
    this.remainder = new THREE.Vector3();
  }

  *collisionPlanes() {
    yield* this.planes.values();
    yield* this.extraPlanes;
  }

  clear() {
    // 描画用の物は作らない。セッション終了時は面の情報だけを片づける。
    this.planes.clear();
  }

  update(frame, referenceSpace) {
    const detected = frame?.detectedPlanes;
    if (!detected || !referenceSpace) {
      this.clear();
      return;
    }
    for (const plane of this.planes.keys()) {
      if (!detected.has(plane)) this.planes.delete(plane);
    }
    for (const plane of detected) {
      const pose = frame.getPose(plane.planeSpace, referenceSpace);
      if (!pose || plane.polygon.length < 3) {
        this.planes.delete(plane);
        continue;
      }
      let data = this.planes.get(plane);
      if (!data) {
        data = { matrix: new THREE.Matrix4(), inverse: new THREE.Matrix4() };
        this.planes.set(plane, data);
      }
      // 位置・向きは輪郭の更新時刻とは別に、毎フレーム更新する。
      data.matrix.fromArray(pose.transform.matrix);
      data.inverse.copy(data.matrix).invert();
      data.polygon = plane.polygon;
    }
  }

  resolve(previousPosition, position, velocity, radius, delta) {
    this.start.copy(previousPosition);
    this.end.copy(position);
    // 同じ移動中に壁から別の壁へ跳ね返る場合も、近い衝突から順に調べる。
    for (let bounce = 0; bounce < 8; bounce++) {
      let nearest = Infinity;
      let hitPlane = null;
      let hitSide = 1;
      let hitHeight = 0;
      for (const data of this.collisionPlanes()) {
        this.localStart.copy(this.start).applyMatrix4(data.inverse);
        this.localEnd.copy(this.end).applyMatrix4(data.inverse);
        const side = this.localStart.y >= 0 ? 1 : -1;
        const from = this.localStart.y * side;
        const to = this.localEnd.y * side;
        if (to >= from || to > radius) continue;
        // 中心の移動線を半径ぶんずらし、ボールの表面が面に触れる時刻を求める。
        const t = Math.max(0, (from - radius) / (from - to));
        if (t > 1 || t >= nearest) continue;
        const x = THREE.MathUtils.lerp(this.localStart.x, this.localEnd.x, t);
        const z = THREE.MathUtils.lerp(this.localStart.z, this.localEnd.z, t);
        if (data.contains ? !data.contains(x, z, radius) : !insidePolygon(x, z, data.polygon)) continue;
        nearest = t;
        hitPlane = data;
        hitSide = side;
        hitHeight = THREE.MathUtils.lerp(from, to, t);
      }
      if (!hitPlane) {
        position.copy(this.end);
        return;
      }

      this.normal.set(0, hitSide, 0).transformDirection(hitPlane.matrix);
      this.remainder.copy(this.end).sub(this.start).multiplyScalar(1 - nearest);
      this.start.lerp(this.end, nearest);
      this.start.addScaledVector(this.normal, radius - hitHeight + SEPARATION);

      const incomingSpeed = velocity.dot(this.normal);
      if (incomingSpeed < 0) {
        hitPlane.onHit?.();
        const reboundSpeed = -incomingSpeed * 0.55;
        // 床や机では小さな跳ね返りを止め、以前の床と同じ摩擦で減速する。
        const resting = this.normal.y > 0.5 && reboundSpeed < 0.35;
        velocity.addScaledVector(this.normal, (resting ? 0 : reboundSpeed) - incomingSpeed);
        const normalMovement = this.remainder.dot(this.normal);
        if (normalMovement < 0) {
          this.remainder.addScaledVector(this.normal, -(resting ? 1 : 1.55) * normalMovement);
        }
        if (resting) {
          const speed = velocity.length();
          const factor = speed > 0 ? Math.max(0, speed - 0.7 * delta) / speed : 0;
          velocity.multiplyScalar(factor);
          this.remainder.multiplyScalar(factor);
        }
      }
      this.end.copy(this.start).add(this.remainder);
    }
    // 狭い隙間などで何度も衝突したら、最後の接触位置で止めてすり抜けを防ぐ。
    position.copy(this.start);
    velocity.set(0, 0, 0);
  }
}
