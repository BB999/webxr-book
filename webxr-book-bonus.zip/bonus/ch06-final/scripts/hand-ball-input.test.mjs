// 手のつまみ、放す直前の速さ、手が見失われたときの処理を確認する。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import * as THREE from 'three';
import { HandBallInput, palmFacesUp } from '../src/hand-ball-input.js';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

function makeHand() {
  const hand = new THREE.Group();
  hand.joints = {};
  hand.position.set(0, 1, -0.35);
  for (const [name, position] of [
    ['wrist', [0, 0, 0]],
    ['index-finger-metacarpal', [-0.03, 0, -0.07]],
    ['pinky-finger-metacarpal', [0.03, 0, -0.07]],
    ['thumb-tip', [-0.01, 0, -0.15]],
    ['index-finger-tip', [0.01, 0, -0.15]],
  ]) {
    const joint = new THREE.Group();
    joint.position.fromArray(position);
    hand.joints[name] = joint;
    hand.add(joint);
  }
  return hand;
}

function setup() {
  const scene = new THREE.Scene();
  const ball = new THREE.Mesh(new THREE.SphereGeometry(0.075), new THREE.MeshBasicMaterial());
  ball.position.set(0, 1, -0.5);
  scene.add(ball);
  const hands = [makeHand(), makeHand()];
  const xr = { getHand: (i) => hands[i], getFrame: () => null, getReferenceSpace: () => null, isPresenting: false };
  const state = {
    scene, ball, heldBy: null, ballReleased: false, ballRadius: 0.075,
    ballHome: ball.position.clone(), ballVelocity: new THREE.Vector3(),
    gripPosition: new THREE.Vector3(), previousBallPosition: new THREE.Vector3(),
    currentBallPosition: new THREE.Vector3(), movementStart: new THREE.Vector3(),
    rollingAxis: new THREE.Vector3(), renderer: { xr }, camera: new THREE.PerspectiveCamera(),
    roomCollisions: { planes: new Map(), update() {}, resolve() {} },
    targetGame: { update() {} },
  };
  vm.createContext(state);
  vm.runInContext(main.slice(main.indexOf('function resetBall()'), main.indexOf('const handInput =')), state);
  const input = new HandBallInput(scene, xr, state.grabBall, state.releaseBall, (anchor) => {
    if (state.heldBy === anchor) state.resetBall();
  });
  state.handInput = input;
  vm.runInContext(main.slice(main.indexOf('function update(delta, elapsed)')), state);
  hands[0].dispatchEvent({ type: 'connected', data: { hand: {}, handedness: 'right' } });
  return { state, hands, input };
}

test('近くのボールをつまみ、離すフレームの動きも投げる勢いに使う', () => {
  const { state, hands, input } = setup();
  hands[0].dispatchEvent({ type: 'pinchstart' });
  state.update(0.02, 0);
  assert.equal(state.heldBy, input.hands[0].anchor);
  hands[0].position.x += 0.01;
  state.update(0.02, 0);
  hands[0].position.x += 0.04;
  hands[0].dispatchEvent({ type: 'pinchend' });
  state.update(0.02, 0);
  assert.equal(state.heldBy, null);
  assert.equal(state.ball.parent, state.scene);
  assert.equal(state.ballReleased, true);
  assert.ok(Math.abs(state.ballVelocity.x - 2) < 1e-8);
});

test('遠くのつまみと手のひらが上向きのつまみではつかまない', () => {
  const { state, hands } = setup();
  hands[0].position.x = 1;
  hands[0].dispatchEvent({ type: 'pinchstart' });
  state.update(0.02, 0);
  assert.equal(state.heldBy, null);
  hands[0].position.x = 0;
  hands[0].rotation.z = Math.PI;
  // 回転後も指先の中点をボールに合わせる。
  hands[0].dispatchEvent({ type: 'pinchstart' });
  state.update(0.02, 0);
  assert.equal(state.heldBy, null);
});

test('左右の手のひらの向きを判別し、向きがわからないときはつかまない', () => {
  const right = makeHand();
  assert.equal(palmFacesUp(right, 'right'), false);
  right.rotation.z = Math.PI;
  assert.equal(palmFacesUp(right, 'right'), true);
  const left = makeHand();
  left.joints['index-finger-metacarpal'].position.x *= -1;
  left.joints['pinky-finger-metacarpal'].position.x *= -1;
  assert.equal(palmFacesUp(left, 'left'), false);
  left.rotation.z = Math.PI;
  assert.equal(palmFacesUp(left, 'left'), true);
  left.joints.wrist.visible = false;
  assert.equal(palmFacesUp(left, 'left'), true);
});

test('指の玉は追跡できる関節だけに表示し、再接続しても増えない', () => {
  const { hands, input } = setup();
  input.update();
  const markers = input.hands[0].markers;
  assert.equal(markers.count, 5);
  hands[0].joints['pinky-finger-metacarpal'].visible = false;
  input.update();
  assert.equal(markers.count, 4);
  const children = hands[0].children.length;
  hands[0].dispatchEvent({ type: 'disconnected' });
  assert.equal(markers.count, 0);
  hands[0].dispatchEvent({ type: 'connected', data: { hand: {}, handedness: 'right' } });
  input.update();
  assert.equal(hands[0].children.length, children);
});

test('つかんだ手や指先を見失ったら、誤って投げずにボールを戻す', () => {
  for (const lost of ['hand', 'tip', 'disconnected']) {
    const { state, hands } = setup();
    hands[0].dispatchEvent({ type: 'pinchstart' });
    state.update(0.02, 0);
    assert.ok(state.heldBy);
    if (lost === 'hand') hands[0].visible = false;
    if (lost === 'tip') hands[0].joints['thumb-tip'].visible = false;
    if (lost === 'disconnected') hands[0].dispatchEvent({ type: 'disconnected' });
    state.update(0.02, 0);
    assert.equal(state.heldBy, null);
    assert.equal(state.ballReleased, false);
    assert.equal(state.ballVelocity.length(), 0);
  }
});

test('コントローラーでつかんだボールを、別の手が奪ったり放したりしない', () => {
  const { state, hands } = setup();
  const grip = new THREE.Group();
  grip.position.copy(state.ball.position);
  state.scene.add(grip);
  state.grabBall(grip);
  assert.equal(state.heldBy, grip);
  hands[0].dispatchEvent({ type: 'pinchstart' });
  state.update(0.02, 0);
  hands[0].dispatchEvent({ type: 'pinchend' });
  state.update(0.02, 0);
  assert.equal(state.heldBy, grip);
  state.releaseBall(grip);
  assert.equal(state.heldBy, null);
  assert.equal(state.ballReleased, true);
});
