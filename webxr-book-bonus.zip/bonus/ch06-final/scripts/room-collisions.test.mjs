// 実機なしで、速いボール・面の輪郭・机での停止を確認する。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { RoomCollisions } from '../src/room-collisions.js';

function planeAt(matrix, polygon = [
  { x: -2, z: -2 }, { x: 2, z: -2 }, { x: 2, z: 2 }, { x: -2, z: 2 },
]) {
  return { planeSpace: {}, polygon, matrix };
}

function frameFor(planes) {
  return {
    detectedPlanes: new Set(planes),
    getPose(space) {
      const plane = planes.find((item) => item.planeSpace === space);
      return { transform: { matrix: plane.matrix.elements } };
    },
  };
}

function roomWith(planes) {
  const room = new RoomCollisions();
  room.update(frameFor(planes), {});
  return room;
}

const wallMatrix = new THREE.Matrix4().makeRotationZ(Math.PI / 2);

test('速いボールが壁を横切っても両側から跳ね返る', () => {
  const room = roomWith([planeAt(wallMatrix)]);
  for (const side of [-1, 1]) {
    const start = new THREE.Vector3(side, 1, 0);
    const end = new THREE.Vector3(-side * 3, 1, 0);
    const velocity = new THREE.Vector3(-side * 100, 0, 0);
    room.resolve(start, end, velocity, 0.075, 0.04);
    assert.ok(end.x * side >= 0.075);
    assert.ok(Math.abs(velocity.x - side * 55) < 1e-8);
  }
});

test('面の外側と、面まで届かない移動は跳ね返らない', () => {
  const room = roomWith([planeAt(wallMatrix)]);
  for (const [start, end] of [
    [new THREE.Vector3(1, 1, 3), new THREE.Vector3(-3, 1, 3)],
    [new THREE.Vector3(1, 1, 0), new THREE.Vector3(0.2, 1, 0)],
  ]) {
    const expected = end.clone();
    const velocity = new THREE.Vector3(-100, 0, 0);
    room.resolve(start, end, velocity, 0.075, 0.04);
    assert.ok(end.distanceTo(expected) < 1e-10);
    assert.equal(velocity.x, -100);
  }
});

test('複数の面は登録順によらず最初に当たる面で跳ね返る', () => {
  const farther = planeAt(wallMatrix.clone().setPosition(-1, 0, 0));
  const nearer = planeAt(wallMatrix);
  const room = roomWith([farther, nearer]);
  const end = new THREE.Vector3(-3, 1, 0);
  const velocity = new THREE.Vector3(-100, 0, 0);
  room.resolve(new THREE.Vector3(1, 1, 0), end, velocity, 0.075, 0.04);
  assert.ok(end.x > 0.075);
  assert.ok(velocity.x > 0);
});

test('机で跳ね、重力が続いても沈まずに減速して止まる', () => {
  const room = roomWith([planeAt(new THREE.Matrix4().makeTranslation(0, 0.8, 0))]);
  const position = new THREE.Vector3(0, 1.2, 0);
  const velocity = new THREE.Vector3(0.3, 0, 0);
  let bounced = false;
  const delta = 1 / 144;
  for (let i = 0; i < 1440; i++) {
    const start = position.clone();
    const oldY = velocity.y;
    position.addScaledVector(velocity, delta);
    position.y -= 0.5 * 9.8 * delta * delta;
    velocity.y -= 9.8 * delta;
    room.resolve(start, position, velocity, 0.075, delta);
    assert.ok(position.y >= 0.875 - 1e-8);
    if (oldY < 0 && velocity.y > 0) bounced = true;
  }
  assert.ok(bounced);
  assert.ok(Math.abs(position.y - 0.875) < 0.001);
  assert.equal(velocity.length(), 0);
});

test('検出後の面の移動・輪郭の変更と、面の消失を反映する', () => {
  const plane = planeAt(wallMatrix.clone());
  const room = roomWith([plane]);
  plane.matrix.setPosition(0.5, 0, 0);
  plane.polygon = [{ x: -0.1, z: -0.1 }, { x: 0.1, z: -0.1 }, { x: 0, z: 0.1 }];
  room.update(frameFor([plane]), {});
  const data = room.planes.get(plane);
  assert.equal(data.matrix.elements[12], 0.5);
  assert.equal(data.polygon, plane.polygon);
  room.update(frameFor([]), {});
  assert.equal(room.planes.size, 0);
  room.update(frameFor([plane]), {});
  room.update(null, null);
  assert.equal(room.planes.size, 0);
});

test('面の姿勢が取得できない間は衝突に使わない', () => {
  const plane = planeAt(wallMatrix);
  const room = roomWith([plane]);
  room.update({ detectedPlanes: new Set([plane]), getPose: () => null }, {});
  assert.equal(room.planes.size, 0);
});
