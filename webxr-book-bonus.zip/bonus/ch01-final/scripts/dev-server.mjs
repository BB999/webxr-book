// 開発サーバー（vite）を裏で動かす・止める・ようすを見るスクリプト（npm run start / stop / status）
// AI の会話が終わっても止まらないように、別のプロセスとして起動する。出力は dev.log に書く
import { spawn, execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PORT = 5173;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const logFile = path.join(root, 'dev.log');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 5173 番で待ち受けているプロセスの番号（前の章の開発サーバーも含む）
function listeners() {
  try {
    return execFileSync('lsof', ['-ti', `tcp:${PORT}`, '-sTCP:LISTEN'], { encoding: 'utf8' }).split('\n').filter(Boolean).map(Number);
  } catch {
    return [];
  }
}

// Quest から開くアドレス（Mac の Wi-Fi の IP アドレス）
function addresses() {
  const list = [`https://localhost:${PORT}/`];
  for (const nets of Object.values(os.networkInterfaces())) {
    for (const n of nets ?? []) if (n.family === 'IPv4' && !n.internal) list.push(`https://${n.address}:${PORT}/`);
  }
  return list;
}

function printAddresses() {
  const [local, ...network] = addresses();
  for (const a of network) console.log(`  Quest から開くアドレス: ${a}`);
  console.log(`  Mac のブラウザで開くアドレス: ${local}`);
}

async function stop() {
  const pids = listeners();
  for (const pid of pids) {
    try { process.kill(pid, 'SIGTERM'); } catch {}
  }
  for (let i = 0; i < 50 && listeners().length; i++) await sleep(100);
  return pids.length > 0;
}

async function start() {
  if (await stop()) console.log('前に動いていた開発サーバーを止めました');
  const out = fs.openSync(logFile, 'w');
  const vite = path.join(root, 'node_modules', 'vite', 'bin', 'vite.js');
  const child = spawn(process.execPath, [vite], { cwd: root, detached: true, stdio: ['ignore', out, out], env: { ...process.env, NO_COLOR: '1' } });
  child.unref();
  // 起動の知らせ（Network: …）が dev.log に出るまで待つ
  for (let i = 0; i < 150; i++) {
    await sleep(100);
    const log = fs.readFileSync(logFile, 'utf8');
    if (/Network:/.test(log) && listeners().length) {
      console.log('✔ 開発サーバーを動かしました（出力は dev.log）');
      printAddresses();
      process.exit(0);
    }
    if (child.exitCode !== null) break;
  }
  // 証明書（HTTPS の鍵）の元は、最初の1回だけ Mac のパスワードを聞いて登録する。裏で動かしているとパスワードを聞けない
  if (/a terminal is required to read the password/.test(fs.readFileSync(logFile, 'utf8'))) {
    console.log('✖ 証明書の準備に Mac のパスワードが要ります。作る人に、ターミナルで npm run dev を1回実行してパスワードを入れ、アドレスが出たら control + C で止めてもらってください（本の 1-5）');
    process.exit(1);
  }
  console.log('✖ 開発サーバーが動きませんでした。dev.log の最後:');
  console.log(fs.readFileSync(logFile, 'utf8').split('\n').slice(-20).join('\n'));
  process.exit(1);
}

const command = process.argv[2];
if (command === 'start') {
  await start();
} else if (command === 'stop') {
  console.log((await stop()) ? '✔ 開発サーバーを止めました' : '開発サーバーは動いていませんでした');
} else if (command === 'status') {
  if (listeners().length) {
    console.log('✔ 開発サーバーは動いています（出力は dev.log）');
    printAddresses();
  } else {
    console.log('開発サーバーは止まっています（npm run start で動かせます）');
  }
} else {
  console.log('使い方: node scripts/dev-server.mjs start | stop | status');
  process.exit(1);
}
