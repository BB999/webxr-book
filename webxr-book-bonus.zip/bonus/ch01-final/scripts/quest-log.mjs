// Quest のブラウザのログ（console.log やエラー）を、Mac のターミナルに出す
// 使い方:
//   npm run log                   … これまでにたまったログを出してから、20秒間、新しいログを待つ
//   npm run log -- --seconds 60   … 新しいログを60秒間待つ
//   npm run log -- --reload       … ページを読み込み直して、最初からのログを見る（VR / MR の中にいるときは、外に出る）
//   npm run log -- --list         … Quest のブラウザで開いているページの一覧を出す
//   npm run log -- --url 文字     … アドレスにこの文字を含むページだけを見る（既定は、5173 番の HTTPS のページ）
// しくみ: adb で、Quest のブラウザの「調べる窓口（DevTools）」を Mac につなぎ、ログを受け取る
// 注意: Quest のブラウザの console.log は、adb logcat には出てこない。このスクリプトで読む
import { execFileSync } from 'node:child_process';

const args = process.argv.slice(2);
const has = (name) => args.includes(name);
const value = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] ? args[i + 1] : fallback;
};
const seconds = Number(value('--seconds', 20));
const urlFilter = value('--url', null);
const PORT = 9222;

const fail = (message) => {
  console.log(`✖ ${message}`);
  process.exit(1);
};
const adb = (...a) => execFileSync('adb', a, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
// ページが出した文字から、ターミナルの表示を乱す制御文字を取りのぞく（改行とタブは残す）
const clean = (text) => String(text).replace(/[\x00-\x08\x0b-\x1f\x7f-\x9f]/g, '');
const isDevServerPage = (url) => {
  try {
    const { protocol, port } = new URL(url);
    return protocol === 'https:' && port === '5173';
  } catch {
    return false;
  }
};

// 1. adb があるか、Quest がつながっているか
try {
  adb('version');
} catch {
  fail('adb が見つかりません。AI に「adb（Android Platform Tools）を Homebrew で入れてください」と頼んでください。');
}
const devices = adb('devices')
  .split('\n')
  .slice(1)
  .map((line) => line.trim().split(/\s+/))
  .filter(([id, state]) => id && state);
if (devices.some(([, state]) => state === 'unauthorized')) {
  fail('Quest が「USB デバッグを許可しますか？」の返事を待っています。Quest をかぶって「許可」を押してください。');
}
const ready = devices.filter(([, state]) => state === 'device').map(([id]) => id);
if (!ready.length) {
  fail('Quest が見つかりません。USB ケーブルでつないでください（本の 1-7）。Wi-Fi でつないでいたときは、Quest の電源を入れ直すと切れます。');
}
const device = value('--device', ready[0]);

// 2. Quest のブラウザの窓口を、Mac の 9222 番につなぐ
adb('-s', device, 'forward', `tcp:${PORT}`, 'localabstract:chrome_devtools_remote');
// 終わるときに、つないだ窓口を閉じる（開いたままだと、Mac のほかのプログラムからもブラウザを操作できてしまう）
process.on('exit', () => {
  try {
    adb('-s', device, 'forward', '--remove', `tcp:${PORT}`);
  } catch {}
});
process.on('SIGINT', () => process.exit(130));
process.on('SIGTERM', () => process.exit(143));
let pages;
try {
  pages = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
} catch {
  fail('Quest のブラウザにつながりませんでした。Quest でブラウザを開いてから、もう一度試してください。');
}
pages = pages.filter((p) => p.type === 'page');
if (has('--list')) {
  pages.forEach((p) => console.log(clean(`${p.title}  ${p.url}`)));
  process.exit(0);
}
const targets = pages.filter((p) => (urlFilter ? p.url.includes(urlFilter) : isDevServerPage(p.url)));
if (!targets.length) {
  fail(`${urlFilter ? `アドレスに「${urlFilter}」を含むページ` : '開発サーバー（5173 番）のページ'}が、Quest のブラウザで開かれていません。開いているページ:\n` +
    pages.map((p) => clean(`  ${p.url}`)).join('\n'));
}

// 3. ログを受け取って、読みやすい形で出す
let errors = 0;
let warnings = 0;
let lastLine = '';
let repeats = 0;
const stamp = (ms) => new Date(ms).toTimeString().slice(0, 8);
// 同じものが続いたら、1行にまとめる（毎フレーム出るエラーで、画面が埋まらないように）
const flushRepeats = () => {
  if (repeats) console.log(`  （同じものが、あと ${repeats} 回）`);
  repeats = 0;
};
const print = (level, text, where, ms = Date.now(), count = 1) => {
  const mark = level === 'error' ? '✖ エラー' : level === 'warning' || level === 'warn' ? '△ 注意' : '・';
  const line = clean(`${mark} ${text}${where ? `  (${where})` : ''}`);
  if (line === lastLine) {
    repeats++;
    return;
  }
  flushRepeats();
  lastLine = line;
  if (level === 'error') errors++;
  if (level === 'warning' || level === 'warn') warnings++;
  console.log(`[${stamp(ms)}] ${line}${count > 1 ? `  （${count} 回）` : ''}`);
};
const describe = (remote) =>
  remote.value !== undefined ? (typeof remote.value === 'string' ? remote.value : JSON.stringify(remote.value))
    : remote.description ?? remote.unserializableValue ?? `[${remote.type}]`;
const placeOf = (stack) => {
  const frame = stack?.callFrames?.find((f) => !f.url.includes('debug-panel'));
  return frame ? `${frame.url.split('/').pop().split('?')[0]}:${frame.lineNumber + 1}` : '';
};

for (const page of targets) {
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  let nextId = 0;
  const send = (method, params = {}) => ws.send(JSON.stringify({ id: ++nextId, method, params }));
  let historyId = -1;
  // Runtime.enable の返事より前に届くログは、つないだ瞬間に Quest が送り直す「前のログ」。
  // テンプレートのページなら「これまでのログ」（window.__questLog）と同じものなので、出さない（2回数えないため）
  let enabled = false;
  const replayed = [];

  ws.onopen = () => {
    console.log(clean(`▶ ${page.url}`));
    send('Runtime.enable');
    send('Log.enable');
    if (has('--reload')) {
      send('Page.reload', { ignoreCache: true });
      console.log('  ページを読み込み直しました。最初からのログを出します。');
    } else {
      send('Runtime.evaluate', { expression: 'JSON.stringify(window.__questLog || null)', returnByValue: true });
      historyId = nextId;
    }
  };
  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id === 1) {
      enabled = true;
      if (has('--reload')) replayed.length = 0;   // 読み込み直す前のページのログ
      return;
    }
    if (msg.id === historyId) {
      const history = JSON.parse(msg.result?.result?.value ?? 'null');
      if (history) {
        console.log(`  これまでのログ（${history.length} 件。新しい 50 件まで）`);
        history.slice(-50).forEach((e) => print(e.level, e.text, '', Date.parse(e.time), e.count));
        flushRepeats();
        lastLine = '';
        console.log(`  ── ここから新しいログ（${seconds}秒） ──`);
      } else {
        replayed.forEach((show) => show());   // テンプレートでないページは、送り直されたログを出す
      }
      replayed.length = 0;
      return;
    }
    const p = msg.params;
    if (msg.method === 'Runtime.consoleAPICalled') {
      const show = () => print(p.type, p.args.map(describe).join(' '), placeOf(p.stackTrace), p.timestamp);
      if (enabled) show(); else replayed.push(show);
    } else if (msg.method === 'Runtime.exceptionThrown') {
      const d = p.exceptionDetails;
      const show = () => print('error', d.exception?.description ?? d.text, placeOf(d.stackTrace) || `${d.url?.split('/').pop() ?? ''}:${d.lineNumber + 1}`, p.timestamp);
      if (enabled) show(); else replayed.push(show);
    } else if (msg.method === 'Log.entryAdded') {
      const e = p.entry;
      if (e.level === 'verbose') return;
      print(e.level, `${e.text}${e.url ? ` ${e.url}` : ''}`, '', e.timestamp);
    }
  };
  ws.onerror = () => console.log(clean(`✖ ${page.url} につながりませんでした`));
}

setTimeout(() => {
  flushRepeats();
  console.log(`— エラー ${errors} 件、注意 ${warnings} 件`);
  process.exit(0);
}, seconds * 1000);
