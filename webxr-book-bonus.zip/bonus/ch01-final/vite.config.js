// 開発サーバーの設定。mkcert で HTTPS にして、同じ Wi-Fi の Quest からも開けるようにする
import { defineConfig } from 'vite';
import mkcert from 'vite-plugin-mkcert';

export default defineConfig({
  plugins: [mkcert()],
  server: {
    host: true,        // Wi-Fi の中のほかの機械（Quest）からも開けるようにする
    port: 5173,        // アドレスの最後の番号。いつも同じにする（ブックマークが使えるように）
    strictPort: true,  // 5173 が使われているときは、別の番号にせず止める
  },
  build: {
    chunkSizeWarningLimit: 2000,  // three.js は大きいので、「ファイルが大きい」という注意の目安を上げておく
  },
});
