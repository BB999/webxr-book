// エラーを見つけやすくするしくみ
// 1. console.log やエラーを window.__questLog にためる（npm run log で、AI が Mac から読める）
// 2. エラーが出たら、VR / MR の中では目の前の赤い板に、ブラウザの画面では左上に出す
// 同じエラーが毎フレームくり返されても、1つにまとめて回数を数える
import * as THREE from 'three';

const MAX_LOG = 200;     // ためておくログの数
const MAX_SHOWN = 4;     // 板に出すエラーの数（新しいものから）

export function setupDebugPanel(scene, renderer) {
  const log = (window.__questLog = window.__questLog || []);
  const errors = [];     // { key, message, place, entry }
  let dirty = false;

  // ブラウザの画面用：左上の赤い一覧（エラーが出たらすぐ出す）
  const list = document.createElement('div');
  list.id = 'debug-list';
  document.body.appendChild(list);
  function showList() {
    list.textContent = `エラー ${errors.length} 件\n\n` +
      errors.slice(-MAX_SHOWN).map((e) => `${e.message}${e.place ? `\n  (${e.place})` : ''}`).join('\n\n');
    list.style.display = renderer.xr.isPresenting ? 'none' : 'block';
  }

  const toText = (value) => {
    if (value instanceof Error) return value.stack || `${value.name}: ${value.message}`;
    if (typeof value === 'object' && value !== null) {
      try { return JSON.stringify(value); } catch { return String(value); }
    }
    return String(value);
  };
  // スタック（エラーが起きた道すじ）から、「main.js:55」のような場所を取り出す
  const placeOf = (text) => {
    const found = text.match(/([\w.-]+\.(?:js|mjs|ts))(?:\?[^:\s)]*)?:(\d+):\d+/);
    return found ? `${found[1]}:${found[2]}` : '';
  };

  // ログに足す。同じものが続いたとき、同じエラー（文と場所が同じ）がまた出たときは、回数だけ増やして true を返す
  const record = (level, values) => {
    const text = values.map(toText).join(' ');
    const message = text.split('\n')[0];
    const place = placeOf(text);
    const key = `${message} ${place}`;
    const last = log[log.length - 1];
    const same = level === 'error' ? errors.find((e) => e.key === key)?.entry
      : last && last.level === level && last.text === text ? last : null;
    if (same) {
      same.count = (same.count || 1) + 1;
      return true;
    }
    const entry = { time: new Date().toISOString(), level, text };
    log.push(entry);
    if (log.length > MAX_LOG) log.shift();
    if (level === 'error') {
      errors.push({ key, message, place, entry });
      showList();
      dirty = true;
    }
    return false;
  };

  for (const level of ['log', 'info', 'warn', 'error']) {
    const original = console[level].bind(console);
    console[level] = (...values) => {
      if (record(level, values)) return;   // くり返しは、ブラウザの開発ツールには出さない
      original(...values);
    };
  }
  addEventListener('error', (event) => record('error', [event.error || event.message]));
  addEventListener('unhandledrejection', (event) => record('error', ['Promise のエラー:', event.reason]));

  // VR / MR 用：目の前に出す赤い板（文字を絵に描いて、板に貼る）
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const panel = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.6),
    new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthTest: false })
  );
  panel.name = 'debug-panel';
  panel.renderOrder = 999;     // ほかの物より手前に描く
  panel.raycast = () => {};    // 光線の当たり判定では、この板を無視する
  panel.visible = false;
  scene.add(panel);

  // 長い文を、板の幅で折り返す
  const wrap = (g, text, width) => {
    const lines = [''];
    for (const char of text) {
      const line = lines[lines.length - 1] + char;
      if (g.measureText(line).width > width) lines.push(char);
      else lines[lines.length - 1] = line;
    }
    return lines;
  };
  const draw = () => {
    const g = canvas.getContext('2d');
    g.clearRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = 'rgba(150, 20, 20, 0.92)';
    g.fillRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = '#fff';
    g.font = 'bold 40px sans-serif';
    g.fillText(`エラーが ${errors.length} 件あります`, 32, 64);
    g.font = '28px sans-serif';
    g.fillText('AI に「Quest のログを見て直して」と頼んでください', 32, 110);
    let y = 170;
    for (const e of errors.slice(-MAX_SHOWN).reverse()) {
      g.font = '28px monospace';
      for (const line of wrap(g, e.message, canvas.width - 64).slice(0, 2)) {
        if (y > canvas.height - 20) break;
        g.fillText(line, 32, y);
        y += 36;
      }
      if (e.place && y <= canvas.height - 20) {
        g.font = '24px monospace';
        g.fillText(`  (${e.place})`, 32, y);
        y += 34;
      }
      y += 14;
    }
    texture.needsUpdate = true;
  };

  // VR / MR に入ったとき、それまでのエラーも板に出す。出たら板をしまう
  renderer.xr.addEventListener('sessionstart', () => {
    list.style.display = 'none';
    if (errors.length) dirty = true;
  });
  renderer.xr.addEventListener('sessionend', () => {
    panel.visible = false;
    if (errors.length) list.style.display = 'block';
  });

  const forward = new THREE.Vector3();
  return {
    // 毎フレーム、描いたあとに呼ぶ。新しいエラーがあったときだけ、頭の正面に板を出し直す
    update() {
      if (!dirty || !renderer.xr.isPresenting) return;
      dirty = false;
      draw();
      // 頭の正面 1.5 メートル、少し下に出す
      const head = renderer.xr.getCamera();
      head.getWorldDirection(forward);
      forward.y = 0;
      forward.normalize();
      panel.position.copy(head.position).addScaledVector(forward, 1.5);
      panel.position.y -= 0.3;
      panel.lookAt(head.position.x, panel.position.y, head.position.z);
      panel.visible = true;
    },
  };
}
