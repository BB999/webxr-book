// 「VR で遊ぶ」「MR で遊ぶ」のボタンを作る
// ボタンを押すと Quest の VR / MR の世界に入る。Quest 以外（Mac のブラウザなど）では押せないボタンになる
import * as THREE from 'three';

// VR / MR のときに Quest に頼む機能。optional（あれば使う）にしておくと、使えない機能があってもセッションは始まる
const DEFAULT_FEATURES = {
  'immersive-vr': { optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking'] },
  'immersive-ar': {
    optionalFeatures: ['local-floor', 'hand-tracking', 'plane-detection', 'mesh-detection', 'hit-test', 'anchors'],
  },
};

// VR / MR に入る途中かどうか（VR と MR のボタンで共通）
let isStarting = false;

/**
 * VR / MR に入るボタンを作る
 * @param {THREE.WebGLRenderer} renderer 描く係
 * @param {'immersive-vr' | 'immersive-ar'} mode VR なら 'immersive-vr'、MR なら 'immersive-ar'
 * @param {string} label ボタンの文字
 * @param {XRSessionInit} [sessionInit] Quest に頼む機能（省略すると上の DEFAULT_FEATURES）
 */
export function createXRButton(renderer, mode, label, sessionInit = DEFAULT_FEATURES[mode]) {
  const button = document.createElement('button');
  button.textContent = label;
  button.className = mode === 'immersive-ar' ? 'mr' : 'vr';
  button.disabled = true;

  if (!('xr' in navigator)) {
    button.textContent = `${label}（Quest のブラウザで開いてください）`;
    return button;
  }
  navigator.xr.isSessionSupported(mode).then((supported) => {
    button.disabled = !supported;
    if (!supported) button.textContent = `${label}（Quest のブラウザで開いてください）`;
  });

  button.addEventListener('click', async () => {
    // すでに VR / MR の中にいるときや、入る途中のときは何もしない（もう一度頼むと InvalidStateError になる）
    if (isStarting || renderer.xr.isPresenting) return;
    isStarting = true;
    // 音は「遊ぶ人が操作したあと」でないと鳴らせない決まりがあるので、ボタンを押したここで音の準備をしておく
    THREE.AudioContext.getContext().resume();
    try {
      const session = await navigator.xr.requestSession(mode, sessionInit);
      document.getElementById('overlay').style.display = 'none';
      session.addEventListener('end', () => {
        document.getElementById('overlay').style.display = '';
      });
      await renderer.xr.setSession(session);
    } catch (error) {
      console.error(`${label} を始められませんでした:`, error);
    } finally {
      isStarting = false;
    }
  });
  return button;
}
