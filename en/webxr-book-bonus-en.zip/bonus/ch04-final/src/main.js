// ---- Game difficulty: the numbers you might want to change are all here ----
const GAME_SETTINGS = {
  spawnInterval: 2,       // Time between balloons at the start (seconds)
  finalSpawnInterval: 0.5, // Time between balloons at the end (seconds). 0.5 means 2 per second
  easyDuration: 20,       // Length of the slow period at the start (seconds)
  hardDuration: 20,       // Length of the hard period at the end (seconds)
  finalRiseMultiplier: 1.5, // How many times faster the final rise speed is than at the start
  riseSpeed: 0.5,         // How fast balloons rise (meters per second)
  balloonDiameter: 0.3,  // Balloon width (meters). 0.3 means 30 centimeters
  timeLimit: 60,          // Game time limit (seconds)
  pointsPerBalloon: 1,    // Points for popping one balloon
  goldChance: 0.1,        // Chance of a gold balloon. 0.1 means about 1 in 10
  goldRiseMultiplier: 2,  // How many times faster gold balloons rise than regular ones
  goldPoints: 5,          // Points for popping one gold balloon
};

// The project's entry point. Builds a 3D world with three.js that you can see in VR on Quest
// Write your project under the "Your project goes below this line" line at the very bottom
// The ground rules for the AI are in AGENTS.md (for Codex) and CLAUDE.md (for Claude)
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- The three actors: the stage (scene), the eyes (camera), and the artist (renderer) ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // Background color (turns transparent automatically in MR, so you can see the room)

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // Eye height of 1.5 meters (in VR, it moves with your head on the Quest)

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // Puts the floor at height 0
document.body.appendChild(renderer.domElement);

// ---- Lights ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // Light that shines evenly on everything
const sun = new THREE.DirectionalLight(0xffffff, 2);            // Light that comes from one direction
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- Floor grid (each square is 1 meter). A guide for judging size. Hidden in MR, where you can see the real floor ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- When viewing in the Mac browser: drag with the mouse to look around (not used in VR) ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- "Play in VR" button ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'Play in VR'));

// ---- Also shows errors in VR (read the logs with npm run log) ----
const debug = setupDebugPanel(scene, renderer);

// ---- Repeats every frame: moves things in update() below, then redraws ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // Keeps things from jumping ahead after a pause
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // Keeps drawing even after an error (the error appears on the red panel)
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- When the browser window changes size, resizes the picture to match ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== Your project goes below this line ========
// Put things on the stage with scene.add(). Units are meters. The floor is at height 0, and straight ahead is the minus z direction
// Write anything you want to move every frame inside update() below

import { XRControllerModelFactory } from 'three/addons/webxr/XRControllerModelFactory.js';

// Sends a white beam, 5 meters long, straight ahead (minus z) from the tip of each hand
const rayGeometry = new THREE.CylinderGeometry(0.002, 0.002, 5, 8);
rayGeometry.rotateX(Math.PI / 2);
rayGeometry.translate(0, 0, -2.5);
const rayMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, fog: false, toneMapped: false });
const controllerModelFactory = new XRControllerModelFactory();
const laserControllers = [];

for (let i = 0; i < 2; i++) {
  // Making the beam a child of the controller moves its position and direction together
  const controller = renderer.xr.getController(i);
  const ray = new THREE.Mesh(rayGeometry, rayMaterial);
  ray.visible = false;
  controller.add(ray);
  controller.addEventListener('connected', (event) => {
    ray.visible = event.data.targetRayMode === 'tracked-pointer' && !event.data.hand;
  });
  controller.addEventListener('disconnected', () => { ray.visible = false; });
  scene.add(controller);
  laserControllers.push({ controller, ray });
  controller.addEventListener('selectstart', (event) => {
    if (!ray.visible || !renderer.xr.isPresenting) return;
    if (gameState === 'finished') {
      startGame();
      return;
    }
    if (gameState !== 'playing') return;
    const target = hitsBalloon(controller);
    if (target) burstBalloon(target, event.data);
  });

  // Shows the controller shape that fits your device, where you hold it
  const grip = renderer.xr.getControllerGrip(i);
  grip.add(controllerModelFactory.createControllerModel(grip));
  scene.add(grip);
}

// Manages live balloons and popped fragments separately
const balloons = [];
const balloonMeshes = [];
const fragmentBursts = [];
const balloonColors = [0xe52222, 0x2277ee, 0xffdd22, 0x22bb55, 0xff66aa];
let spawnProgress = 0;
const viewerPosition = new THREE.Vector3();
const viewerForward = new THREE.Vector3();
const viewerRotation = new THREE.Quaternion();

// Attaches the sound listener to the camera and makes a short pop sound in code
const popListener = new THREE.AudioListener();
camera.add(popListener);
let popBuffer;
const activePopSounds = new Set();

function removePopSound(sound) {
  if (!activePopSounds.delete(sound)) return;
  if (sound.isPlaying) sound.stop();
  sound.disconnect();
  sound.gain.disconnect();
  scene.remove(sound);
}

function playPopSound(position) {
  if (!popBuffer) {
    const context = popListener.context;
    const duration = 0.12;
    popBuffer = context.createBuffer(1, Math.ceil(context.sampleRate * duration), context.sampleRate);
    const samples = popBuffer.getChannelData(0);
    for (let i = 0; i < samples.length; i++) {
      const time = i / context.sampleRate;
      const attack = Math.min(1, time / 0.001);
      const fade = Math.pow(1 - i / samples.length, 2);
      samples[i] = attack * fade * (
        (Math.random() * 2 - 1) * 0.65 * Math.exp(-time * 35)
        + Math.sin(2 * Math.PI * 150 * time) * 0.35 * Math.exp(-time * 45)
      );
    }
  }
  const sound = new THREE.PositionalAudio(popListener);
  sound.setBuffer(popBuffer);
  sound.setRefDistance(2);
  sound.setVolume(0.7);
  sound.position.copy(position);
  sound.onEnded = () => {
    THREE.Audio.prototype.onEnded.call(sound);
    removePopSound(sound);
  };
  activePopSounds.add(sound);
  scene.add(sound);
  // Updates the position before playing, so the sound comes from where it popped
  sound.updateMatrixWorld(true);
  sound.play();
}

function vibrateController(inputSource) {
  const actuator = inputSource?.gamepad?.hapticActuators?.[0];
  if (!actuator) return;
  // Even if vibration isn't available, the game keeps going
  try {
    const result = actuator.pulse(0.5, 100);
    result?.catch(() => {});
  } catch {
    // Does nothing if the connection has dropped
  }
}

// Draws large letters on a sign 3 meters straight ahead, at a height of 2.5 meters
let score = 0;
let remainingTime = GAME_SETTINGS.timeLimit;
let gameState = 'waiting';
let previousSignText = '';
const signCanvas = document.createElement('canvas');
signCanvas.width = 1024;
signCanvas.height = 512;
const signContext = signCanvas.getContext('2d');
const signTexture = new THREE.CanvasTexture(signCanvas);
signTexture.colorSpace = THREE.SRGBColorSpace;
const sign = new THREE.Mesh(
  new THREE.PlaneGeometry(1.8, 0.9),
  new THREE.MeshBasicMaterial({ map: signTexture, toneMapped: false, fog: false })
);
sign.position.set(0, 2.5, -3);
scene.add(sign);

function updateSign() {
  const seconds = Math.max(0, Math.ceil(remainingTime - 1e-9));
  const text = gameState === 'finished'
    ? `Game over!\nScore ${score}`
    : `Score ${score}\nTime ${seconds}s`;
  if (text === previousSignText) return;
  previousSignText = text;
  signContext.fillStyle = '#fff8e8';
  signContext.fillRect(0, 0, 1024, 512);
  signContext.fillStyle = '#25354a';
  signContext.font = 'bold 110px sans-serif';
  signContext.textAlign = 'center';
  signContext.textBaseline = 'middle';
  const lines = text.split('\n');
  signContext.fillText(lines[0], 512, 160, 960);
  signContext.fillText(lines[1], 512, 350, 960);
  signTexture.needsUpdate = true;
}

// A new game also clears away the earlier balloons and fragments
function clearGameObjects() {
  for (const sound of activePopSounds) removePopSound(sound);
  while (balloons.length > 0) removeBalloon(balloons[balloons.length - 1]);
  for (const burst of fragmentBursts) {
    for (const { mesh } of burst.fragments) scene.remove(mesh);
    burst.geometry.dispose();
    burst.material.dispose();
  }
  fragmentBursts.length = 0;
}

function startGame() {
  clearGameObjects();
  score = 0;
  remainingTime = GAME_SETTINGS.timeLimit;
  spawnProgress = 0;
  gameState = 'playing';
  updateSign();
}

renderer.xr.addEventListener('sessionstart', startGame);
renderer.xr.addEventListener('sessionend', () => {
  clearGameObjects();
  gameState = 'waiting';
  score = 0;
  remainingTime = GAME_SETTINGS.timeLimit;
  spawnProgress = 0;
  updateSign();
});
updateSign();

// Spawns 2 to 4 meters ahead, to the left, or to the right, based on where you are and which way you face
function spawnBalloon() {
  const viewer = renderer.xr.isPresenting ? renderer.xr.getCamera() : camera;
  viewer.getWorldPosition(viewerPosition);
  viewer.getWorldQuaternion(viewerRotation);
  viewerForward.set(0, 0, -1).applyQuaternion(viewerRotation);
  const heading = Math.hypot(viewerForward.x, viewerForward.z) > 0.001
    ? Math.atan2(viewerForward.x, -viewerForward.z) : 0;
  const angle = heading + (Math.random() - 0.5) * Math.PI;
  const distance = 2 + Math.random() * 2;
  const group = new THREE.Group();
  group.position.set(
    viewerPosition.x + Math.sin(angle) * distance,
    0.43,
    viewerPosition.z - Math.cos(angle) * distance
  );
  const isGold = Math.random() < GAME_SETTINGS.goldChance;
  const color = isGold ? 0xffc526 : balloonColors[Math.floor(Math.random() * balloonColors.length)];
  const material = new THREE.MeshStandardMaterial({
    color,
    roughness: isGold ? 0.2 : 0.35,
    metalness: isGold ? 0.5 : 0,
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(GAME_SETTINGS.balloonDiameter / 2, 24, 16), material);
  mesh.scale.y = 1.2;
  group.add(mesh);
  const string = new THREE.Mesh(
    new THREE.CylinderGeometry(0.0015, 0.0015, 0.25, 6),
    new THREE.MeshStandardMaterial({ color: 0xffffff })
  );
  string.position.y = -0.305;
  group.add(string);
  const balloon = {
    group, mesh, string, color, baseX: group.position.x, age: 0,
    riseMultiplier: isGold ? GAME_SETTINGS.goldRiseMultiplier : 1,
    points: isGold ? GAME_SETTINGS.goldPoints : GAME_SETTINGS.pointsPerBalloon,
  };
  mesh.userData.balloon = balloon;
  balloons.push(balloon);
  balloonMeshes.push(mesh);
  scene.add(group);
}

// Cleans up a removed balloon's shape and material
function removeBalloon(balloon) {
  scene.remove(balloon.group);
  balloons.splice(balloons.indexOf(balloon), 1);
  balloonMeshes.splice(balloonMeshes.indexOf(balloon.mesh), 1);
  balloon.mesh.geometry.dispose();
  balloon.mesh.material.dispose();
  balloon.string.geometry.dispose();
  balloon.string.material.dispose();
}

const balloonRaycaster = new THREE.Raycaster();
balloonRaycaster.far = 5;
const rayOrigin = new THREE.Vector3();
const rayDirection = new THREE.Vector3();
const rayRotation = new THREE.Matrix4();
const balloonHits = [];
const highlightWhite = new THREE.Color(0xffffff);

// Picks the nearest balloon within 5 meters along the beam
function hitsBalloon(controller) {
  if (!renderer.xr.isPresenting) return null;
  controller.updateWorldMatrix(true, false);
  for (const balloon of balloons) balloon.mesh.updateWorldMatrix(true, false);
  rayOrigin.setFromMatrixPosition(controller.matrixWorld);
  rayRotation.extractRotation(controller.matrixWorld);
  rayDirection.set(0, 0, -1).applyMatrix4(rayRotation);
  balloonRaycaster.set(rayOrigin, rayDirection);
  balloonHits.length = 0;
  balloonRaycaster.intersectObjects(balloonMeshes, false, balloonHits);
  return balloonHits.length > 0 ? balloonHits[0].object.userData.balloon : null;
}

// Sends out fragments the same color as the popped balloon
function burstBalloon(balloon, inputSource) {
  if (gameState !== 'playing' || !balloons.includes(balloon)) return;
  score += balloon.points;
  updateSign();
  const geometry = new THREE.PlaneGeometry(0.025, 0.035);
  const material = new THREE.MeshStandardMaterial({ color: balloon.color, side: THREE.DoubleSide });
  const fragments = [];
  for (let i = 0; i < 20; i++) {
    const mesh = new THREE.Mesh(geometry, material);
    const direction = new THREE.Vector3().randomDirection();
    mesh.position.copy(balloon.group.position).addScaledVector(direction, 0.1);
    mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
    scene.add(mesh);
    fragments.push({ mesh, velocity: direction.multiplyScalar(0.6 + Math.random() * 0.8) });
  }
  fragmentBursts.push({ fragments, geometry, material, age: 0 });
  playPopSound(balloon.group.position);
  vibrateController(inputSource);
  removeBalloon(balloon);
}

// Steady for the first 20 seconds, changes little by little in between, and at its maximum for the last 20 seconds
function getGameDifficulty(gameElapsed) {
  const transitionDuration = GAME_SETTINGS.timeLimit - GAME_SETTINGS.easyDuration - GAME_SETTINGS.hardDuration;
  const progress = transitionDuration > 0
    ? THREE.MathUtils.clamp((gameElapsed - GAME_SETTINGS.easyDuration) / transitionDuration, 0, 1)
    : (gameElapsed < GAME_SETTINGS.easyDuration ? 0 : 1);
  return {
    spawnRate: THREE.MathUtils.lerp(1 / GAME_SETTINGS.spawnInterval, 1 / GAME_SETTINGS.finalSpawnInterval, progress),
    riseSpeed: GAME_SETTINGS.riseSpeed * THREE.MathUtils.lerp(1, GAME_SETTINGS.finalRiseMultiplier, progress),
  };
}

/**
 * Called every frame
 * @param {number} delta Time since the last frame (seconds)
 * @param {number} elapsed Time since the start (seconds)
 */
function update(delta, elapsed) {
  // Calculates at the middle of the frame, to reduce pace differences caused by how often it draws
  const difficulty = getGameDifficulty(GAME_SETTINGS.timeLimit - remainingTime + (gameState === 'playing' ? delta / 2 : 0));
  if (gameState === 'playing') {
    remainingTime = Math.max(0, remainingTime - delta);
    if (remainingTime <= 1e-9) {
      remainingTime = 0;
      gameState = 'finished';
    } else {
      spawnProgress += delta * difficulty.spawnRate;
      while (spawnProgress + 1e-9 >= 1) {
        spawnProgress = Math.max(0, spawnProgress - 1);
        spawnBalloon();
      }
    }
    updateSign();
  }
  for (let i = balloons.length - 1; i >= 0; i--) {
    const balloon = balloons[i];
    balloon.age += delta;
    balloon.group.position.y += difficulty.riseSpeed * balloon.riseMultiplier * delta;
    balloon.group.position.x = balloon.baseX + Math.sin(balloon.age * 1.5) * 0.1;
    if (balloon.group.position.y > 8) {
      removeBalloon(balloon);
      continue;
    }
    balloon.mesh.material.color.setHex(balloon.color);
    balloon.mesh.material.emissive.setHex(0x000000);
  }
  for (const { controller, ray } of laserControllers) {
    const target = gameState === 'playing' && ray.visible ? hitsBalloon(controller) : null;
    if (target) {
      target.mesh.material.color.setHex(target.color).lerp(highlightWhite, 0.2);
      target.mesh.material.emissive.setHex(target.color).multiplyScalar(0.15);
    }
  }
  for (let i = fragmentBursts.length - 1; i >= 0; i--) {
    const burst = fragmentBursts[i];
    burst.age += delta;
    for (const { mesh, velocity } of burst.fragments) {
      velocity.y -= 2 * delta;
      mesh.position.addScaledVector(velocity, delta);
      mesh.rotation.x += 3 * delta;
      mesh.rotation.z += 2 * delta;
    }
    // Cleans up each set of fragments after 1.5 seconds, and frees their shapes and materials too
    if (burst.age >= 1.5) {
      for (const { mesh } of burst.fragments) scene.remove(mesh);
      burst.geometry.dispose();
      burst.material.dispose();
      fragmentBursts.splice(i, 1);
    }
  }
}

// ---- Meadow (Chapter 4's starting point): sky and ground ----
scene.remove(grid);                                // The grid isn't used
scene.background = new THREE.Color(0xe3f3ff);      // Sky color (near the horizon)
scene.fog = new THREE.Fog(0xe3f3ff, 25, 110);      // Fades the distance into the sky color

// Sky: a large sphere painted on the inside. Deep blue at the top, whiter toward the horizon
const skyGeometry = new THREE.SphereGeometry(100, 32, 16);
const skyColors = [];
const top = new THREE.Color(0x4a9be0);
const horizon = new THREE.Color(0xe3f3ff);
const position = skyGeometry.attributes.position;
for (let i = 0; i < position.count; i++) {
  const height = Math.max(0, position.getY(i) / 100);   // 0 (horizon) to 1 (straight up)
  const color = horizon.clone().lerp(top, Math.pow(height, 0.6));
  skyColors.push(color.r, color.g, color.b);
}
skyGeometry.setAttribute('color', new THREE.Float32BufferAttribute(skyColors, 3));
const sky = new THREE.Mesh(skyGeometry, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false }));
scene.add(sky);

// Ground: a green panel, 240 meters on each side (the distance fades into the sky color with fog)
const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(240, 240, 48, 48),
  new THREE.MeshStandardMaterial({ color: 0x79c26a, roughness: 1 })
);
ground.rotation.x = -Math.PI / 2;                  // Lays it flat to make the floor
scene.add(ground);

// Distant hills: squashed spheres placed in a circle all around
const hillMaterial = new THREE.MeshStandardMaterial({ color: 0x5fae58, roughness: 1 });
for (let i = 0; i < 9; i++) {
  const angle = (i / 9) * Math.PI * 2 + 0.3;
  const hill = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), hillMaterial);
  const distance = 55 + (i % 3) * 12;
  hill.position.set(Math.sin(angle) * distance, 0, -Math.cos(angle) * distance);
  hill.scale.set(14 + (i % 4) * 4, 5 + (i % 3) * 2.5, 10);
  hill.lookAt(0, 0, 0);
  scene.add(hill);
}

// Clouds: a few white spheres stacked together, floating in the sky
const cloudMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0xaab6c2, fog: false });
for (let i = 0; i < 7; i++) {
  const angle = (i / 7) * Math.PI * 2;
  const cloud = new THREE.Group();
  for (let j = 0; j < 4; j++) {
    const puff = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), cloudMaterial);
    puff.position.set((j - 1.5) * 2.2, (j % 2) * 0.8, 0);
    puff.scale.setScalar(2 + (j % 2));
    cloud.add(puff);
  }
  cloud.position.set(Math.sin(angle) * 80, 30 + (i % 3) * 6, -Math.cos(angle) * 80);
  cloud.lookAt(0, cloud.position.y, 0);
  scene.add(cloud);
}
