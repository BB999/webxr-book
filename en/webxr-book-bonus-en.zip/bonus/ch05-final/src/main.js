// The project's entry point. Builds a 3D world with three.js that you can see in VR on Quest
// Write your project under the "Your project goes below this line" line at the very bottom
// The ground rules for the AI are in AGENTS.md (for Codex) and CLAUDE.md (for Claude)
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- The three actors: the stage (scene), the eyes (camera), and the artist (renderer) ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // Background color (turns transparent automatically in MR, so you can see the room)

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // Eye height of 1.5 meters (in VR, it moves with your head on the Quest)

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // Puts the floor at height 0
document.body.appendChild(renderer.domElement);

// ---- Lights ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // Light that shines evenly on everything
const sun = new THREE.DirectionalLight(0xffffff, 2);            // Light that comes from one direction
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- Floor grid (each square is 1 meter). A guide for judging size. Hidden in MR, where you can see the real floor ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- When viewing in the Mac browser: drag with the mouse to look around (not used in VR) ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- "Play in MR" button ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-ar', 'Play in MR'));

// ---- Also shows errors in VR (read the logs with npm run log) ----
const debug = setupDebugPanel(scene, renderer);

// ---- Repeats every frame: moves things in update() below, then redraws ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // Keeps things from jumping ahead after a pause
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // Keeps drawing even after an error (the error appears on the red panel)
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- When the browser window changes size, resizes the picture to match ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== Your project goes below this line ========
// Put things on the stage with scene.add(). Units are meters. The floor is at height 0, and straight ahead is the minus z direction
// Write anything you want to move every frame inside update() below

// A container for placing Nekobi. It can remember the position for the start of MR even before loading finishes
const nekobi = new THREE.Group();
nekobi.position.set(0, 0, -1);
scene.add(nekobi);

// Makes shadows with a light from above. The light moves with Nekobi too
renderer.shadowMap.enabled = true;
sun.position.set(0, 2, 0);
sun.castShadow = true;
sun.shadow.mapSize.set(512, 512);
sun.shadow.camera.left = -0.6;
sun.shadow.camera.right = 0.6;
sun.shadow.camera.top = 0.6;
sun.shadow.camera.bottom = -0.6;
sun.shadow.camera.near = 0.1;
sun.shadow.camera.far = 3;
sun.shadow.normalBias = 0.01;
nekobi.add(sun, sun.target);

// The panel itself is transparent, so only the shadow lies over the real floor
const shadowFloor = new THREE.Mesh(
  new THREE.PlaneGeometry(1.2, 1.2),
  new THREE.ShadowMaterial({ opacity: 0.3, depthWrite: false }),
);
shadowFloor.rotation.x = -Math.PI / 2;
shadowFloor.position.y = 0.001;
shadowFloor.receiveShadow = true;
nekobi.add(shadowFloor);

new GLTFLoader().load('/models/nekobi.glb', (gltf) => {
  const model = gltf.scene;
  // Makes every shape in Nekobi cast a shadow
  model.traverse((object) => {
    if (object.isMesh) object.castShadow = true;
  });
  const bounds = new THREE.Box3().setFromObject(model);
  const size = bounds.getSize(new THREE.Vector3());
  // Sets the height up to the ears to 40 centimeters
  model.scale.setScalar(0.4 / size.y);
  bounds.setFromObject(model);
  const center = bounds.getCenter(new THREE.Vector3());
  // Puts the feet on the floor and lines up the horizontal center with the container's center
  model.position.x -= center.x;
  model.position.y -= bounds.min.y;
  model.position.z -= center.z;
  nekobi.add(model);
}, undefined, (error) => {
  console.error('Couldn\'t load Nekobi:', error);
});

// Each time you enter MR, places it on the floor 1 meter ahead in the direction you're first looking
let placeNekobi = false;
const forward = new THREE.Vector3();
const headRotation = new THREE.Quaternion();
renderer.xr.addEventListener('sessionstart', () => {
  placeNekobi = true;
  nekobi.visible = false;
});
renderer.xr.addEventListener('sessionend', () => {
  placeNekobi = false;
  nekobi.position.set(0, 0, -1);
  nekobi.rotation.y = 0;
  nekobi.visible = true;
});

// Shows the room surfaces the Quest remembers as nearly transparent panels
const roomPlanes = new Map();

function removeRoomPlane(plane, entry) {
  scene.remove(entry.mesh);
  entry.mesh.geometry.dispose();
  entry.mesh.material.dispose();
  roomPlanes.delete(plane);
}

renderer.xr.addEventListener('sessionend', () => {
  for (const [plane, entry] of roomPlanes) removeRoomPlane(plane, entry);
});

function createRoomPlaneGeometry(plane) {
  // A surface's outline arrives as x and z coordinates relative to that surface
  const points = Array.from(plane.polygon, (point) => new THREE.Vector2(point.x, -point.z));
  const geometry = new THREE.ShapeGeometry(new THREE.Shape(points));
  geometry.rotateX(-Math.PI / 2);
  return geometry;
}

function updateRoomPlanes(frame, referenceSpace) {
  const planes = frame.detectedPlanes;
  if (!planes) return;

  // Cleans up the panel and resources of any surface that's no longer found
  for (const [plane, entry] of roomPlanes) {
    if (!planes.has(plane)) removeRoomPlane(plane, entry);
  }

  for (const plane of planes) {
    const pose = frame.getPose(plane.planeSpace, referenceSpace);
    let entry = roomPlanes.get(plane);
    if (!pose || plane.polygon.length < 3) {
      if (entry) entry.mesh.visible = false;
      continue;
    }
    if (!entry) {
      const mesh = new THREE.Mesh(
        createRoomPlaneGeometry(plane),
        new THREE.MeshBasicMaterial({
          transparent: true, opacity: 0.12, side: THREE.DoubleSide,
          depthWrite: false,
        }),
      );
      mesh.matrixAutoUpdate = false;
      // Draws before Nekobi's shadow, to keep the shadow looking right
      mesh.renderOrder = -1;
      scene.add(mesh);
      entry = { mesh, changedTime: plane.lastChangedTime };
      roomPlanes.set(plane, entry);
    } else if (entry.changedTime !== plane.lastChangedTime) {
      entry.mesh.geometry.dispose();
      entry.mesh.geometry = createRoomPlaneGeometry(plane);
      entry.changedTime = plane.lastChangedTime;
    }
    entry.mesh.visible = true;
    entry.mesh.matrix.fromArray(pose.transform.matrix);
    // If no orientation arrives, checks whether the surface is horizontal from its up axis
    const horizontal = plane.orientation === 'horizontal' ||
      (plane.orientation == null && Math.abs(entry.mesh.matrix.elements[5]) > 0.7);
    entry.mesh.material.color.setHex(horizontal ? 0x66ff88 : 0x6699ff);
  }
}

// Uses only the right controller. Doesn't use pinch actions from hand tracking
let rightInputSource = null;
let moveNekobi = false;
for (let index = 0; index < 2; index++) {
  const controller = renderer.xr.getController(index);
  controller.addEventListener('connected', (event) => {
    const source = event.data;
    if (source.handedness === 'right' && source.targetRayMode === 'tracked-pointer' && !source.hand) {
      rightInputSource = source;
    }
  });
  controller.addEventListener('disconnected', (event) => {
    if (event.data === rightInputSource) {
      rightInputSource = null;
      moveNekobi = false;
      aimLine.visible = aimMarker.visible = false;
    }
  });
  controller.addEventListener('selectstart', (event) => {
    if (rightInputSource && event.data === rightInputSource) moveNekobi = true;
  });
}

// Reuses the beam and white circle instead of rebuilding them every frame
const aimGeometry = new THREE.BufferGeometry().setFromPoints([
  new THREE.Vector3(), new THREE.Vector3(0, 0, -10),
]);
const aimLine = new THREE.Line(aimGeometry, new THREE.LineBasicMaterial({ color: 0xffffff }));
aimLine.matrixAutoUpdate = false;
aimLine.frustumCulled = false;
aimLine.visible = false;
scene.add(aimLine);

const aimMarker = new THREE.Mesh(
  new THREE.CircleGeometry(0.025, 24),
  new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, depthWrite: false }),
);
aimMarker.visible = false;
scene.add(aimMarker);

const aimRaycaster = new THREE.Raycaster();
aimRaycaster.far = 10;
const aimDirection = new THREE.Vector3();
const aimNormal = new THREE.Vector3();
const aimNormalMatrix = new THREE.Matrix3();
const markerAxis = new THREE.Vector3(0, 0, 1);
const aimTargets = [];
const aimHits = [];

renderer.xr.addEventListener('sessionend', () => {
  rightInputSource = null;
  moveNekobi = false;
  aimLine.visible = aimMarker.visible = false;
});

function updateControllerAim(frame, referenceSpace) {
  // Handles the trigger only once this frame, and doesn't carry a miss over to later
  const shouldMove = moveNekobi;
  moveNekobi = false;
  aimLine.visible = aimMarker.visible = false;
  if (!rightInputSource) return;
  const pose = frame.getPose(rightInputSource.targetRaySpace, referenceSpace);
  if (!pose) return;

  aimLine.matrix.fromArray(pose.transform.matrix);
  aimRaycaster.ray.origin.setFromMatrixPosition(aimLine.matrix);
  aimDirection.set(0, 0, -1).transformDirection(aimLine.matrix);
  aimRaycaster.ray.direction.copy(aimDirection);
  aimTargets.length = 0;
  aimHits.length = 0;
  for (const { mesh } of roomPlanes.values()) {
    if (!mesh.visible) continue;
    // Before drawing, checks for hits using the positions of surfaces that just arrived
    mesh.updateMatrixWorld(true);
    aimTargets.push(mesh);
  }
  aimRaycaster.intersectObjects(aimTargets, false, aimHits);
  const hit = aimHits[0];
  aimGeometry.attributes.position.setXYZ(1, 0, 0, -(hit ? hit.distance : 10));
  aimGeometry.attributes.position.needsUpdate = true;
  aimLine.visible = true;
  if (!hit) return;

  // Lays the circle along the surface it hit, floating slightly in front to avoid overlap
  aimNormalMatrix.getNormalMatrix(hit.object.matrixWorld);
  aimNormal.copy(hit.face.normal).applyNormalMatrix(aimNormalMatrix);
  if (aimNormal.dot(aimDirection) > 0) aimNormal.negate();
  aimMarker.position.copy(hit.point).addScaledVector(aimNormal, 0.002);
  aimMarker.quaternion.setFromUnitVectors(markerAxis, aimNormal);
  aimMarker.visible = true;

  if (!shouldMove) return;
  const viewerPose = frame.getViewerPose(referenceSpace);
  if (!viewerPose) return;
  // Moves the feet to the marker's position and keeps the body upright, facing the player
  nekobi.position.copy(hit.point);
  const viewerPosition = viewerPose.transform.position;
  const dx = viewerPosition.x - hit.point.x;
  const dz = viewerPosition.z - hit.point.z;
  if (dx * dx + dz * dz > 0.0001) nekobi.rotation.y = Math.atan2(dx, dz);
  nekobi.visible = true;
  placeNekobi = false;
}

/**
 * Called every frame
 * @param {number} delta Time since the last frame (seconds)
 * @param {number} elapsed Time since the start (seconds)
 */
function update(delta, elapsed) {
  if (!renderer.xr.isPresenting) return;
  const frame = renderer.xr.getFrame();
  const referenceSpace = renderer.xr.getReferenceSpace();
  if (!frame || !referenceSpace) return;
  updateRoomPlanes(frame, referenceSpace);
  updateControllerAim(frame, referenceSpace);
  if (!placeNekobi) return;
  const pose = frame.getViewerPose(referenceSpace);
  if (!pose) return;

  headRotation.copy(pose.transform.orientation);
  forward.set(0, 0, -1).applyQuaternion(headRotation);
  // Ignores up-and-down tilt and places it on the floor 1 meter ahead
  forward.y = 0;
  if (forward.lengthSq() < 0.0001) return;
  forward.normalize();
  nekobi.position.copy(pose.transform.position).add(forward);
  nekobi.position.y = 0;
  // The model's face points toward plus z, so this turns it to face the player
  nekobi.rotation.y = Math.atan2(-forward.x, -forward.z);
  nekobi.visible = true;
  placeNekobi = false;
}
