# Prompt Collection

These are the prompts from the book. Copy the text in a box and paste it into your chat with the AI.

## Chapter 1: Get Ready to Build

### Prompt 1-4-1 Say hello to the AI

```text
Hello. I'd like to work with you to build a VR project I can play in the Meta Quest browser. I've never programmed before. Nice to meet you.
```

### Prompt 1-4-2 Check for the tools and install what's missing

```text
Please check whether these tools are installed on my Mac. If any are missing, install them with Homebrew.

- Node.js
- adb (Android Platform Tools)

When you're done, show me the version of each in a table.
```

### Prompt 1-5-1 Have the AI run the dev server

```text
Please run the dev server.
```

### Prompt 1-6-1 Put a cube in front of me

```text
Using this template, please make a page I can play in VR.

- When I open the page on Quest, a "Play in VR" button appears
- Pressing the button takes me into VR
- A cube, 30 centimeters on each side, floats at eye level about 1 meter in front of me
- The cube slowly rotates
```

### Prompt 1-7-1 Check that the Quest is connected

```text
Please use adb to check whether a Meta Quest is connected to my Mac.
```

### Prompt 1-8-1 Have the AI read the Quest's logs

```text
Please read the Quest's logs and check for errors.
```

## Chapter 2: Get Good at Asking the AI

### Prompt 2-1-1 A request the AI won't understand

```text
Make the cube look nice.
```

### Prompt 2-1-2 A request the AI will understand

```text
Please make the cube floating in front of me bright red. Keep its size and position as they are.
```

### Prompt 2-2-1 Change the color

```text
Please make the cube in front of me bright red. Keep its size and position as they are.
```

### Prompt 2-2-2 Change the position and size

```text
Please move the red cube so it's 2 meters in front of me and 1 meter above the floor. Make it 50 centimeters on each side. Keep its color as it is.
```

### Prompt 2-2-3 Add another cube

```text
Please place one more cube, blue and the same size, to the right of the red cube, 1 meter away from it. Keep the red cube as it is.
```

### Prompt 2-3-1 Make it bob up and down

```text
Please make the blue cube gently bob up and down around its current position, over a range of about 20 centimeters. Move it slowly, taking about 3 seconds for one round trip. Keep the red cube's motion as it is.
```

### Prompt 2-3-2 Fix the rotation speed

```text
The red cube is rotating too fast. Please slow it down to about half its current speed.
```

### Prompt 2-4-1 Tell the AI what's going wrong

```text
The blue cube has stopped showing up. The red cube is still showing. Please read the Quest's logs, find the cause, and fix it.
```

### Prompt 2-4-2 Go back one step

```text
Please undo that last change and go back to the previous save point.
```

## Chapter 3: A Planet in Space

### Prompt 3-2-1 Place the planet

```text
Please place a sphere 1 meter in diameter at eye level, 2 meters in front of me, and make it a planet.

- For the pattern, please layer at least 10 thin horizontal stripes of cream and reddish brown, like Jupiter. Make the edges between the stripes wave a little, like flowing clouds, and blur them
- In the southern part, please add one reddish-brown oval, like the Great Red Spot
- Please create the pattern in code, without using image files
```

### Prompt 3-3-1 Shine sunlight on the planet

```text
Please remove the current light and have a white light, like the sun, shine on the planet from far away, diagonally above and to my left. Please make the side the light doesn't reach dark. But don't make it pitch black; keep it just bright enough to see faintly. Please leave the planet's pattern as it is.
```

### Prompt 3-4-1 Make the planet spin

```text
Please make the planet spin slowly around a vertical axis, taking about 20 seconds for one rotation. Please tilt the planet's axis just a little (about 20 degrees).
```

### Prompt 3-5-1 Send the moon into orbit

```text
Please make a moon that circles the planet.

- Make the moon a gray sphere 20 centimeters in diameter. On its surface, draw dark mottled patches and lots of craters in code, without using image files. Make the bumps of the craters cast shadows when light hits them
- Place an invisible "turntable" at the center of the planet. Make it turn separately from the planet's spin
- Make the moon a "child" of the turntable, and put it 1 meter from the turntable's center
- Turn the turntable so the moon goes around the planet once in about 10 seconds
```

### Prompt 3-6-1 Scatter stars in the background

```text
Please scatter about 2,000 small white stars at random in the distance all around. Place every star at least 50 meters away from me. To make it feel like space, please remove the floor grid. Please leave the planet and moon as they are.
```

### Prompt 3-6-2 Customization example: add a ring

```text
Please add a ring like Saturn's around the planet. Make the ring light brown and semi-transparent. Please make the ring tilt together with the planet.
```

## Chapter 4: Balloon Pop

### Prompt 4-2-1 Send a beam from the controllers

```text
Please send a thin white beam, about 5 meters long, straight forward from the tip of each of my two controllers.

- When I move a controller, its beam moves with it
- Also show the shape of the controllers in VR
- Please leave the sky and ground as they are
```

### Prompt 4-3-1 Place one balloon and make it poppable

```text
Please place one red balloon at eye level, 2 meters in front of me.

- Make the balloon a sphere 30 centimeters in diameter, stretched to be slightly taller, with a short string at the bottom
- While a beam is touching the balloon, make the balloon slightly brighter
- If I pull the trigger while a beam is touching it, make the balloon disappear and small pieces fly apart
- Please leave the beams as they are
```

### Prompt 4-4-1 Keep making balloons

```text
Please send out balloons like the last one, one after another, for the game.

- One balloon per second appears from the ground around me (in front, to the left, and to the right), 2 to 4 meters away
- Each new balloon rises slowly at about 50 centimeters per second, swaying slightly from side to side
- Its color is picked at random from red, blue, yellow, green, and pink
- Any balloon that goes higher than 8 meters is removed
- The practice balloon in front of me goes away
- The beams and the way balloons pop stay as they are
```

### Prompt 4-5-1 Show the score and time left

```text
Please add a score and a time limit to the game.

- Place a sign 3 meters straight ahead, at a height of 2.5 meters, and show "Score 0" and "Time 60s" (the time left) on it in large letters
- Each time I pop a balloon, add 1 to the score
- Pressing "Play in VR" starts the game. After 60 seconds, balloons stop appearing, and the sign shows "Game over! Score N" (with the score in place of N)
- If I pull the trigger after the game is over, the score goes back to 0 and the game starts again
```

### Prompt 4-6-1 Add sound and vibration when a balloon pops

```text
Please add feedback for when a balloon pops.

- Play a short "pop!" sound effect. Don't use a sound file; create the sound in code
- Make the sound come from where the balloon popped
- Briefly (for about 0.1 seconds) vibrate the controller in the hand that pulled the trigger
- Leave the game's rules and look as they are
```

### Prompt 4-7-1 Gather the tuning numbers in one place

```text
Please gather the numbers that set the game's difficulty (the interval between balloons, how fast they rise, their size, the time limit, and the points per balloon) in one place at the very top of the program. Give each number a short comment in English explaining what it is. Please keep the game's behavior as it is.
```

### Prompt 4-7-2 Make it gradually harder

```text
Please make the game get harder as time passes.

- For the first 20 seconds, send out balloons at a pace of one every 2 seconds
- For the last 20 seconds, send them out at a pace of two per second, and make them rise 1.5 times as fast
- In between, make things change little by little
```

### Prompt 4-7-3 Mix in special balloons

```text
Please mix in a gold balloon now and then. Gold balloons rise twice as fast as regular balloons and are worth 5 points when popped. Please make about 1 in 10 balloons gold.
```

### Prompt 4-7-4 Customization example: keep a high score

```text
Please remember the best score so far and show "Best N" on the sign (with the best score in place of N). Please keep the best score even when the page is reloaded. When the best score is beaten, turn the sign's text gold.
```

## Chapter 5: Nekobi in Your Room

### Prompt 5-2-1 Switch to MR

```text
Please change the "Play in VR" button to a "Play in MR" button.

- In MR, I should see my room all around me, as seen through the Quest's cameras
- Float a blue cube, 20 centimeters on each side, 1 meter in front of me at eye level
```

### Prompt 5-3-1 Place Nekobi's 3D model

```text
Please load the 3D model of Nekobi at `public/models/nekobi.glb` and place it in my room.

- Place it on the floor 1 meter in front of me, facing me
- Adjust its size so it's about 40 centimeters tall
- Remove the blue cube
```

### Prompt 5-4-1 Cast a shadow on the floor

```text
Please make a shadow fall on the floor at Nekobi's feet.

- Shine a light from above to create the shadow
- Make the shadow look like it's falling on my room's real floor. The panel that receives the shadow should itself be invisible
- Make the panel that receives the shadow a child of Nekobi, so it moves together with Nekobi
```

### Prompt 5-5-1 Show the room's surfaces

```text
Please show the room surfaces the Quest remembers (floors, walls, desks, and so on) as lightly colored panels.

- Make horizontal surfaces (floors and desks) green and vertical surfaces (walls) blue
- Make the panels almost transparent, so I can see the room behind them
- Keep Nekobi and the shadow as they are
```

### Prompt 5-6-1 Aim with the beam and place

```text
Please make a beam come out of the right controller.

- Show a round white marker where the beam hits a detected room surface
- When I pull the trigger, move Nekobi to the marker
- When Nekobi is placed, Nekobi should turn to face me
- Keep the colored surface panels as they are
```

### Prompt 5-7-1 Customization example: add more Nekobi

```text
Each time I pull the trigger, please add one more Nekobi at the marker. Let me place up to 5, and when I place a 6th, remove the oldest one. Give each Nekobi their own shadow.
```

## Chapter 6: Ball Play in Your Room

### Prompt 6-2-1 Grab and throw the ball

```text
Please float a red ball, 15 centimeters in diameter, 50 centimeters in front of me at waist height (1 meter above the floor).

- When I bring a controller close to the ball and squeeze the grip, I should be able to grab the ball
- When I release the grip, the ball should fly off with the momentum of my hand's motion at that moment
- Don't add gravity yet; the ball should fly in a straight line
- If the ball goes more than 5 meters away, return it to its original spot in front of me
```

### Prompt 6-3-1 Gravity and bouncing on the floor

```text
Please add gravity to the thrown ball.

- A thrown ball should fall along a parabolic arc
- When it hits the floor (height 0), it should bounce, bounce less and less, then roll along the floor and stop
- I should be able to grab a stopped ball again
- Keep the way grabbing and throwing work as they are
```

### Prompt 6-4-1 Bounce off the real walls and floor

```text
Please make the ball bounce off the room surfaces found by plane detection (floors, walls, desks, and so on).

- The detected surfaces can stay invisible
- So that the ball doesn't pass through a surface even when it's moving fast, check whether the line from the ball's position in the previous frame to its current position crosses a surface
- Keep gravity and the way grabbing and throwing work as they are
```

### Prompt 6-5-1 Put a target on the wall

```text
From the detected walls, please choose the nearest one and put a target on it.

- Make the target 40 centimeters in diameter, shaped like overlapping red and white circles, and put it 1.2 meters above the floor
- When the ball hits the target, play a short "ping!" sound and spin the target around once
- Above the target, show the number of hits as "Hits: 0", and add 1 with each hit
- If no wall is found, float the target 2 meters in front of me
```

### Prompt 6-6-1 Grab and throw with my hands

```text
When I put the controllers down, please let me play with the ball using my hands too.

- When I pinch with my thumb and index finger near the ball, I should be able to grab the ball
- When I open my fingers, the ball should fly off with the momentum of my hand's motion at that moment
- Show small spheres at the positions of my fingers, so I can see the shape of my hands
- Keep the way playing with controllers works as it is
```

### Prompt 6-7-1 Customization example: add more balls

```text
Each time I press the A button, please put one new ball in front of me. Let me have up to 5 balls, and when a 6th one appears, remove the oldest ball. Change the ball's color in order through red, blue, and yellow.
```

## Chapter 7: Publish It and Let Others Play

### Prompt 7-1-1 Publish to Cloudflare

```text
Please publish this project to Cloudflare.

- After npm run build, please publish it with npx wrangler deploy --assets ./dist --compatibility-date 2026-11-01. Please don't change package.json or vite.config.js
- Please name the project "balloon-game"
- If I need to log in, please tell me so, and I'll log in in the browser
- Once it's published, please tell me the address to open on Quest
```

### Prompt 7-2-1 Show the redraw count

```text
In VR / MR, please show in small text, at the bottom right of my view, how many times per second the picture is being redrawn (the frame rate). When it drops below 70, please make the number red. Please keep the project's motion and appearance as they are.
```

### Prompt 7-3-1 Make a QR code to hand out

```text
Please make a printable page (`share-qr.html`) with a QR code for the published address, and show it on my Mac's screen.

- Make the QR code with qrcode-generator, which is included in the template
- Put the project's name above the QR code and the address below it
- At the very bottom, write "Scan this with 'Scan QR code' in the Quest's Camera settings to play" and "Before you play, make sure there are no objects or people around you"
```
