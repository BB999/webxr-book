// Tests target placement, fast ball hits, the count, and one full spin without a real device.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { RoomCollisions } from '../src/room-collisions.js';
import { TargetGame, findNearestWall } from '../src/target-game.js';

function wall(z, width = 4, height = 3) {
  const matrix = new THREE.Matrix4().makeRotationX(Math.PI / 2).setPosition(0, 0, z);
  return [
    { orientation: 'vertical' },
    { matrix, inverse: matrix.clone().invert(), polygon: [
      { x: -width / 2, z: 0 }, { x: width / 2, z: 0 },
      { x: width / 2, z: -height }, { x: -width / 2, z: -height },
    ] },
  ];
}

function makeGame() {
  const texts = [];
  globalThis.document = { createElement: () => ({
    width: 0, height: 0,
    getContext: () => ({ clearRect() {}, fillRect() {}, fillText(text) { texts.push(text); } }),
  }) };
  const room = new RoomCollisions();
  const game = new TargetGame(new THREE.Scene(), new THREE.PerspectiveCamera(), room);
  let plays = 0;
  game.sound = { isPlaying: false, play() { plays++; } };
  return { room, game, texts, plays: () => plays };
}

test('skips the floor and picks the near wall at a height of 1.2 meters', () => {
  const far = wall(-3);
  const near = wall(1);
  const floor = [{ orientation: 'horizontal' }, { matrix: new THREE.Matrix4(), polygon: [] }];
  const target = findNearestWall(new Map([floor, far, near]), new THREE.Vector3(0, 1.6, 0));
  assert.equal(target.plane, near[0]);
  assert.ok(Math.abs(target.position.y - 1.2) < 1e-8);
  assert.ok(Math.abs(target.position.z - 1) < 1e-8);
  assert.ok(target.normal.z < 0);
});

test('uses distance to the finite outline, not the surface center, and stays one radius away from the outline edge', () => {
  const short = wall(-0.5, 1);
  const wide = wall(-1, 10);
  const target = findNearestWall(new Map([short, wide]), new THREE.Vector3(3, 1.6, 0));
  assert.equal(target.plane, wide[0]);
  assert.ok(Math.abs(target.position.x - 3) < 1e-8);
  const edge = findNearestWall(new Map([short]), new THREE.Vector3(3, 1.6, 0));
  assert.ok(Math.abs(edge.position.x - 0.3) < 1e-8);
});

test('with no wall, places it 2 meters ahead, at the same distance even with a different starting pose', () => {
  const { game } = makeGame();
  assert.deepEqual(game.group.position.toArray(), [0, 1.2, -2]);
  game.beginSession();
  const frame = { getViewerPose: () => ({ transform: {
    position: { x: 1, y: 1.6, z: 2 },
    orientation: new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI / 2),
  } }) };
  game.update(0.01, game.camera, new Map(), new THREE.Vector3(), 0.075, frame, {});
  assert.ok(game.group.position.distanceTo(new THREE.Vector3(-1, 1.2, 2)) < 1e-8);
});

test('counts a fast hit once, counts another after leaving, and returns to the start after one spin', () => {
  const { room, game, texts, plays } = makeGame();
  const start = new THREE.Vector3(0, 1.2, -1);
  const end = new THREE.Vector3(0, 1.2, -3);
  const velocity = new THREE.Vector3(0, 0, -100);
  room.resolve(start, end, velocity, 0.075, 0.02);
  assert.equal(game.hits, 1);
  assert.equal(plays(), 1);
  assert.ok(velocity.z > 0);
  game.hit();
  assert.equal(game.hits, 1);
  game.update(0.3, game.camera, new Map(), new THREE.Vector3(0, 1.2, -2), 0.075);
  assert.ok(Math.abs(game.disc.rotation.y - Math.PI) < 1e-8);
  game.update(0.3, game.camera, new Map(), new THREE.Vector3(0, 1.2, -1), 0.075);
  assert.equal(game.disc.rotation.y, 0);
  game.hit();
  assert.equal(game.hits, 2);
  assert.equal(texts.at(-1), 'Hits: 2');
  assert.equal(plays(), 2);
});

test('does not count hits outside the target or on a wall in front of the target', () => {
  const { room, game } = makeGame();
  const behind = new THREE.Vector3(1, 1.2, -3);
  room.resolve(new THREE.Vector3(1, 1.2, -1), behind, new THREE.Vector3(0, 0, -100), 0.075, 0.02);
  assert.equal(game.hits, 0);
  const obstruction = wall(-1.5);
  room.planes.set(...obstruction);
  const end = new THREE.Vector3(0, 1.2, -3);
  room.resolve(new THREE.Vector3(0, 1.2, -1), end, new THREE.Vector3(0, 0, -100), 0.075, 0.02);
  assert.equal(game.hits, 0);
});

test('attaches when a wall arrives, and goes back to a floating target when it disappears', () => {
  const { game } = makeGame();
  game.observer.set(0, 1.6, 0);
  const planes = new Map([wall(-1)]);
  game.update(0.3, game.camera, planes, new THREE.Vector3(), 0.075);
  assert.ok(Math.abs(game.group.position.z + 0.985) < 1e-8);
  assert.ok(Math.abs(game.group.position.y - 1.2) < 1e-8);
  game.update(0.3, game.camera, new Map(), new THREE.Vector3(), 0.075);
  assert.deepEqual(game.group.position.toArray(), [0, 1.2, -2]);
});
