// Draws finger positions as small balls, and handles pinching a nearby ball.
import * as THREE from 'three';

const wristPosition = new THREE.Vector3();
const indexDirection = new THREE.Vector3();
const pinkyDirection = new THREE.Vector3();
const palmNormal = new THREE.Vector3();

export function palmFacesUp(hand, handedness) {
  const wrist = hand.joints.wrist;
  const index = hand.joints['index-finger-metacarpal'];
  const pinky = hand.joints['pinky-finger-metacarpal'];
  // While the hand's direction is unknown, doesn't grab, since it can't be told apart from system gestures.
  if (!wrist?.visible || !index?.visible || !pinky?.visible ||
      (handedness !== 'left' && handedness !== 'right')) return true;
  wrist.getWorldPosition(wristPosition);
  index.getWorldPosition(indexDirection).sub(wristPosition);
  pinky.getWorldPosition(pinkyDirection).sub(wristPosition);
  palmNormal.crossVectors(indexDirection, pinkyDirection);
  if (palmNormal.lengthSq() < 1e-10) return true;
  palmNormal.normalize();
  if (handedness === 'left') palmNormal.negate();
  return palmNormal.y > 0.5;
}

export class HandBallInput {
  constructor(scene, xr, onGrab, onRelease, onLost) {
    this.onGrab = onGrab;
    this.onRelease = onRelease;
    this.onLost = onLost;
    this.thumbPosition = new THREE.Vector3();
    this.indexPosition = new THREE.Vector3();
    this.jointMatrix = new THREE.Matrix4();
    this.jointScale = new THREE.Vector3(0.006, 0.006, 0.006);
    // Prepares the balls once and reuses them. Doesn't keep adding more when the connection changes.
    const geometry = new THREE.SphereGeometry(1, 8, 6);
    const material = new THREE.MeshStandardMaterial({ color: 0xffffff });
    this.hands = [];
    for (let index = 0; index < 2; index++) {
      const hand = xr.getHand(index);
      const anchor = new THREE.Group();
      anchor.visible = false;
      scene.add(hand, anchor);
      const markers = new THREE.InstancedMesh(geometry, material, 25);
      markers.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      markers.frustumCulled = false;
      markers.count = 0;
      hand.add(markers);
      const state = { hand, anchor, markers, enabled: false, handedness: '', grabPending: false, releasePending: false };
      this.hands.push(state);
      hand.addEventListener('connected', (event) => {
        state.enabled = Boolean(event.data.hand);
        state.handedness = event.data.handedness;
        state.grabPending = false;
        state.releasePending = false;
      });
      hand.addEventListener('disconnected', () => {
        state.enabled = false;
        this.clearHand(state);
      });
      // After all finger positions are updated, update() decides where to grab.
      hand.addEventListener('pinchstart', () => { if (state.enabled) state.grabPending = true; });
      hand.addEventListener('pinchend', () => { if (state.enabled) state.releasePending = true; });
    }
  }

  clearHand(state) {
    state.anchor.visible = false;
    state.markers.count = 0;
    state.grabPending = false;
    state.releasePending = false;
    this.onLost(state.anchor);
  }

  clear() {
    for (const state of this.hands) this.clearHand(state);
  }

  update() {
    for (const state of this.hands) {
      const { hand, anchor, markers } = state;
      if (!state.enabled || !hand.visible) {
        this.clearHand(state);
        continue;
      }
      let count = 0;
      for (const name in hand.joints) {
        const joint = hand.joints[name];
        if (!joint.visible || count >= 25) continue;
        this.jointMatrix.compose(joint.position, joint.quaternion, this.jointScale);
        markers.setMatrixAt(count++, this.jointMatrix);
      }
      markers.count = count;
      markers.instanceMatrix.needsUpdate = true;

      const thumb = hand.joints['thumb-tip'];
      const index = hand.joints['index-finger-tip'];
      const wrist = hand.joints.wrist;
      if (!thumb?.visible || !index?.visible || !wrist?.visible) {
        anchor.visible = false;
        state.grabPending = false;
        state.releasePending = false;
        this.onLost(anchor);
        continue;
      }
      thumb.getWorldPosition(this.thumbPosition);
      index.getWorldPosition(this.indexPosition);
      anchor.position.copy(this.thumbPosition).add(this.indexPosition).multiplyScalar(0.5);
      wrist.getWorldQuaternion(anchor.quaternion);
      anchor.visible = true;
      if (state.grabPending) {
        state.grabPending = false;
        // Pinches with the palm facing up are left to the Quest's system.
        if (!palmFacesUp(hand, state.handedness)) this.onGrab(anchor);
      }
    }
  }

  finishFrame() {
    // Measures the throw speed from the last finger movement, then releases the ball.
    for (const state of this.hands) {
      if (!state.releasePending) continue;
      state.releasePending = false;
      this.onRelease(state.anchor);
    }
  }
}
