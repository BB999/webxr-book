// Checks detected room surfaces against the ball's path, and bounces it off invisible surfaces.
import * as THREE from 'three';

const SEPARATION = 0.0001;

// In a surface's coordinates the height is 0, so being inside the outline is checked with width and depth.
function insidePolygon(x, z, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const a = polygon[j];
    const b = polygon[i];
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const lengthSq = dx * dx + dz * dz;
    if (lengthSq > 0) {
      const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (z - a.z) * dz) / lengthSq));
      if ((x - a.x - t * dx) ** 2 + (z - a.z - t * dz) ** 2 < 1e-10) return true;
    }
    if ((a.z > z) !== (b.z > z) && x < a.x + (z - a.z) * dx / dz) inside = !inside;
  }
  return inside;
}

export class RoomCollisions {
  constructor() {
    this.planes = new Map();
    this.extraPlanes = [];
    this.start = new THREE.Vector3();
    this.end = new THREE.Vector3();
    this.localStart = new THREE.Vector3();
    this.localEnd = new THREE.Vector3();
    this.normal = new THREE.Vector3();
    this.remainder = new THREE.Vector3();
  }

  *collisionPlanes() {
    yield* this.planes.values();
    yield* this.extraPlanes;
  }

  clear() {
    // Creates nothing to draw. When the session ends, clears only the surface data.
    this.planes.clear();
  }

  update(frame, referenceSpace) {
    const detected = frame?.detectedPlanes;
    if (!detected || !referenceSpace) {
      this.clear();
      return;
    }
    for (const plane of this.planes.keys()) {
      if (!detected.has(plane)) this.planes.delete(plane);
    }
    for (const plane of detected) {
      const pose = frame.getPose(plane.planeSpace, referenceSpace);
      if (!pose || plane.polygon.length < 3) {
        this.planes.delete(plane);
        continue;
      }
      let data = this.planes.get(plane);
      if (!data) {
        data = { matrix: new THREE.Matrix4(), inverse: new THREE.Matrix4() };
        this.planes.set(plane, data);
      }
      // Updates position and direction every frame, separately from when the outline was updated.
      data.matrix.fromArray(pose.transform.matrix);
      data.inverse.copy(data.matrix).invert();
      data.polygon = plane.polygon;
    }
  }

  resolve(previousPosition, position, velocity, radius, delta) {
    this.start.copy(previousPosition);
    this.end.copy(position);
    // Even when bouncing from one wall to another in the same move, checks the nearest collision first.
    for (let bounce = 0; bounce < 8; bounce++) {
      let nearest = Infinity;
      let hitPlane = null;
      let hitSide = 1;
      let hitHeight = 0;
      for (const data of this.collisionPlanes()) {
        this.localStart.copy(this.start).applyMatrix4(data.inverse);
        this.localEnd.copy(this.end).applyMatrix4(data.inverse);
        const side = this.localStart.y >= 0 ? 1 : -1;
        const from = this.localStart.y * side;
        const to = this.localEnd.y * side;
        if (to >= from || to > radius) continue;
        // Shifts the center's path by the radius to find the moment the ball's edge touches the surface.
        const t = Math.max(0, (from - radius) / (from - to));
        if (t > 1 || t >= nearest) continue;
        const x = THREE.MathUtils.lerp(this.localStart.x, this.localEnd.x, t);
        const z = THREE.MathUtils.lerp(this.localStart.z, this.localEnd.z, t);
        if (data.contains ? !data.contains(x, z, radius) : !insidePolygon(x, z, data.polygon)) continue;
        nearest = t;
        hitPlane = data;
        hitSide = side;
        hitHeight = THREE.MathUtils.lerp(from, to, t);
      }
      if (!hitPlane) {
        position.copy(this.end);
        return;
      }

      this.normal.set(0, hitSide, 0).transformDirection(hitPlane.matrix);
      this.remainder.copy(this.end).sub(this.start).multiplyScalar(1 - nearest);
      this.start.lerp(this.end, nearest);
      this.start.addScaledVector(this.normal, radius - hitHeight + SEPARATION);

      const incomingSpeed = velocity.dot(this.normal);
      if (incomingSpeed < 0) {
        hitPlane.onHit?.();
        const reboundSpeed = -incomingSpeed * 0.55;
        // On floors and desks, stops small bounces and slows down with the same friction as the earlier floor.
        const resting = this.normal.y > 0.5 && reboundSpeed < 0.35;
        velocity.addScaledVector(this.normal, (resting ? 0 : reboundSpeed) - incomingSpeed);
        const normalMovement = this.remainder.dot(this.normal);
        if (normalMovement < 0) {
          this.remainder.addScaledVector(this.normal, -(resting ? 1 : 1.55) * normalMovement);
        }
        if (resting) {
          const speed = velocity.length();
          const factor = speed > 0 ? Math.max(0, speed - 0.7 * delta) / speed : 0;
          velocity.multiplyScalar(factor);
          this.remainder.multiplyScalar(factor);
        }
      }
      this.end.copy(this.start).add(this.remainder);
    }
    // After many collisions in a tight gap or similar spot, stops at the last contact point to prevent passing through.
    position.copy(this.start);
    velocity.set(0, 0, 0);
  }
}
