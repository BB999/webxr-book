// Places a target on a nearby wall and manages the hit sound, spin, and hit count display.
import * as THREE from 'three';

const TARGET_HEIGHT = 1.2;
const TARGET_RADIUS = 0.2;
const up = new THREE.Vector3(0, 1, 0);

// Picks the spot closest to the player on the line crossing the wall's outline at a height of 1.2 meters.
export function findNearestWall(planes, observer) {
  let best = null;
  let bestDistance = Infinity;
  for (const [plane, data] of planes) {
    const normal = new THREE.Vector3(0, 1, 0).transformDirection(data.matrix);
    if (plane.orientation !== 'vertical' && Math.abs(normal.y) > 0.2) continue;
    const vertices = data.polygon.map((p) => new THREE.Vector3(p.x, 0, p.z).applyMatrix4(data.matrix));
    const crossings = [];
    for (let i = 0; i < vertices.length; i++) {
      const a = vertices[i];
      const b = vertices[(i + 1) % vertices.length];
      if ((a.y > TARGET_HEIGHT) === (b.y > TARGET_HEIGHT)) continue;
      crossings.push(a.clone().lerp(b, (TARGET_HEIGHT - a.y) / (b.y - a.y)));
    }
    const along = new THREE.Vector3().crossVectors(up, normal).normalize();
    crossings.sort((a, b) => a.dot(along) - b.dot(along));
    for (let i = 0; i + 1 < crossings.length; i += 2) {
      const a = crossings[i];
      const b = crossings[i + 1];
      const segment = b.clone().sub(a);
      const length = segment.length();
      if (length < TARGET_RADIUS * 2) continue;
      const t = THREE.MathUtils.clamp(
        observer.clone().sub(a).dot(segment) / (length * length),
        TARGET_RADIUS / length, 1 - TARGET_RADIUS / length,
      );
      const position = a.clone().addScaledVector(segment, t);
      const distance = position.distanceToSquared(observer);
      if (distance >= bestDistance) continue;
      bestDistance = distance;
      const facing = normal.clone();
      if (observer.clone().sub(position).dot(facing) < 0) facing.negate();
      best = { position, normal: facing, plane };
    }
  }
  return best;
}

export class TargetGame {
  constructor(scene, camera, roomCollisions) {
    this.camera = camera;
    this.group = new THREE.Group();
    scene.add(this.group);
    this.disc = new THREE.Group();
    this.group.add(this.disc);
    // Makes a red and white target from circles with the same center, each shifted slightly forward.
    const red = new THREE.MeshBasicMaterial({ color: 0xff2020, side: THREE.DoubleSide });
    const white = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
    for (let i = 0; i < 5; i++) {
      const circle = new THREE.Mesh(new THREE.CircleGeometry(TARGET_RADIUS * (5 - i) / 5, 64), i % 2 ? white : red);
      circle.position.z = i * 0.0005;
      this.disc.add(circle);
    }
    this.canvas = document.createElement('canvas');
    this.canvas.width = 512;
    this.canvas.height = 128;
    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    const label = new THREE.Mesh(
      new THREE.PlaneGeometry(0.6, 0.15),
      new THREE.MeshBasicMaterial({ map: this.texture, transparent: true, side: THREE.DoubleSide }),
    );
    label.position.set(0, 0.32, 0.003);
    this.group.add(label);
    this.hits = 0;
    this.remainingTurn = 0;
    this.contactLocked = false;
    this.observer = new THREE.Vector3();
    this.forward = new THREE.Vector3(0, 0, -1);
    this.localBall = new THREE.Vector3();
    this.refreshIn = 0;
    this.needsObserver = false;
    this.fallbackPosition = new THREE.Vector3(0, TARGET_HEIGHT, -2);
    this.fallbackNormal = new THREE.Vector3(0, 0, 1);
    this.group.position.copy(this.fallbackPosition);
    this.surface = {
      matrix: new THREE.Matrix4(), inverse: new THREE.Matrix4(),
      contains: (x, z, radius) => x * x + z * z <= (TARGET_RADIUS + radius) ** 2,
      onHit: () => this.hit(),
    };
    roomCollisions.extraPlanes.push(this.surface);
    // Prepares the sound only on a hit. Playback uses three.js's audio system.
    this.sound = null;
    this.drawScore();
    this.updateSurface();
  }

  drawScore() {
    const g = this.canvas.getContext('2d');
    g.clearRect(0, 0, 512, 128);
    g.fillStyle = 'rgba(255,255,255,0.95)';
    g.fillRect(0, 0, 512, 128);
    g.fillStyle = '#c01010';
    g.font = 'bold 72px sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(`Hits: ${this.hits}`, 256, 64);
    this.texture.needsUpdate = true;
  }

  beginSession() {
    this.needsObserver = true;
    this.refreshIn = 0;
    this.contactLocked = false;
  }

  endSession() {
    this.needsObserver = false;
    this.observer.set(0, 1.6, 0);
    this.fallbackPosition.set(0, TARGET_HEIGHT, -2);
    this.fallbackNormal.set(0, 0, 1);
    this.refreshIn = 0;
  }

  updateSurface() {
    // Even when the target spins, the hit check keeps the position of the circle on the wall.
    this.group.updateMatrixWorld(true);
    this.surface.matrix.copy(this.group.matrixWorld).multiply(new THREE.Matrix4().makeRotationX(Math.PI / 2));
    this.surface.inverse.copy(this.surface.matrix).invert();
  }

  update(delta, head, planes, ballPosition, ballRadius, frame, referenceSpace) {
    if (this.needsObserver) {
      // Uses the current head position and direction even before the session's first draw.
      const pose = frame && referenceSpace ? frame.getViewerPose(referenceSpace) : null;
      if (pose) {
        this.observer.copy(pose.transform.position);
        this.forward.set(0, 0, -1).applyQuaternion(new THREE.Quaternion().copy(pose.transform.orientation));
      } else {
        head.getWorldPosition(this.observer);
        head.getWorldDirection(this.forward);
      }
      this.forward.y = 0;
      if (this.forward.lengthSq() < 0.001) this.forward.set(0, 0, -1);
      this.forward.normalize();
      this.fallbackPosition.copy(this.observer).addScaledVector(this.forward, 2);
      this.fallbackPosition.y = TARGET_HEIGHT;
      this.fallbackNormal.copy(this.forward).negate();
      this.needsObserver = false;
    }
    // Chooses based on where you first stood, so the target doesn't slide along the wall when you move your head.
    this.refreshIn -= delta;
    if (this.refreshIn <= 0) {
      this.refreshIn = 0.25;
      const wall = findNearestWall(planes, this.observer);
      const position = wall ? wall.position : this.fallbackPosition;
      const normal = wall ? wall.normal : this.fallbackNormal;
      this.group.position.copy(position).addScaledVector(normal, wall ? 0.015 : 0);
      this.group.lookAt(position.clone().add(normal));
      this.updateSurface();
    }
    this.localBall.copy(ballPosition).applyMatrix4(this.surface.inverse);
    // Doesn't count the same contact twice until the ball leaves the target.
    if (Math.abs(this.localBall.y) > ballRadius + 0.04 ||
        Math.hypot(this.localBall.x, this.localBall.z) > TARGET_RADIUS + ballRadius + 0.04) {
      this.contactLocked = false;
    }
    if (this.remainingTurn > 0) {
      const turn = Math.min(this.remainingTurn, delta * Math.PI * 2 / 0.6);
      this.disc.rotation.y += turn;
      this.remainingTurn -= turn;
      if (this.remainingTurn <= 0) this.disc.rotation.y = 0;
    }
  }

  hit() {
    if (this.contactLocked) return;
    this.contactLocked = true;
    this.hits++;
    this.drawScore();
    this.remainingTurn += Math.PI * 2;
    if (!this.sound) {
      const listener = new THREE.AudioListener();
      this.camera.add(listener);
      this.sound = new THREE.Audio(listener);
      const context = listener.context;
      const buffer = context.createBuffer(1, Math.ceil(context.sampleRate * 0.18), context.sampleRate);
      const samples = buffer.getChannelData(0);
      for (let i = 0; i < samples.length; i++) {
        const t = i / context.sampleRate;
        samples[i] = Math.sin(2 * Math.PI * 1400 * t) * Math.exp(-t * 32) * Math.min(1, t / 0.003) * 0.35;
      }
      this.sound.setBuffer(buffer);
    }
    if (this.sound.isPlaying) this.sound.stop();
    this.sound.play();
  }
}
