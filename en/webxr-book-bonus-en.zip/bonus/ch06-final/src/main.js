// The project's entry point. Builds a 3D world with three.js that you can see in VR on Quest
// Write your project under the "Your project goes below this line" line at the very bottom
// The ground rules for the AI are in AGENTS.md (for Codex) and CLAUDE.md (for Claude)
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- The three actors: the stage (scene), the eyes (camera), and the artist (renderer) ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // Background color (turns transparent automatically in MR, so you can see the room)

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // Eye height of 1.5 meters (in VR, it moves with your head on the Quest)

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // Puts the floor at height 0
document.body.appendChild(renderer.domElement);

// ---- Lights ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // Light that shines evenly on everything
const sun = new THREE.DirectionalLight(0xffffff, 2);            // Light that comes from one direction
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- Floor grid (each square is 1 meter). A guide for judging size. Hidden in MR, where you can see the real floor ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- When viewing in the Mac browser: drag with the mouse to look around (not used in VR) ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- "Play in MR" button (you can see the room. The background turns transparent automatically) ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-ar', 'Play in MR'));

// ---- Also shows errors in VR (read the logs with npm run log) ----
const debug = setupDebugPanel(scene, renderer);

// ---- Repeats every frame: moves things in update() below, then redraws ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // Keeps things from jumping ahead after a pause
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // Keeps drawing even after an error (the error appears on the red panel)
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- When the browser window changes size, resizes the picture to match ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== Your project goes below this line ========
// Put things on the stage with scene.add(). Units are meters. The floor is at height 0, and straight ahead is the minus z direction
// Write anything you want to move every frame inside update() below

import { RoomCollisions } from './room-collisions.js';
import { TargetGame } from './target-game.js';
import { HandBallInput } from './hand-ball-input.js';

const roomCollisions = new RoomCollisions();
const movementStart = new THREE.Vector3();
const ballHome = new THREE.Vector3(0, 1, -0.5);
const ball = new THREE.Mesh(
  new THREE.SphereGeometry(0.075, 24, 16),
  new THREE.MeshStandardMaterial({ color: 0xff0000 }),
);
ball.position.copy(ballHome);
scene.add(ball);

const ballVelocity = new THREE.Vector3();
const previousBallPosition = new THREE.Vector3();
const currentBallPosition = new THREE.Vector3();
const gripPosition = new THREE.Vector3();
let heldBy = null;
let ballReleased = false;
const ballRadius = 0.075;
const rollingAxis = new THREE.Vector3();
const targetGame = new TargetGame(scene, camera, roomCollisions);

function resetBall() {
  scene.attach(ball);
  heldBy = null;
  ballReleased = false;
  ball.position.copy(ballHome);
  ball.quaternion.identity();
  ballVelocity.set(0, 0, 0);
}

// Uses the same closeness check and throw speed for hands and controllers.
function grabBall(holder) {
  if (heldBy || !holder.visible) return;
  holder.getWorldPosition(gripPosition);
  ball.getWorldPosition(currentBallPosition);
  // Can grab within about 5 centimeters of the ball's surface.
  if (gripPosition.distanceTo(currentBallPosition) > 0.125) return;
  heldBy = holder;
  holder.attach(ball);
  previousBallPosition.copy(currentBallPosition);
  ballVelocity.set(0, 0, 0);
}

function releaseBall(holder) {
  if (heldBy !== holder) return;
  // Keeps its position when the stage becomes its parent again, and flies at the speed it was just moving.
  scene.attach(ball);
  heldBy = null;
  ballReleased = true;
}

const handInput = new HandBallInput(scene, renderer.xr, grabBall, releaseBall, (holder) => {
  if (heldBy === holder) resetBall();
});

// On both sides, grabs near the controller itself, not at the end of the beam.
for (let index = 0; index < 2; index++) {
  const controller = renderer.xr.getController(index);
  const grip = renderer.xr.getControllerGrip(index);
  scene.add(controller, grip);

  controller.addEventListener('squeezestart', (event) => {
    if (!event.data?.hand) grabBall(grip);
  });

  controller.addEventListener('squeezeend', () => releaseBall(grip));
  controller.addEventListener('disconnected', () => {
    if (heldBy === grip) resetBall();
  });
}

renderer.xr.addEventListener('sessionend', resetBall);
renderer.xr.addEventListener('sessionend', () => handInput.clear());
renderer.xr.addEventListener('sessionend', () => roomCollisions.clear());
renderer.xr.addEventListener('sessionstart', () => targetGame.beginSession());
renderer.xr.addEventListener('sessionend', () => targetGame.endSession());

/**
 * Called every frame
 * @param {number} delta Time since the last frame (seconds)
 * @param {number} elapsed Time since the start (seconds)
 */
function update(delta, elapsed) {
  const frame = renderer.xr.getFrame();
  const referenceSpace = renderer.xr.getReferenceSpace();
  roomCollisions.update(frame, referenceSpace);
  handInput.update();
  ball.getWorldPosition(currentBallPosition);
  targetGame.update(delta, renderer.xr.isPresenting ? renderer.xr.getCamera() : camera,
    roomCollisions.planes, currentBallPosition, ballRadius, frame, referenceSpace);
  if (heldBy) {
    if (!heldBy.visible) {
      resetBall();
      return;
    }
    ball.getWorldPosition(currentBallPosition);
    if (delta > 0) {
      ballVelocity.copy(currentBallPosition).sub(previousBallPosition).divideScalar(delta);
    }
    previousBallPosition.copy(currentBallPosition);
  } else if (ballReleased) {
    // Splits time into small steps to keep floor bounces stable, even with long gaps between draws.
    const steps = Math.max(1, Math.ceil(delta / (1 / 120)));
    const step = delta / steps;
    for (let i = 0; i < steps; i++) {
      movementStart.copy(ball.position);
      // Gravity speeds it up downward, so it falls in an arc.
      ball.position.addScaledVector(ballVelocity, step);
      ball.position.y -= 0.5 * 9.8 * step * step;
      ballVelocity.y -= 9.8 * step;

      roomCollisions.resolve(movementStart, ball.position, ballVelocity, ballRadius, step);

      // Touches the floor at a height equal to its radius. Loses momentum with each bounce.
      if (ball.position.y <= ballRadius) {
        ball.position.y = ballRadius;
        if (ballVelocity.y < 0) {
          ballVelocity.y = -ballVelocity.y * 0.55;
          if (ballVelocity.y < 0.35) ballVelocity.y = 0;
        }

        if (ballVelocity.y === 0) {
          // Once small bounces stop, friction with the floor slows its rolling.
          const speed = Math.hypot(ballVelocity.x, ballVelocity.z);
          const nextSpeed = Math.max(0, speed - 0.7 * step);
          if (speed > 0) {
            rollingAxis.set(ballVelocity.z, 0, -ballVelocity.x).normalize();
            ball.rotateOnWorldAxis(rollingAxis, speed * step / ballRadius);
            ballVelocity.x *= nextSpeed / speed;
            ballVelocity.z *= nextSpeed / speed;
          }
        }
      }
    }
    if (ball.position.lengthSq() > 5 * 5) resetBall();
  }
  handInput.finishFrame();
}
