# ch01-final

This is the finished version for Chapter 1 of *The WebXR Textbook Even a Stray Cat Can Understand*. A rotating cube floats in front of you.

This finished version was made by typing the book's prompts into an AI. The AI writes a slightly different program every time, so it's fine if your project is different.

## How to Use It

1. In Terminal, move to this folder (type `cd `, drag this folder onto Terminal, and press `return`)
2. Run `npm install` (only the first time)
3. The first time only, run `npm run dev`, enter your Mac password, and stop it with `control` + `C` when an address appears (this creates the certificate. You only do it once per Mac)
4. Start the AI with `claude` (Claude Code) or `codex` (Codex), and ask it to "run the dev server"
5. Open the `https://192.168.…:5173` address the AI gives you in the Quest browser

For details, see Chapter 1 of the book.

## What's Inside

- three.js 0.186.1 and Vite (the dev server). It uses HTTPS through mkcert, so a Quest on the same Wi-Fi can open it
- A "Play in VR" button (you can add an MR button too)
- A red panel that shows errors in VR
- A script that reads the Quest browser's logs on the Mac (`npm run log`)
- Scripts that run, stop, and check the dev server in the background (`npm run start` / `stop` / `status`. Output goes to `dev.log`). The dev server keeps running after the AI conversation ends. When it runs, it shows a QR code of the Quest address on your Mac's screen (scan it with Scan QR code in the Quest's Camera settings. If you can't find that, open XRQR in the Quest browser to scan it)
- Ground rules for the AI (`CLAUDE.md` for Claude, `AGENTS.md` for Codex. Both have the same content)
- A setting that lets the AI make save points (git) without asking permission each time (for Claude, also when running and stopping the dev server) (`.claude/settings.json` for Claude, `.codex/rules/default.rules` for Codex). Risky operations such as `git push` are blocked. For other commands, the AI asks before running them
