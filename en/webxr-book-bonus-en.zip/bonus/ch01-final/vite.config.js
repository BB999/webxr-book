// Dev server settings. mkcert enables HTTPS so a Quest on the same Wi-Fi can open the page
import { defineConfig } from 'vite';
import mkcert from 'vite-plugin-mkcert';

export default defineConfig({
  plugins: [mkcert()],
  server: {
    host: true,        // Let other devices on the Wi-Fi (the Quest) open the page
    port: 5173,        // The last number in the address. Always the same, so bookmarks keep working
    strictPort: true,  // If 5173 is in use, stop instead of switching to another number
  },
  build: {
    chunkSizeWarningLimit: 2000,  // three.js is big, so raise the threshold for the "file is large" warning
  },
});
