// Script that runs, stops, and checks the dev server (vite) in the background (npm run start / stop / status)
// Starts it as a separate process so it keeps running after the AI conversation ends. Output goes to dev.log
// Once it's running, shows a QR code of the Quest address (quest-qr.html) on the Mac's screen. Scan it with "Scan QR code" in the Quest's Camera settings (if you can't find that, open XRQR (xrqr.net) in the Quest browser to scan it)
import { spawn, execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import qrcode from 'qrcode-generator';

const PORT = 5173;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const logFile = path.join(root, 'dev.log');
const qrFile = path.join(root, 'quest-qr.html');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// The IDs of the processes listening on port 5173 (including a dev server from an earlier chapter)
function listeners() {
  try {
    return execFileSync('lsof', ['-ti', `tcp:${PORT}`, '-sTCP:LISTEN'], { encoding: 'utf8' }).split('\n').filter(Boolean).map(Number);
  } catch {
    return [];
  }
}

// The addresses to open on Quest (the Mac's Wi-Fi IP address)
function addresses() {
  const list = [`https://localhost:${PORT}/`];
  for (const nets of Object.values(os.networkInterfaces())) {
    for (const n of nets ?? []) if (n.family === 'IPv4' && !n.internal) list.push(`https://${n.address}:${PORT}/`);
  }
  return list;
}

function printAddresses() {
  const [local, ...network] = addresses();
  for (const a of network) console.log(`  Address for your Quest: ${a}`);
  console.log(`  Address for your Mac's browser: ${local}`);
}

// Writes a page with a QR code of the Quest address. If open is true, shows it on the Mac's screen
// XRQR (used on Quests that haven't gotten the update) can't read when the camera sees several QR codes, so there's only one. Picks the address most likely to be home Wi-Fi (192.168.… and so on) and lists the others as text
function writeQr(open) {
  const rank = (a) => (/\/\/192\.168\./.test(a) ? 0 : /\/\/10\./.test(a) ? 1 : /\/\/172\.(1[6-9]|2\d|3[01])\./.test(a) ? 2 : 3);
  const [main, ...others] = addresses().slice(1).sort((a, b) => rank(a) - rank(b));
  if (!main) return;
  const qr = qrcode(0, 'M');
  qr.addData(main);
  qr.make();
  const more = others.length ? `<p class="more">If it won't open, try typing one of these addresses into the Quest's address bar: ${others.join(' ')}</p>` : '';
  fs.writeFileSync(qrFile, `<!doctype html><html lang="en"><meta charset="utf-8"><title>Open on Quest</title>
<style>body{font-family:sans-serif;text-align:center;background:#fff;color:#222;margin:24px}svg{width:min(60vh,80vw);height:auto}.addr{font-size:22px}.more{font-size:14px;color:#666}</style>
<h1>Open on Quest</h1><p>Scan this QR code with "Scan QR code" in the Quest's Camera settings (if you can't find that, open xrqr.net in the Quest browser to scan it)</p>
${qr.createSvgTag({ cellSize: 10, margin: 4, scalable: true })}<p class="addr">${main}</p>${more}</html>`);
  if (open) {
    try { execFileSync('open', [qrFile]); } catch {}
  }
}

async function stop() {
  const pids = listeners();
  for (const pid of pids) {
    try { process.kill(pid, 'SIGTERM'); } catch {}
  }
  for (let i = 0; i < 50 && listeners().length; i++) await sleep(100);
  return pids.length > 0;
}

async function start() {
  if (await stop()) console.log('Stopped the dev server that was already running');
  const out = fs.openSync(logFile, 'w');
  const vite = path.join(root, 'node_modules', 'vite', 'bin', 'vite.js');
  const child = spawn(process.execPath, [vite], { cwd: root, detached: true, stdio: ['ignore', out, out], env: { ...process.env, NO_COLOR: '1' } });
  child.unref();
  // Waits until the startup notice (Network: …) appears in dev.log
  for (let i = 0; i < 150; i++) {
    await sleep(100);
    const log = fs.readFileSync(logFile, 'utf8');
    if (/Network:/.test(log) && listeners().length) {
      console.log('✔ Started the dev server (output goes to dev.log)');
      printAddresses();
      writeQr(true);
      console.log('  Put the QR code of the Quest address on the Mac\'s screen (quest-qr.html)');
      process.exit(0);
    }
    if (child.exitCode !== null) break;
  }
  // The certificate's source (the HTTPS key) is registered once, the first time, after asking for the Mac password. A background process can't ask for the password
  if (/a terminal is required to read the password/.test(fs.readFileSync(logFile, 'utf8'))) {
    console.log('✖ Setting up the certificate needs the Mac password. Ask the builder to quit the AI for now (control + C twice), run npm run dev once in Terminal, enter the password, and stop it with control + C when an address appears (section 1-3 of the book)');
    process.exit(1);
  }
  console.log('✖ The dev server did not start. End of dev.log:');
  console.log(fs.readFileSync(logFile, 'utf8').split('\n').slice(-20).join('\n'));
  process.exit(1);
}

const command = process.argv[2];
if (command === 'start') {
  await start();
} else if (command === 'stop') {
  console.log((await stop()) ? '✔ Stopped the dev server' : 'The dev server was not running');
} else if (command === 'status') {
  if (listeners().length) {
    console.log('✔ The dev server is running (output goes to dev.log)');
    printAddresses();
    writeQr(false);
    console.log('  Also rebuilt the QR code page (quest-qr.html) with the current address');
  } else {
    console.log('The dev server is stopped (start it with npm run start)');
  }
} else {
  console.log('Usage: node scripts/dev-server.mjs start | stop | status');
  process.exit(1);
}
