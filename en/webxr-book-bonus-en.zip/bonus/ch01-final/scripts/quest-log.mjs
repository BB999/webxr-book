// Prints the Quest browser's logs (console.log and errors) in Terminal on the Mac
// Usage:
//   npm run log                   … Prints the logs saved so far, then waits 20 seconds for new logs
//   npm run log -- --seconds 60   … Waits 60 seconds for new logs
//   npm run log -- --reload       … Reloads the page to see the logs from the start (if you're in VR / MR, this takes you out)
//   npm run log -- --list         … Lists the pages open in the Quest browser
//   npm run log -- --url text     … Only watches pages whose address contains this text (the default is HTTPS pages on port 5173)
// How it works: adb connects the Quest browser's inspection port (DevTools) to the Mac and receives the logs
// Note: The Quest browser's console.log doesn't appear in adb logcat. Read it with this script
import { execFileSync } from 'node:child_process';

const args = process.argv.slice(2);
const has = (name) => args.includes(name);
const value = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] ? args[i + 1] : fallback;
};
const seconds = Number(value('--seconds', 20));
const urlFilter = value('--url', null);
const PORT = 9222;

const fail = (message) => {
  console.log(`✖ ${message}`);
  process.exit(1);
};
const adb = (...a) => execFileSync('adb', a, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
// Removes control characters that would garble Terminal from text the page produced (keeps line breaks and tabs)
const clean = (text) => String(text).replace(/[\x00-\x08\x0b-\x1f\x7f-\x9f]/g, '');
const isDevServerPage = (url) => {
  try {
    const { protocol, port } = new URL(url);
    return protocol === 'https:' && port === '5173';
  } catch {
    return false;
  }
};

// 1. Checks that adb exists and the Quest is connected
try {
  adb('version');
} catch {
  fail('adb not found. Ask the AI: "Please install adb (Android Platform Tools) with Homebrew."');
}
const devices = adb('devices')
  .split('\n')
  .slice(1)
  .map((line) => line.trim().split(/\s+/))
  .filter(([id, state]) => id && state);
if (devices.some(([, state]) => state === 'unauthorized')) {
  fail('The Quest is waiting for an answer to "Allow USB debugging?". Put on the Quest and press "Allow".');
}
const ready = devices.filter(([, state]) => state === 'device').map(([id]) => id);
if (!ready.length) {
  fail('Quest not found. Connect it with a USB cable (section 1-7 of the book). If it was connected over Wi-Fi, restarting the Quest drops the connection.');
}
const device = value('--device', ready[0]);

// 2. Connects the Quest browser's port to port 9222 on the Mac
adb('-s', device, 'forward', `tcp:${PORT}`, 'localabstract:chrome_devtools_remote');
// On exit, closes the port we connected (if left open, other programs on the Mac could also control the browser)
process.on('exit', () => {
  try {
    adb('-s', device, 'forward', '--remove', `tcp:${PORT}`);
  } catch {}
});
process.on('SIGINT', () => process.exit(130));
process.on('SIGTERM', () => process.exit(143));
let pages;
try {
  pages = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
} catch {
  fail('Couldn\'t connect to the Quest browser. Open the browser on the Quest and try again.');
}
pages = pages.filter((p) => p.type === 'page');
if (has('--list')) {
  pages.forEach((p) => console.log(clean(`${p.title}  ${p.url}`)));
  process.exit(0);
}
const targets = pages.filter((p) => (urlFilter ? p.url.includes(urlFilter) : isDevServerPage(p.url)));
if (!targets.length) {
  fail(`${urlFilter ? `No page with "${urlFilter}" in its address` : 'No dev server page (port 5173)'} is open in the Quest browser. Open pages:\n` +
    pages.map((p) => clean(`  ${p.url}`)).join('\n'));
}

// 3. Receives the logs and prints them in an easy-to-read form
let errors = 0;
let warnings = 0;
let lastLine = '';
let repeats = 0;
const stamp = (ms) => new Date(ms).toTimeString().slice(0, 8);
// When the same line repeats, combines it into one line (so errors that occur every frame don't fill the screen)
const flushRepeats = () => {
  if (repeats) console.log(`  (same line, ${repeats} more times)`);
  repeats = 0;
};
const print = (level, text, where, ms = Date.now(), count = 1) => {
  const mark = level === 'error' ? '✖ Error' : level === 'warning' || level === 'warn' ? '△ Warning' : '•';
  const line = clean(`${mark} ${text}${where ? `  (${where})` : ''}`);
  if (line === lastLine) {
    repeats++;
    return;
  }
  flushRepeats();
  lastLine = line;
  if (level === 'error') errors++;
  if (level === 'warning' || level === 'warn') warnings++;
  console.log(`[${stamp(ms)}] ${line}${count > 1 ? `  (${count} times)` : ''}`);
};
const describe = (remote) =>
  remote.value !== undefined ? (typeof remote.value === 'string' ? remote.value : JSON.stringify(remote.value))
    : remote.description ?? remote.unserializableValue ?? `[${remote.type}]`;
const placeOf = (stack) => {
  const frame = stack?.callFrames?.find((f) => !f.url.includes('debug-panel'));
  return frame ? `${frame.url.split('/').pop().split('?')[0]}:${frame.lineNumber + 1}` : '';
};

for (const page of targets) {
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  let nextId = 0;
  const send = (method, params = {}) => ws.send(JSON.stringify({ id: ++nextId, method, params }));
  let historyId = -1;
  // Logs that arrive before the reply to Runtime.enable are "earlier logs" the Quest resends the moment we connect.
  // On a template page, these are the same as the "logs so far" (window.__questLog), so they aren't printed (to avoid counting them twice)
  let enabled = false;
  const replayed = [];

  ws.onopen = () => {
    console.log(clean(`▶ ${page.url}`));
    send('Runtime.enable');
    send('Log.enable');
    if (has('--reload')) {
      send('Page.reload', { ignoreCache: true });
      console.log('  Reloaded the page. Printing the logs from the start.');
    } else {
      send('Runtime.evaluate', { expression: 'JSON.stringify(window.__questLog || null)', returnByValue: true });
      historyId = nextId;
    }
  };
  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id === 1) {
      enabled = true;
      if (has('--reload')) replayed.length = 0;   // Logs from the page before the reload
      return;
    }
    if (msg.id === historyId) {
      const history = JSON.parse(msg.result?.result?.value ?? 'null');
      if (history) {
        console.log(`  Logs so far (${history.length}. Up to the newest 50)`);
        history.slice(-50).forEach((e) => print(e.level, e.text, '', Date.parse(e.time), e.count));
        flushRepeats();
        lastLine = '';
        console.log(`  ── New logs from here (${seconds}s) ──`);
      } else {
        replayed.forEach((show) => show());   // On a page that isn't from the template, prints the resent logs
      }
      replayed.length = 0;
      return;
    }
    const p = msg.params;
    if (msg.method === 'Runtime.consoleAPICalled') {
      const show = () => print(p.type, p.args.map(describe).join(' '), placeOf(p.stackTrace), p.timestamp);
      if (enabled) show(); else replayed.push(show);
    } else if (msg.method === 'Runtime.exceptionThrown') {
      const d = p.exceptionDetails;
      const show = () => print('error', d.exception?.description ?? d.text, placeOf(d.stackTrace) || `${d.url?.split('/').pop() ?? ''}:${d.lineNumber + 1}`, p.timestamp);
      if (enabled) show(); else replayed.push(show);
    } else if (msg.method === 'Log.entryAdded') {
      const e = p.entry;
      if (e.level === 'verbose') return;
      print(e.level, `${e.text}${e.url ? ` ${e.url}` : ''}`, '', e.timestamp);
    }
  };
  ws.onerror = () => console.log(clean(`✖ Couldn't connect to ${page.url}`));
}

setTimeout(() => {
  flushRepeats();
  console.log(`— Errors: ${errors}, warnings: ${warnings}`);
  process.exit(0);
}, seconds * 1000);
