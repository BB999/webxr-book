# Ground Rules for Claude

The ground rules themselves are in `AGENTS.md` (they're kept in one file so Claude and Codex use the same content). The line below loads them.

@AGENTS.md
