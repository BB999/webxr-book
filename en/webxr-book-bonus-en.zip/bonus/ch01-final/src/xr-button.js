// Makes the "Play in VR" and "Play in MR" buttons
// Pressing a button enters the VR / MR world on Quest. Anywhere else (like the Mac browser), the button can't be pressed
import * as THREE from 'three';

// Features to request from Quest for VR / MR. Marking them optional (use if available) lets the session start even if some aren't available
const DEFAULT_FEATURES = {
  'immersive-vr': { optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking'] },
  'immersive-ar': {
    optionalFeatures: ['local-floor', 'hand-tracking', 'plane-detection', 'mesh-detection', 'hit-test', 'anchors'],
  },
};

// Whether we're partway through entering VR / MR (shared by the VR and MR buttons)
let isStarting = false;

/**
 * Makes a button that enters VR / MR
 * @param {THREE.WebGLRenderer} renderer The artist
 * @param {'immersive-vr' | 'immersive-ar'} mode 'immersive-vr' for VR, 'immersive-ar' for MR
 * @param {string} label The button's text
 * @param {XRSessionInit} [sessionInit] Features to request from Quest (if left out, DEFAULT_FEATURES above)
 */
export function createXRButton(renderer, mode, label, sessionInit = DEFAULT_FEATURES[mode]) {
  const button = document.createElement('button');
  button.textContent = label;
  button.className = mode === 'immersive-ar' ? 'mr' : 'vr';
  button.disabled = true;

  if (!('xr' in navigator)) {
    button.textContent = `${label} (open in the Quest browser)`;
    return button;
  }
  navigator.xr.isSessionSupported(mode).then((supported) => {
    button.disabled = !supported;
    if (!supported) button.textContent = `${label} (open in the Quest browser)`;
  });

  button.addEventListener('click', async () => {
    // Does nothing if already in VR / MR or on the way in (asking again causes an InvalidStateError)
    if (isStarting || renderer.xr.isPresenting) return;
    isStarting = true;
    // Sound is only allowed after the player has done something, so this prepares the sound here, when the button is pressed
    THREE.AudioContext.getContext().resume();
    try {
      const session = await navigator.xr.requestSession(mode, sessionInit);
      document.getElementById('overlay').style.display = 'none';
      session.addEventListener('end', () => {
        document.getElementById('overlay').style.display = '';
      });
      await renderer.xr.setSession(session);
    } catch (error) {
      console.error(`Couldn't start ${label}:`, error);
    } finally {
      isStarting = false;
    }
  });
  return button;
}
