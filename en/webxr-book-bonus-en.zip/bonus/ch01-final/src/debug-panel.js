// Makes errors easy to find
// 1. Saves console.log output and errors in window.__questLog (the AI can read them from the Mac with npm run log)
// 2. When an error occurs, shows it on a red panel in front of you in VR / MR, or at the top left of the screen in the browser
// If the same error repeats every frame, combines it into one and counts the repeats
import * as THREE from 'three';

const MAX_LOG = 200;     // How many logs to keep
const MAX_SHOWN = 4;     // How many errors to show on the panel (newest first)

export function setupDebugPanel(scene, renderer) {
  const log = (window.__questLog = window.__questLog || []);
  const errors = [];     // { key, message, place, entry }
  let dirty = false;

  // For the browser screen: a red list at the top left (appears as soon as an error occurs)
  const list = document.createElement('div');
  list.id = 'debug-list';
  document.body.appendChild(list);
  function showList() {
    list.textContent = `Errors: ${errors.length}\n\n` +
      errors.slice(-MAX_SHOWN).map((e) => `${e.message}${e.place ? `\n  (${e.place})` : ''}`).join('\n\n');
    list.style.display = renderer.xr.isPresenting ? 'none' : 'block';
  }

  const toText = (value) => {
    if (value instanceof Error) return value.stack || `${value.name}: ${value.message}`;
    if (typeof value === 'object' && value !== null) {
      try { return JSON.stringify(value); } catch { return String(value); }
    }
    return String(value);
  };
  // From the stack (the path that led to the error), pulls out a place like "main.js:55"
  const placeOf = (text) => {
    const found = text.match(/([\w.-]+\.(?:js|mjs|ts))(?:\?[^:\s)]*)?:(\d+):\d+/);
    return found ? `${found[1]}:${found[2]}` : '';
  };

  // Adds to the log. When the same entry repeats, or the same error (same text and place) comes up again, only raises the count and returns true
  const record = (level, values) => {
    const text = values.map(toText).join(' ');
    const message = text.split('\n')[0];
    const place = placeOf(text);
    const key = `${message} ${place}`;
    const last = log[log.length - 1];
    const same = level === 'error' ? errors.find((e) => e.key === key)?.entry
      : last && last.level === level && last.text === text ? last : null;
    if (same) {
      same.count = (same.count || 1) + 1;
      return true;
    }
    const entry = { time: new Date().toISOString(), level, text };
    log.push(entry);
    if (log.length > MAX_LOG) log.shift();
    if (level === 'error') {
      errors.push({ key, message, place, entry });
      showList();
      dirty = true;
    }
    return false;
  };

  for (const level of ['log', 'info', 'warn', 'error']) {
    const original = console[level].bind(console);
    console[level] = (...values) => {
      if (record(level, values)) return;   // Repeats aren't shown in the browser's developer tools
      original(...values);
    };
  }
  addEventListener('error', (event) => record('error', [event.error || event.message]));
  addEventListener('unhandledrejection', (event) => record('error', ['Promise error:', event.reason]));

  // For VR / MR: the red panel in front of you (draws the text as a picture and puts it on the panel)
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const panel = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.6),
    new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthTest: false })
  );
  panel.name = 'debug-panel';
  panel.renderOrder = 999;     // Draws in front of everything else
  panel.raycast = () => {};    // Beam hit checks ignore this panel
  panel.visible = false;
  scene.add(panel);

  // Wraps long text to fit the panel's width
  const wrap = (g, text, width) => {
    const lines = [''];
    for (const char of text) {
      const line = lines[lines.length - 1] + char;
      if (g.measureText(line).width > width) lines.push(char);
      else lines[lines.length - 1] = line;
    }
    return lines;
  };
  const draw = () => {
    const g = canvas.getContext('2d');
    g.clearRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = 'rgba(150, 20, 20, 0.92)';
    g.fillRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = '#fff';
    g.font = 'bold 40px sans-serif';
    g.fillText(`Errors found: ${errors.length}`, 32, 64);
    g.font = '28px sans-serif';
    g.fillText('Ask the AI: "Read the Quest\'s logs and fix it"', 32, 110);
    let y = 170;
    for (const e of errors.slice(-MAX_SHOWN).reverse()) {
      g.font = '28px monospace';
      for (const line of wrap(g, e.message, canvas.width - 64).slice(0, 2)) {
        if (y > canvas.height - 20) break;
        g.fillText(line, 32, y);
        y += 36;
      }
      if (e.place && y <= canvas.height - 20) {
        g.font = '24px monospace';
        g.fillText(`  (${e.place})`, 32, y);
        y += 34;
      }
      y += 14;
    }
    texture.needsUpdate = true;
  };

  // On entering VR / MR, also shows earlier errors on the panel. On leaving, puts the panel away
  renderer.xr.addEventListener('sessionstart', () => {
    list.style.display = 'none';
    if (errors.length) dirty = true;
  });
  renderer.xr.addEventListener('sessionend', () => {
    panel.visible = false;
    if (errors.length) list.style.display = 'block';
  });

  const forward = new THREE.Vector3();
  return {
    // Called every frame after drawing. Only when there's a new error, shows the panel again in front of your head
    update() {
      if (!dirty || !renderer.xr.isPresenting) return;
      dirty = false;
      draw();
      // 1.5 meters in front of your head, slightly lower
      const head = renderer.xr.getCamera();
      head.getWorldDirection(forward);
      forward.y = 0;
      forward.normalize();
      panel.position.copy(head.position).addScaledVector(forward, 1.5);
      panel.position.y -= 0.3;
      panel.lookAt(head.position.x, panel.position.y, head.position.z);
      panel.visible = true;
    },
  };
}
