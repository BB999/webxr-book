// The project's entry point. Builds a 3D world with three.js that you can see in VR on Quest
// Write your project under the "Your project goes below this line" line at the very bottom
// The ground rules for the AI are in AGENTS.md (for Codex) and CLAUDE.md (for Claude)
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- The three actors: the stage (scene), the eyes (camera), and the artist (renderer) ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // Background color (turns transparent automatically in MR, so you can see the room)

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // Eye height of 1.5 meters (in VR, it moves with your head on the Quest)

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // Puts the floor at height 0
document.body.appendChild(renderer.domElement);

// ---- Lights ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // Light that shines evenly on everything
const sun = new THREE.DirectionalLight(0xffffff, 2);            // Light that comes from one direction
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- Floor grid (each square is 1 meter). A guide for judging size. Hidden in MR, where you can see the real floor ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- When viewing in the Mac browser: drag with the mouse to look around (not used in VR) ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- "Play in VR" button ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'Play in VR'));

// ---- Also shows errors in VR (read the logs with npm run log) ----
const debug = setupDebugPanel(scene, renderer);

// ---- Repeats every frame: moves things in update() below, then redraws ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // Keeps things from jumping ahead after a pause
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // Keeps drawing even after an error (the error appears on the red panel)
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- When the browser window changes size, resizes the picture to match ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== Your project goes below this line ========
// Put things on the stage with scene.add(). Units are meters. The floor is at height 0, and straight ahead is the minus z direction
// Write anything you want to move every frame inside update() below

// Places a cube, 30 centimeters on each side, 1 meter straight ahead at about eye level
const cube = new THREE.Mesh(
  new THREE.BoxGeometry(0.3, 0.3, 0.3),
  new THREE.MeshStandardMaterial({ color: 0x44aaff }),
);
cube.position.set(0, 1.5, -1);
scene.add(cube);

/**
 * Called every frame
 * @param {number} delta Time since the last frame (seconds)
 * @param {number} elapsed Time since the start (seconds)
 */
function update(delta, elapsed) {
  // Rotates slowly according to the seconds that have passed
  cube.rotation.x += delta * 0.2;
  cube.rotation.y += delta * 0.3;
}
