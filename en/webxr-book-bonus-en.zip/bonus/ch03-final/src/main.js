// The project's entry point. Builds a 3D world with three.js that you can see in VR on Quest
// Write your project under the "Your project goes below this line" line at the very bottom
// The ground rules for the AI are in AGENTS.md (for Codex) and CLAUDE.md (for Claude)
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- The three actors: the stage (scene), the eyes (camera), and the artist (renderer) ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // Background color (turns transparent automatically in MR, so you can see the room)

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // Eye height of 1.5 meters (in VR, it moves with your head on the Quest)

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // Puts the floor at height 0
document.body.appendChild(renderer.domElement);

// ---- Lights ----
// The planet's lights are set up in the project section below

// ---- When viewing in the Mac browser: drag with the mouse to look around (not used in VR) ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- "Play in VR" button ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'Play in VR'));

// ---- Also shows errors in VR (read the logs with npm run log) ----
const debug = setupDebugPanel(scene, renderer);

// ---- Repeats every frame: moves things in update() below, then redraws ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // Keeps things from jumping ahead after a pause
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // Keeps drawing even after an error (the error appears on the red panel)
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- When the browser window changes size, resizes the picture to match ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== Your project goes below this line ========
// Put things on the stage with scene.add(). Units are meters. The floor is at height 0, and straight ahead is the minus z direction
// Write anything you want to move every frame inside update() below

// Scatters 2000 stars in all directions, 60 to 100 meters from eye position
const starPositions = new Float32Array(2000 * 3);
for (let i = 0; i < 2000; i++) {
  const height = Math.random() * 2 - 1;
  const angle = Math.random() * Math.PI * 2;
  const distance = 60 + Math.random() * 40;
  const horizontal = Math.sqrt(1 - height * height);
  starPositions[i * 3] = distance * horizontal * Math.cos(angle);
  starPositions[i * 3 + 1] = 1.6 + distance * height;
  starPositions[i * 3 + 2] = distance * horizontal * Math.sin(angle);
}
// Draws the stars all together so they stay light on Quest
const starGeometry = new THREE.BufferGeometry();
starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
const stars = new THREE.Points(
  starGeometry,
  new THREE.PointsMaterial({ color: 0xffffff, size: 0.15, sizeAttenuation: true, toneMapped: false }),
);
scene.add(stars);

// Leaves a white light just strong enough to faintly show the pattern on the dark side
scene.add(new THREE.AmbientLight(0xffffff, 0.12));
// Shines parallel white light from diagonally above on the left, like a faraway sun
const sun = new THREE.DirectionalLight(0xffffff, 2);
sun.position.set(-100, 101.6, 48);
sun.target.position.set(0, 1.6, -2);
scene.add(sun, sun.target);

// Draws a Jupiter-like pattern once, without using an image file
// Colors thin stripes by latitude and makes their edges wavy with noise. Adds a reddish-brown oval in the south, like the Great Red Spot
const planetCanvas = document.createElement('canvas');
planetCanvas.width = 2048;
planetCanvas.height = 1024;
const planetContext = planetCanvas.getContext('2d');
const planetPixels = planetContext.createImageData(2048, 1024);

// Smooth noise (sampled at points on the sphere's surface, so no seams appear)
const hash = (x, y, z) => {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
};
const smooth = (t) => t * t * (3 - 2 * t);
const noise = (x, y, z) => {
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
  const fx = smooth(x - ix), fy = smooth(y - iy), fz = smooth(z - iz);
  const lerp = (a, b, t) => a + (b - a) * t;
  const corner = (dx, dy, dz) => hash(ix + dx, iy + dy, iz + dz);
  return lerp(
    lerp(lerp(corner(0, 0, 0), corner(1, 0, 0), fx), lerp(corner(0, 1, 0), corner(1, 1, 0), fx), fy),
    lerp(lerp(corner(0, 0, 1), corner(1, 0, 1), fx), lerp(corner(0, 1, 1), corner(1, 1, 1), fx), fy),
    fz,
  );
};
const fbm = (x, y, z, octaves) => {
  let sum = 0, amp = 0.5, freq = 1;
  for (let i = 0; i < octaves; i++) {
    sum += amp * noise(x * freq, y * freq, z * freq);
    amp *= 0.5;
    freq *= 2;
  }
  return sum;
};

// From north to south: each stripe's top-edge latitude (degrees) and color
const bands = [
  [90, [138, 124, 110]], [62, [168, 148, 124]], [50, [204, 180, 146]], [44, [168, 128, 96]],
  [37, [226, 206, 172]], [30, [178, 122, 82]], [23, [236, 222, 192]], [17, [176, 104, 64]],
  [8, [242, 228, 198]], [-7, [158, 92, 56]], [-19, [236, 216, 182]], [-27, [184, 132, 92]],
  [-34, [222, 202, 168]], [-43, [172, 136, 106]], [-53, [188, 168, 142]], [-63, [138, 124, 110]],
];
const bandColor = (latDeg) => {
  let i = bands.findIndex((b, k) => k === bands.length - 1 || latDeg > bands[k + 1][0]);
  const [top, color] = bands[i];
  const next = bands[i + 1];
  // Near a stripe's lower edge, blends smoothly into the next stripe's color
  if (!next) return color;
  const t = Math.min(1, Math.max(0, (next[0] + 1.5 - latDeg) / 3));
  return color.map((c, k) => c + (next[1][k] - c) * smooth(t));
};

const spotLat = THREE.MathUtils.degToRad(-22);
const spotLon = Math.PI / 2; // The side that faces you first
for (let y = 0; y < 1024; y++) {
  const latitude = (0.5 - (y + 0.5) / 1024) * Math.PI;
  for (let x = 0; x < 2048; x++) {
    const longitude = ((x + 0.5) / 2048) * Math.PI * 2;
    const px = Math.cos(latitude) * Math.cos(longitude);
    const py = Math.cos(latitude) * Math.sin(longitude);
    const pz = Math.sin(latitude);

    // Makes the stripe edges wavy
    const warp = (fbm(px * 3, py * 3, pz * 3, 3) - 0.5) * 7 + (fbm(px * 10, py * 10, pz * 10, 2) - 0.5) * 1.2;
    let color = bandColor(THREE.MathUtils.radToDeg(latitude) + warp);

    // Fine streaks running sideways (fine from north to south, long from east to west)
    const streak = fbm(px * 6, py * 6, pz * 60, 3);
    color = color.map((c) => c * (0.86 + streak * 0.28));

    // A reddish-brown oval with blurry edges, like the Great Red Spot
    let dLon = longitude - spotLon;
    dLon = Math.atan2(Math.sin(dLon), Math.cos(dLon));
    const d = Math.hypot((dLon * Math.cos(latitude)) / 0.34, (latitude - spotLat) / 0.15)
      + (fbm(px * 20, py * 20, pz * 20, 2) - 0.5) * 0.25;
    if (d < 1.5) {
      const core = 1 - smooth(Math.min(1, Math.max(0, (d - 0.55) / 0.45)));
      const ring = Math.max(0, 1 - Math.abs(d - 1.15) / 0.3);
      color = color.map((c, k) => c + ([246, 230, 206][k] - c) * ring * 0.7);
      color = color.map((c, k) => c + ([204, 102, 66][k] * (0.9 + streak * 0.2) - c) * core);
    }

    const offset = (y * 2048 + x) * 4;
    planetPixels.data[offset] = color[0];
    planetPixels.data[offset + 1] = color[1];
    planetPixels.data[offset + 2] = color[2];
    planetPixels.data[offset + 3] = 255;
  }
}
planetContext.putImageData(planetPixels, 0, 0);
const planetTexture = new THREE.CanvasTexture(planetCanvas);
planetTexture.colorSpace = THREE.SRGBColorSpace;
planetTexture.anisotropy = 8;

// Places a planet with a 0.5 meter radius at eye level, 2 meters straight ahead
const planetSurface = new THREE.Mesh(
  new THREE.SphereGeometry(0.5, 64, 32),
  new THREE.MeshStandardMaterial({ map: planetTexture, roughness: 1 }),
);
// Separates the axis tilt from the spin, so the tilted axis keeps its direction
const planetAxis = new THREE.Group();
planetAxis.rotation.z = THREE.MathUtils.degToRad(20);
planetAxis.add(planetSurface);
// Makes the whole planet a parent, so the surface's spin and the moon's orbit move separately
const planet = new THREE.Group();
planet.position.set(0, 1.6, -2);
planet.add(planetAxis);
scene.add(planet);

// Places an invisible platform at the planet's center that turns separately from the spin
const moonPlatform = new THREE.Group();
planet.add(moonPlatform);

// Draws the moon's pattern (dark "seas" and craters) and its bumpy heights once, without using an image file
const moonColorCanvas = document.createElement('canvas');
const moonBumpCanvas = document.createElement('canvas');
moonColorCanvas.width = moonBumpCanvas.width = 1024;
moonColorCanvas.height = moonBumpCanvas.height = 512;
const moonColorContext = moonColorCanvas.getContext('2d');
const moonBumpContext = moonBumpCanvas.getContext('2d');
const moonColorPixels = moonColorContext.createImageData(1024, 512);
const moonBumpPixels = moonBumpContext.createImageData(1024, 512);

// Decides crater positions and sizes with random numbers that come out in the same order every time
let seed = 7;
const random = () => {
  seed = (seed * 16807) % 2147483647;
  return seed / 2147483647;
};
const craters = [];
for (let i = 0; i < 260; i++) {
  const z = random() * 2 - 1;
  const angle = random() * Math.PI * 2;
  const r = Math.sqrt(1 - z * z);
  // Makes smaller craters more numerous
  const size = 0.03 + 0.17 * random() ** 3;
  craters.push({ x: r * Math.cos(angle), y: r * Math.sin(angle), z, size, near: Math.cos(size * 1.4) });
}

for (let y = 0; y < 512; y++) {
  const latitude = (0.5 - (y + 0.5) / 512) * Math.PI;
  for (let x = 0; x < 1024; x++) {
    const longitude = ((x + 0.5) / 1024) * Math.PI * 2;
    const px = Math.cos(latitude) * Math.cos(longitude);
    const py = Math.cos(latitude) * Math.sin(longitude);
    const pz = Math.sin(latitude);

    // Dark "seas" and a fine rough texture
    const sea = smooth(Math.min(1, Math.max(0, (fbm(px * 2, py * 2, pz * 2, 4) - 0.46) / 0.2)));
    let shade = 0.78 - sea * 0.3 + (fbm(px * 30, py * 30, pz * 30, 3) - 0.5) * 0.12;
    let height = 0.5 + (fbm(px * 30, py * 30, pz * 30, 3) - 0.5) * 0.3;

    // Craters: the floor is sunken and a little darker, and the rim is raised and brighter
    for (const c of craters) {
      // Skips distant craters before calculating the angle
      const dot = px * c.x + py * c.y + pz * c.z;
      if (dot < c.near) continue;
      const d = Math.acos(Math.min(1, dot)) / c.size;
      if (d < 1) {
        height -= 0.35 * (1 - d * d);
        shade -= 0.06 * (1 - d);
      }
      const rim = Math.max(0, 1 - Math.abs(d - 1) / 0.4);
      height += 0.2 * rim;
      shade += 0.03 * rim;
    }

    const gray = Math.min(255, Math.max(0, shade * 255));
    const bump = Math.min(255, Math.max(0, height * 255));
    const offset = (y * 1024 + x) * 4;
    moonColorPixels.data[offset] = gray;
    moonColorPixels.data[offset + 1] = gray * 0.98;
    moonColorPixels.data[offset + 2] = gray * 0.95;
    moonColorPixels.data[offset + 3] = 255;
    moonBumpPixels.data[offset] = moonBumpPixels.data[offset + 1] = moonBumpPixels.data[offset + 2] = bump;
    moonBumpPixels.data[offset + 3] = 255;
  }
}
moonColorContext.putImageData(moonColorPixels, 0, 0);
moonBumpContext.putImageData(moonBumpPixels, 0, 0);
const moonTexture = new THREE.CanvasTexture(moonColorCanvas);
moonTexture.colorSpace = THREE.SRGBColorSpace;
const moonBump = new THREE.CanvasTexture(moonBumpCanvas);

// Makes the moon, 20 centimeters in diameter, a child of the platform, 1 meter from its center
const moon = new THREE.Mesh(
  new THREE.SphereGeometry(0.1, 64, 32),
  new THREE.MeshStandardMaterial({ map: moonTexture, bumpMap: moonBump, bumpScale: 3, roughness: 1 }),
);
moon.position.set(1, 0, 0);
moonPlatform.add(moon);

/**
 * Called every frame
 * @param {number} delta Time since the last frame (seconds)
 * @param {number} elapsed Time since the start (seconds)
 */
function update(delta, elapsed) {
  // Spins once every 20 seconds around the planet's own vertical axis
  planetSurface.rotation.y = (planetSurface.rotation.y + (Math.PI * 2 / 20) * delta) % (Math.PI * 2);
  // Turns the platform once every 10 seconds, carrying the moon around the planet
  moonPlatform.rotation.y = (moonPlatform.rotation.y + (Math.PI * 2 / 10) * delta) % (Math.PI * 2);
}
