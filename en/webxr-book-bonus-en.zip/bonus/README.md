# Bonus Downloads for The WebXR Textbook Even a Stray Cat Can Understand

| Folder or file | What it is |
|---|---|
| `webxr-book-template` | The template (used from Chapter 1) |
| `chNN-start` | The starting point for that chapter |
| `chNN-final` | The finished version of that chapter. If you get stuck, swap this in and move on |
| `models/nekobi.glb` | The 3D model of Nekobi (Chapter 5) |
| `prompts.md` | The book's prompts, ready to copy |
| `LICENSE` | Terms for the code (MIT: use it freely, including publishing and commercial use) |
| `LICENSE-nekobi.md` | Terms for the 3D model of Nekobi |

Copy a folder to anywhere on your Mac, move to it in Terminal with `cd`, and run `npm install`. Then start the AI (`claude` or `codex`) and ask it to run the dev server. See Chapters 1 and 3 (3-1) of the book for details.
