# Terms of Use for the 3D Model of Nekobi

Covers: `models/nekobi.glb` (the same file as `public/models/nekobi.glb` in each chapter's sample) and the character Nekobi.
These terms are separate from the LICENSE (MIT) for the bonus code.
This is a translation. If it differs from the Japanese version (`LICENSE-nekobi.md` in the Japanese bonus downloads), the Japanese version takes priority.

## You may

- Include it in your own projects and publish them (you're also free to hand out QR codes and have people play them).
- Modify its shape, or change its colors and patterns.

## You may not

- Use it in projects you receive money for (paid distribution or commercial projects).
- Distribute or sell the model itself (including lightly modified versions).
- Claim that Nekobi is a character you created.

## Other

- Noranekobi can't take responsibility for anything that happens as a result of using it.

Noranekobi
