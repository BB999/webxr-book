// The project's entry point. Builds a 3D world with three.js that you can see in VR on Quest
// Write your project under the "Your project goes below this line" line at the very bottom
// The ground rules for the AI are in AGENTS.md (for Codex) and CLAUDE.md (for Claude)
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createXRButton } from './xr-button.js';
import { setupDebugPanel } from './debug-panel.js';

// ---- The three actors: the stage (scene), the eyes (camera), and the artist (renderer) ----
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101820);   // Background color (turns transparent automatically in MR, so you can see the room)

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.01, 200);
camera.position.set(0, 1.5, 0);                 // Eye height of 1.5 meters (in VR, it moves with your head on the Quest)

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor'); // Puts the floor at height 0
document.body.appendChild(renderer.domElement);

// ---- Lights ----
scene.add(new THREE.HemisphereLight(0xffffff, 0x445566, 1.2));  // Light that shines evenly on everything
const sun = new THREE.DirectionalLight(0xffffff, 2);            // Light that comes from one direction
sun.position.set(2, 4, 1);
scene.add(sun);

// ---- Floor grid (each square is 1 meter). A guide for judging size. Hidden in MR, where you can see the real floor ----
const grid = new THREE.GridHelper(10, 10, 0x6a8aa8, 0x3a4f63);
scene.add(grid);
renderer.xr.addEventListener('sessionstart', () => { grid.visible = renderer.xr.getEnvironmentBlendMode() === 'opaque'; });
renderer.xr.addEventListener('sessionend', () => { grid.visible = true; });

// ---- When viewing in the Mac browser: drag with the mouse to look around (not used in VR) ----
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -1);
controls.update();

// ---- "Play in VR" button ----
document.getElementById('buttons').appendChild(createXRButton(renderer, 'immersive-vr', 'Play in VR'));

// ---- Also shows errors in VR (read the logs with npm run log) ----
const debug = setupDebugPanel(scene, renderer);

// ---- Repeats every frame: moves things in update() below, then redraws ----
const timer = new THREE.Timer();
timer.connect(document);
renderer.setAnimationLoop((time) => {
  timer.update(time);
  const delta = Math.min(timer.getDelta(), 0.1);   // Keeps things from jumping ahead after a pause
  try {
    update(delta, timer.getElapsed());
  } catch (error) {
    console.error(error);   // Keeps drawing even after an error (the error appears on the red panel)
  }
  controls.enabled = !renderer.xr.isPresenting;
  renderer.render(scene, camera);
  debug.update();
});

// ---- When the browser window changes size, resizes the picture to match ----
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ======== Your project goes below this line ========
// Put things on the stage with scene.add(). Units are meters. The floor is at height 0, and straight ahead is the minus z direction
// Write anything you want to move every frame inside update() below

/**
 * Called every frame
 * @param {number} delta Time since the last frame (seconds)
 * @param {number} elapsed Time since the start (seconds)
 */
function update(delta, elapsed) {
}

// ---- Meadow (Chapter 4's starting point): sky and ground ----
scene.remove(grid);                                // The grid isn't used
scene.background = new THREE.Color(0xe3f3ff);      // Sky color (near the horizon)
scene.fog = new THREE.Fog(0xe3f3ff, 25, 110);      // Fades the distance into the sky color

// Sky: a large sphere painted on the inside. Deep blue at the top, whiter toward the horizon
const skyGeometry = new THREE.SphereGeometry(100, 32, 16);
const skyColors = [];
const top = new THREE.Color(0x4a9be0);
const horizon = new THREE.Color(0xe3f3ff);
const position = skyGeometry.attributes.position;
for (let i = 0; i < position.count; i++) {
  const height = Math.max(0, position.getY(i) / 100);   // 0 (horizon) to 1 (straight up)
  const color = horizon.clone().lerp(top, Math.pow(height, 0.6));
  skyColors.push(color.r, color.g, color.b);
}
skyGeometry.setAttribute('color', new THREE.Float32BufferAttribute(skyColors, 3));
const sky = new THREE.Mesh(skyGeometry, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false }));
scene.add(sky);

// Ground: a green panel, 240 meters on each side (the distance fades into the sky color with fog)
const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(240, 240, 48, 48),
  new THREE.MeshStandardMaterial({ color: 0x79c26a, roughness: 1 })
);
ground.rotation.x = -Math.PI / 2;                  // Lays it flat to make the floor
scene.add(ground);

// Distant hills: squashed spheres placed in a circle all around
const hillMaterial = new THREE.MeshStandardMaterial({ color: 0x5fae58, roughness: 1 });
for (let i = 0; i < 9; i++) {
  const angle = (i / 9) * Math.PI * 2 + 0.3;
  const hill = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), hillMaterial);
  const distance = 55 + (i % 3) * 12;
  hill.position.set(Math.sin(angle) * distance, 0, -Math.cos(angle) * distance);
  hill.scale.set(14 + (i % 4) * 4, 5 + (i % 3) * 2.5, 10);
  hill.lookAt(0, 0, 0);
  scene.add(hill);
}

// Clouds: a few white spheres stacked together, floating in the sky
const cloudMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0xaab6c2, fog: false });
for (let i = 0; i < 7; i++) {
  const angle = (i / 7) * Math.PI * 2;
  const cloud = new THREE.Group();
  for (let j = 0; j < 4; j++) {
    const puff = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), cloudMaterial);
    puff.position.set((j - 1.5) * 2.2, (j % 2) * 0.8, 0);
    puff.scale.setScalar(2 + (j % 2));
    cloud.add(puff);
  }
  cloud.position.set(Math.sin(angle) * 80, 30 + (i % 3) * 6, -Math.cos(angle) * 80);
  cloud.lookAt(0, cloud.position.y, 0);
  scene.add(cloud);
}
